<?php
// Pusat Pelaporan dan Data Statistik Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id
// Written by iyok642@yahoo.com, lastupdate 28 Pebruari 2014

//parameter tanggal
$bln = $_POST["bln"]*1; if($bln==""){ $bln = $_GET["bln"]*1; };
$thn = $_POST["thn"]*1; if($thn==""){ $thn = $_GET["thn"]*1; };
$laporan = $_POST["laporan"]*1;     if($laporan==""){ $laporan = $_GET["laporan"]*1; };
$id_parent = $_POST["id_parent"]*1; if($id_parent==""){ $id_parent = $_GET["id_parent"]*1; };
$id_satker = $_POST["id_satker"]*1; if($id_satker==""){ $id_satker = $_GET["id_satker"]*1; };

if (($bln=="") and ($thn=="") and ($laporan <> "")){ $bln=substr($laporan,4,2)*1; $thn=substr($laporan,0,4)*1; }

//set default bulan tahun laporan
if ($bln==""){ 
	$bln = (date('m')-1)*1; $thn = date('Y')*1;
	if (date('d')>=25){ $bln = date('m')*1; }
	if ($bln==0){ $bln=12; $thn=(date('Y')-1)*1; }
};//if
if ($laporan == ""){ $laporan="$thn$bln"; };

//load setting
include_once("include.php");
include("include_login.php");

$runSQL = "select * from laporan_satker where id_satker='$SESS_ID_SATKER'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) { 
	$tk_satker=$row[tk_satker];
	if ($tk_satker=="PTA"){ $filterSQL="id_satker='$SESS_ID_SATKER'"; }
	else { $filterSQL="tk_satker='PTA' or tk_satker='PUSAT'"; };
};//while

$view_this_satker = $SESS_ID_SATKER;
if ($tk_satker <> "PA"){
	$runSQL = "select * from laporan_satker where $filterSQL order by nm_satker";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		if ($id_parent==""){ $id_parent=12; };
		if ($id_parent==$row[id_satker]) { $cek="selected"; }else{ unset($cek); }
		$selectpta .= "<option value=\"$laporan&id_parent=$row[id_satker]\" $cek>$row[nm_satker]</option>"; 
	};//while
	$selectpta = "<select size=1 name=\"laporan\" onChange=\"runJump3(this.value)\" class=\"laporanfree\"> $selectpta </select>";

	$runSQL = "select * from laporan_satker where id_parent='$id_parent' order by nm_satker";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		if ($id_satker==""){ $id_satker=$row[id_satker]; };
		if ($id_satker==$row[id_satker]) { $cek="selected"; $view_this_satker=$row[id_satker]; }else{ unset($cek); }
		$selectpa .= "<option value=\"$laporan&id_parent=$id_parent&id_satker=$row[id_satker]\" $cek>$row[nm_satker]</option>"; 
	};//while
	$selectpa = "<select size=1 name=\"laporan\" onChange=\"runJump3(this.value)\" class=\"laporanfree\"> $selectpa </select>";
	
	$parser = "&id_parent=$id_parent&id_satker=$id_satker";
	$dlparser = "&id_satker=$view_this_satker";
};//if

//data satker
$runSQL = "select * from laporan_satker where id_satker='$view_this_satker'";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$nm_satker_pjg = $row[nm_satker_pjg];
};//while

//pilihan bulan tahun laporan
unset($selectbulan);
for($i=1; $i<=12; $i++){
	if ($i==($bln*1)) { $cek="selected"; }else{ unset($cek); }
	$selectbulan .= "<option value=\"".$i."$parser\" $cek> &nbsp; ".$bulan[$i]." &nbsp; </option>"; 
};//for
$selectbulan = "<select size=1 name=\"bln\" onChange=\"runJump(this.value)\" class=\"laporanfree\"> $selectbulan </select>";

unset($selecttahun);
for($i=2014; $i<=date('Y'); $i++){
	if ($i==($thn*1)) { $cek="selected"; }else{ unset($cek); }
	$selecttahun .= "<option value=\"".$i.$bln."$parser\" $cek> &nbsp; ".$i." &nbsp; </option>"; 
};//for
$selecttahun = "<select size=1 name=\"thn\" onChange=\"runJump3(this.value)\" class=\"laporanfree\"> $selecttahun </select>";

?>
<html>
<head>
  <meta name="Generator" content="EditPlus">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <meta name="Description" content="Sistem Pendaftaran Perkara Secara Online Pengadilan Agama">
  <title>Laporan Perkara <? echo $bulan[($bln*1)]." ".$thn; ?></title>
  <link rel="shortcut icon" href="favicon.ico">
  <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
 <tr>
   <td align="center">
	<table width="980" border="0" cellpadding="0" cellspacing="0">
	</table>
	<table width="980" height="450" border="0" cellpadding="0" cellspacing="0" align="center">
	  <tr><td width="100%" colspan="2"><?php include("header.php"); ?></td></tr>
	  <tr>
        <td width="200" valign="top" bgcolor="#336600"><?php include("menu.php"); ?></td>
        <td width="780" valign="top">
		<table width="100%" height="450" bgcolor="#FFFFFF" border="1" cellpadding="10" cellspacing="0" style="border-collapse:collapse" bordercolor="#003300">
		 <tr>
			<td width="100%" vAlign="top">
			<!--content-->
	
			<table align="center" border="0" cellpadding="1" cellspacing="5" width="750">
			  <tr><td width="100%" align="center"><? echo $selectpta." ".$selectpa; ?></td></tr>
			  <tr>
			    <td width="100%" align="center">
				<? echo $selectbulan.' '.$selecttahun; ?><br>
				<br><font color="#0000FF" size="3"><b>Laporan Rekapitulasi Perkara<br><?=$nm_satker_pjg?><br>Bulan <?=$bulan[($bln*1)]." Tahun ".$thn;?></b></font><br>
				<br>Untuk keperluan hardcopy (<b>cetak laporan bulanan</b>) silakan download file berikut
				<table align="center" border="0" cellpadding="1" cellspacing="5">
				  <tr>
				    <td align="center" valign="top"><a href="download.php?<?="bln=$bln&thn=$thn$dlparser";?>"><img src="img/csv.jpg" height='35'></a><br><a href="download.php?<?="bln=$bln&thn=$thn$dlparser";?>"><font size="1" color="#009900"><b>RK<br><?=$bulan[($bln*1)]."<br>".$thn;?></a></td>
					<td align="center"> &nbsp; </td>
				    <td align="center" valign="top"><a href="download_delegasi.php?<?="bln=$bln&thn=$thn$dlparser";?>"><img src="img/csv.jpg" height='35'></a><br><a href="download_delegasi.php?<?="bln=$bln&thn=$thn$dlparser";?>"><font size="1" color="#009900"><b>Delegasi<br><?=$bulan[($bln*1)]."<br>".$thn;?></a></td>
					<td align="center"> &nbsp; </td>
					<td align="center" valign="top"><a href="download_delegasi_keluar.php?<?="bln=$bln&thn=$thn$dlparser";?>"><img src="img/csv.jpg" height='35'></a><br><a href="download_delegasi_keluar.php?<?="bln=$bln&thn=$thn$dlparser";?>"><font size="1" color="#009900"><b>Delegasi<br>Keluar<br><?=$bulan[($bln*1)]."<br>".$thn;?></a></td>
					<td align="center"> &nbsp; </td>
				    <td align="center"  valign="top"><a href="download_pa.php?<?="bln=$bln&thn=$thn$dlparser";?>"><img src="img/csv.jpg" height='35'></a><br><a href="download_pa.php?<?="bln=$bln&thn=$thn$dlparser";?>"><font size="1" color="#009900"><b>RK<br>Setahun</a></td>
				  </tr>
				</table>
			    </td>
			  </tr>
			</table>
		    <iframe name="news_view" border="0" src="rk_gabungan.php?<?="bln=$bln&thn=$thn$dlparser";?>" width="100%" height="1440" style="border:none"></iframe>

			<!--end.content-->
			</td>
		 </tr>
		</table>
		</td>
	  </tr>
	  <tr>
        <td width="100%" bgcolor="#004A00" colspan="2"><?php include("footer.php"); ?></td>
	  </tr>
	</table>
    </td>
  </tr>
</table>
<script language="Javascript" type="text/javascript">
	function runJump(val) {
	  window.location='<?=$_SERVER["PHP_SELF"];?>?laporan=<?=$thn?>'+val; //make connection
	}
	function runJump3(val) {
	  window.location='<?=$_SERVER["PHP_SELF"];?>?laporan='+val; //make connection
	}
</script>
</body>
</html>
<?
if ($connDB){ $close = mysql_close($connDB);};
?>