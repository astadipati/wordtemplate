<?php
// Aplikasi Pendaftaran Perkara Online
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id
// Contact Tim IT PTA Surabaya, lastupdate 15 Mei 2013

session_start();
$session_id = session_id();

//load setting
include_once("include.php");

if ($run == ""){ $run = $_POST["run"]; };
if ($myusername == ""){ $myusername = strtoupper(substr($_POST["myusername"],0,15)); };
if ($mypassword == ""){ $mypassword = md5(substr($_POST["mypassword"],0,25)); };
if ($do == ""){ $do = substr($_GET["do"],0,20); };

if ($do == "logout"){

	  mysql_query("delete from sys_session where session_id='$session_id'");
	  mysql_query("optimize table sys_session");
	  $info_passwd = "<br><font color='#000099' size='1'><i>Logout...<br>Silakan masukan username dan password lagi.";

} else if ((strlen($myusername) > 2) and (strlen($mypassword) > 1)){
	
	$runSQL = "select * from sys_username where upper(name_user)='$myusername' and pass_user='$mypassword'";
	$result = mysql_query($runSQL, $connDB);
	if ($row = mysql_fetch_array ($result)) { 
		
		$id_satker = $row[id_satker];
		$id_user = $row[id_user];
		$id_location = flocation($REMOTE_ADDR);

		mysql_query("delete from sys_session where session_id='$session_id'");
		mysql_query("insert into sys_session (created, session_id, ip_address, id_satker, name_user, name_server) values (now(), '$session_id', '$REMOTE_ADDR', '$id_satker', '$myusername', 'localhost')");
		mysql_query("update sys_user_access set login_count=login_count+1, var_access=CONCAT(var_access,';',CURTIME(),':$id_user:$id_satker:$id_location') where currentdate=curdate() and session_id='$session_id'");
		mysql_close($connDB);
		header("location:tampil.php");

	} else {

		$info_passwd = "<br><font color='#FF0000' size='1'><i>Username/Password tidak sesuai.";

	};//if (sys_username)
};//end-while

//set parameter flocation for history
function flocation($REMOTE_ADDR){
	global $connDB, $id_location;
	$runSQL = "select id_location from sys_location where ipaddress='$REMOTE_ADDR'";
	$result = mysql_query($runSQL, $connDB);
	if ($row = mysql_fetch_array ($result)) { 
		$id_location = $row[id_location];
	} else {
	  $runSQL = "insert into sys_location (ipaddress, created) values ('$REMOTE_ADDR', NOW())";
	  $insert = mysql_query($runSQL, $connDB);
	  $id_location = mysql_insert_id($connDB);
	};//if
	return $id_location;
};//flocation

//set parameter fusername for history
function fusername($name_user, $pass_user, $fullname, $id_satker, $name_server){
	global $connDB, $id_user;
	$runSQL = "select id_user from sys_username where name_user='$name_user' and name_server='$name_server'";
	$result = mysql_query($runSQL, $connDB);
	if ($row = mysql_fetch_array ($result)) { 
		$id_user = $row[id_user];
		if ($row[pass_user] <> $pass_user){ mysql_query("update sys_username set pass_user='$pass_user' where id_user='$id_user'", $connDB); };
	} else {
	  $runSQL = "insert into sys_username (name_user, pass_user, fullname, id_satker, name_server, created) values ('$name_user', '$pass_user', '$fullname', '$id_satker', '$name_server', NOW())";
	  $insert = mysql_query($runSQL, $connDB);
	  $id_user = mysql_insert_id($connDB);
	};//if
	return $id_user;
};//flocation

?>
<html>
<head>
  <meta name="Generator" content="EditPlus">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <meta name="Description" content="Sistem Pendaftaran Perkara Secara Online Pengadilan Agama">
  <title>Pusat Pelaporan dan Data Statistik PTA Surabaya</title>
  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
  <link rel="icon" href="favicon.ico" type="image/x-icon">
  <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
 <tr>
   <td align="center">
	<table width="980" border="0" cellpadding="0" cellspacing="0">
	</table>
	<table width="980" height="450" border="0" cellpadding="0" cellspacing="0" align="center">
	  <tr><td width="100%" colspan="2"><?php include("header.php"); ?></td></tr>
	  <tr>
        <td width="980" valign="top">
		<table width="100%" height="450" bgcolor="#FFFFFF" border="1" cellpadding="10" cellspacing="0" style="border-collapse:collapse" bordercolor="#003300">
		 <tr>
			<td width="100%" align="center" vAlign="top">
			<table border="0" cellpadding="5" cellspacing="1" width="750" height="500">
			  <tr>
				<td width="100%"  align="center" vAlign="top">

				<br><br>
				<form method="POST" name="form" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
				<table border="0" cellpadding="5" cellspacing="1" width="400">
				  <tr>
					<td bgcolor='#339900' width="100%" align="center" colspan="2"><b>Authority</b></td>
				  </tr>
				  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
					<td width="30%" align="right">Username : </td>
					<td width="70%"><input type="text" name="myusername" size="20"><?php echo $info_usernm; ?></td>
				  </tr>
				  <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
					<td width="30%" align="right" valign="top">Password : </td>
					<td width="70%"><input type="password" name="mypassword" size="20"><?php echo $info_passwd; ?></td>
				  </tr>
				  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
					<td width="100%" colspan="2" align="center">
						<input type="submit" value="  Login " name="run" class="button">
					</td>
				  </tr>
				</table>   
				</form>

				<br><br>
				<table border="1" cellpadding="30" cellspacing="0" width="500">
				  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
					<td width="100%" align="center">
					  Untuk username & password dapat menggunakan account<br>
					  <font color="#FF0000"><b>infoperkara</b></font>
					</td>
				  </tr>
				</table>   



				</td>
			 </tr>
			</table>
			<p align="right"><font color="#969696"><i><? echo $REMOTE_ADDR; ?></i></font></p>
			</td>
		 </tr>
		</table>
		</td>
	  </tr>
	  <tr>
        <td width="100%" bgcolor="#004A00" colspan="2"><?php include("footer.php"); ?></td>
	  </tr>
	</table>
    </td>
  </tr>
</table>
</body>
</html>
<?php
if ($connDB){ $close = mysql_close($connDB);};
?>