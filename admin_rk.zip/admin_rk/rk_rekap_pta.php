<?php
// Data Statistik dan Pusat Pelaporan Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id/laporan
// Contact iyok642@yahoo.com, lastupdate 28 Pebruari 2014

//parameter tanggal
$bln = $_POST["bln"]*1; if($bln==""){ $bln = $_GET["bln"]*1; }
$thn = $_POST["thn"]*1; if($thn==""){ $thn = $_GET["thn"]*1; };
$view = $_POST["view"];  if($view==""){ $view = $_GET["view"]; };
$laporan = $_POST["laporan"]*1;  if($laporan==""){ $laporan = $_GET["laporan"]*1; };

//set default bulan tahun laporan
if ($bln==""){ 
	$bln = (date('m')-1)*1; $thn = date('Y')*1;
	if (date('d')>=20){ $bln = date('m')*1; }
	if ($bln==0){ $bln=12; $thn=(date('Y')-1)*1; }
};//if
if ($laporan == ""){ $laporan="$thn$bln"; };

//load setting
include_once("include.php");
include("include_login.php");

$kolom=35; $tabel = "laporan_rk3"; $title="<b>RK.3</b> - Laporan Perkara yang Diterima Pengadilan Agama"; 
if ($view == "RK.1"){ $kolom=35; $tabel="laporan_rk1"; $title="<b>RK.1</b> - Laporan Perkara Banding yang Diterima"; }
if ($view == "RK.2"){ $kolom=45; $tabel="laporan_rk2"; $title="<b>RK.2</b> - Laporan Perkara Banding yang Diputus"; }
if ($view == "RK.3"){ $kolom=35; $tabel="laporan_rk3"; $title="<b>RK.3</b> - Laporan Perkara Tk. Pertama yang Diterima"; }
if ($view == "RK.4"){ $kolom=45; $tabel="laporan_rk4"; $title="<b>RK.4</b> - Laporan Perkara Tk. Pertama yang Diputus"; }
if ($view == "RK.5"){ $kolom=19; $tabel="laporan_rk5"; $title="<b>RK.5</b> - Faktor-faktor penyebab terjadinya perceraian"; }
if (($view == "RK.5")and($thn>=2017)){ $kolom=18; $tabel="laporan_rk5new"; $title="<b>RK.5</b> - Faktor-faktor penyebab terjadinya perceraian"; }
if ($view == "RK.6"){ $kolom=20; $tabel="laporan_rk6"; $title="<b>RK.6</b> - PP No.10 Tahun 1983 jo. PP No.45 Tahun 1990"; }
if ($view == "RK.7a"){ $kolom=8; $tabel="laporan_rk7a"; $title="<b>RK.7a</b> - Rekapitulasi Keuangan Perkara"; }
if ($view == "RK.7b"){ $kolom=8; $tabel="laporan_rk7b"; $title="<b>RK.7b</b> - Rekapitulasi Keuangan Perkara Eksekusi"; }
if ($view == "RK.7c"){ $kolom=8; $tabel="laporan_rk7c"; $title="<b>RK.7c</b> - Rekapitulasi Keuangan Perkara Konsinyasi"; }
if ($view == "RK.8a"){ $kolom=9; $tabel="laporan_rk8a"; $title="<b>RK.8a</b> - Pelaksanaan Sidang Keliling"; }
if ($view == "RK.8b"){ $kolom=8; $tabel="laporan_rk8b"; $title="<b>RK.8b</b> - Pelaksanaan Prodeo"; }
if ($view == "RK.8c"){ $kolom=8; $tabel="laporan_rk8c"; $title="<b>RK.8c</b> - Pelaksanaan Posbakum"; }
if ($view == "RK.9"){ $kolom=10; $tabel="laporan_rk9"; $title="<b>RK.9</b> - Rekap Perkara Banding, Kasasi, PK, Eksekusi"; }
if ($view == "RK.10"){ $kolom=12; $tabel="laporan_rk10"; $title="<b>RK.10</b> - Rekapitulasi Mediasi"; }
if ($view == "RK.11a"){ $kolom=4; $tabel="laporan_rk11a"; $title="<b>RK.11a</b> - Hak Kepaniteraan"; }
if ($view == "RK.11b"){ $kolom=21; $tabel="laporan_rk11b"; $title="<b>RK.11b</b> - Hak Kepaniteraan Lainnya"; }
if ($view == "RK.12"){ $kolom=6; $tabel="laporan_rk12"; $title="<b>RK.12</b> - Tingkat Penyelesaian Perkara"; }
if ($view == "RK.MA"){ $kolom=12; $tabel="laporan_rkma"; $title="<b>RK.MA</b> - Rekapitulasi Perkara Diterima Diputus"; }
if ($view == "RK.ESYARIAH"){ $kolom=10; $tabel="laporan_rkesyar"; $title="<b>RK.ESyariah</b> - Laporan Ekonomi Syariah"; }
if ($view == "Pelayanan Terpadu"){ $kolom=10; $tabel="laporan_lyterpadu"; $title="<b>Pelayanan Terpadu</b> - Laporan Pelayanan Terpadu"; }
if ($view == "Register Delegasi"){ $kolom=3; $tabel="laporan_delegasi"; $title="<b>Register Delegasi Panggilan/Pemberitahuan"; }

//default id_parent
$id_parent = 12;
$runSQL = "select * from laporan_satker where id_satker='$SESS_ID_SATKER'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) { 
	if ($row[tk_satker]=="PA"){ $id_parent=$row[id_parent]; };
	if ($row[tk_satker]=="PTA"){ $id_parent=$row[id_satker]; };
};//while

//data satker
$data_satker=array();
$runSQL = "select * from laporan_satker where id_parent=$id_parent order by urutan_cetak, nm_satker";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$id_satker = $row[id_satker];
	array_push($data_satker, $id_satker);
	$nama_satker[$id_satker] = $row[nm_satker];
};//while
if (count($data_satker)>0){ $filterSQL="and (id_satker=".implode(" or id_satker=", $data_satker).")"; };

//baca data banding
$include_pta = array("RK.7a","RK.11b","RK.12");
if (in_array($view, $include_pta)){
	$runSQL = "select * from $tabel where tahun='$thn' and bulan='$bln' and id_satker='$id_parent'";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$id_satker=$row[id_satker];
		for($i=6; $i<($kolom+5); $i++){
			if ($i > 6){ $align = "align='right'"; };
			$html_pta .= "<td $align style='font-size:10px' nowrap>".currency($row[$i])."</td>";
			$total[$i] += $row[$i];
		};//for
	};//while
	$htmlbaris .= "<tr bgcolor='#CCFA9A' onmouseover='bgColor=\"#ABE159\"' onmouseout='bgColor=\"#CCFA9A\"'><td align='center' style='font-size:10px' nowrap>-</td>".$html_pta."</tr>\n"; 
};//if

//html kolom atas
for($i=1; $i<=$kolom; $i++){ $htmltop .= "<td align='center' style='font-size:8px' nowrap>$i</td>"; };//for

//baca laporan
$runSQL = "select * from $tabel where tahun='$thn' and bulan='$bln' $filterSQL";
if ($tabel=="laporan_delegasi"){ $runSQL = "select id_satker,tahun,bulan,id_session,lastupdate,kolom_1,kolom_2,kolom_3,kolom_4 from $tabel where tahun='$thn' and bulan='$bln' $filterSQL";};
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$id_satker=$row[id_satker];
	for($i=7; $i<($kolom+5); $i++){
	  if (!thisstring($row[$i])){ $align="align='right'"; }else { unset($align); };
	  $html[$id_satker] .= "<td $align style='font-size:10px' nowrap>".currency($row[$i])."</td>";
	  $total[$i] += $row[$i];
	};//for
};//while

//html isi laporan
for($i=0; $i<count($data_satker); $i++){
	$id_satker = $data_satker[$i];
	if ($html[$id_satker]==""){ $html[$id_satker]="<td colspan='".($kolom-2)."' align='center'><font size='1' color='#FF0000'>- tidak melaporkan -</td>"; }
	if ($i%2 > 0){ $color="#CCFA9A"; }else{ $color="#EEFBE1"; };
	$htmlbaris .= "<tr bgcolor='$color' onmouseover='bgColor=\"#ABE159\"' onmouseout='bgColor=\"$color\"'><td align='center' style='font-size:10px' nowrap>".($i+1)."</td><td style='font-size:10px' nowrap>".$nama_satker[$id_satker]."</td>".$html[$id_satker]."</tr>\n"; 
};//for

$arr_no_jumlah = array("RK.ESYARIAH","Pelayanan Terpadu","Register Delegasi");
if (!in_array ($view, $arr_no_jumlah)){

if ($i%2 > 0){ $color="#CCFA9A"; }else{ $color="#EEFBE1"; };
$htmlbaris .= "<tr bgcolor='$color' onmouseover='bgColor=\"#ABE159\"' onmouseout='bgColor=\"$color\"'><td align='center' style='font-size:10px' colspan='2' nowrap>Jumlah</td>";
for($i=7; $i<($kolom+5); $i++){
	$htmlbaris .= "<td align='right' style='font-size:10px' nowrap>".currency($total[$i])."</td>";
};//for
$htmlbaris .= "</tr>\n"; 
};//in_array arr_no_jumlah

?>
<html>
<head>
  <meta name="Generator" content="EditPlus">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <meta name="Description" content="Sistem Pendaftaran Perkara Secara Online Pengadilan Agama">
  <title>Laporan Perkara <? echo $bulan[($bln*1)]." ".$thn; ?></title>
  <link rel="shortcut icon" href="favicon.ico">
  <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body bgcolor="#FFFFFF">
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="35"><?=$title;?></td></tr>
  <tr bgcolor='#D1ED74' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#D1ED74"'><?=$htmltop;?></tr>
  <?=$htmlbaris;?>
</table>

</body>
</html>
<?
if ($connDB){ $close = mysql_close($connDB);};
?>