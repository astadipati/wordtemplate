<?php
// Data Statistik dan Pusat Pelaporan Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id/laporan
// Contact iyok642@yahoo.com, lastupdate 28 Pebruari 2014

//parameter tanggal
$bln = $_POST["bln"]*1; if($bln==""){ $bln = $_GET["bln"]*1; }
$thn = $_POST["thn"]*1; if($thn==""){ $thn = $_GET["thn"]*1; };
$id_satker = $_POST["id_satker"]*1; if($id_satker==""){ $id_satker = $_GET["id_satker"]*1; };

//set default bulan tahun laporan
if ($bln==""){ 
	$bln = (date('m')-1)*1; $thn = date('Y')*1;
	if (date('d')>=20){ $bln = date('m')*1; }
	if ($bln==0){ $bln=12; $thn=(date('Y')-1)*1; }
};//if
if ($laporan == ""){ $laporan="$thn$bln"; };

//load setting
include_once("include.php");
include("include_login.php");

//data satker
$view_this_satker=$SESS_ID_SATKER;
$runSQL = "select * from laporan_satker where id_satker='$SESS_ID_SATKER'";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$nm_satker_pjg = $row[nm_satker_pjg];
	if (($row[tk_satker]=="PTA")or($row[tk_satker]=="BADILAG")){ $view_this_satker=$id_satker; }
};//while

$styletop = "align='center' style='font-size:8px' nowrap";
$stylebtm = "align='center' style='font-size:10px' nowrap";
$fontbtn = "<b>";

//laporan rk.3
$runSQL = "select * from laporan_rk3 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=35; $i++){
		$htmltop_rk3 .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk3 ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td $stylebtm>$fontbtn$row[kolom_8]</td><td $stylebtm>$fontbtn$row[kolom_9]</td><td $stylebtm>$fontbtn$row[kolom_10]</td><td $stylebtm>$fontbtn$row[kolom_11]</td><td $stylebtm>$fontbtn$row[kolom_12]</td><td $stylebtm>$fontbtn$row[kolom_13]</td><td $stylebtm>$fontbtn$row[kolom_14]</td><td $stylebtm>$fontbtn$row[kolom_15]</td><td $stylebtm>$fontbtn$row[kolom_16]</td><td $stylebtm>$fontbtn$row[kolom_17]</td><td $stylebtm>$fontbtn$row[kolom_18]</td><td $stylebtm>$fontbtn$row[kolom_19]</td><td $stylebtm>$fontbtn$row[kolom_20]</td><td $stylebtm>$fontbtn$row[kolom_21]</td><td $stylebtm>$fontbtn$row[kolom_22]</td><td $stylebtm>$fontbtn$row[kolom_23]</td><td $stylebtm>$fontbtn$row[kolom_24]</td><td $stylebtm>$fontbtn$row[kolom_25]</td><td $stylebtm>$fontbtn$row[kolom_26]</td><td $stylebtm>$fontbtn$row[kolom_27]</td><td $stylebtm>$fontbtn$row[kolom_28]</td><td $stylebtm>$fontbtn$row[kolom_29]</td><td $stylebtm>$fontbtn$row[kolom_30]</td><td $stylebtm>$fontbtn$row[kolom_31]</td><td $stylebtm>$fontbtn$row[kolom_32]</td><td $stylebtm>$fontbtn$row[kolom_33]</td><td $stylebtm>$fontbtn$row[kolom_34]</td><td style='font-size:10px'>$row[kolom_35]</td>";
} else {
	$htmlbuttom_rk3 = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan rk.4
$runSQL = "select * from laporan_rk4 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=45; $i++){
		$htmltop_rk4 .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk4 ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td $stylebtm>$fontbtn$row[kolom_8]</td><td $stylebtm>$fontbtn$row[kolom_9]</td><td $stylebtm>$fontbtn$row[kolom_10]</td><td $stylebtm>$fontbtn$row[kolom_11]</td><td $stylebtm>$fontbtn$row[kolom_12]</td><td $stylebtm>$fontbtn$row[kolom_13]</td><td $stylebtm>$fontbtn$row[kolom_14]</td><td $stylebtm>$fontbtn$row[kolom_15]</td><td $stylebtm>$fontbtn$row[kolom_16]</td><td $stylebtm>$fontbtn$row[kolom_17]</td><td $stylebtm>$fontbtn$row[kolom_18]</td><td $stylebtm>$fontbtn$row[kolom_19]</td><td $stylebtm>$fontbtn$row[kolom_20]</td><td $stylebtm>$fontbtn$row[kolom_21]</td><td $stylebtm>$fontbtn$row[kolom_22]</td><td $stylebtm>$fontbtn$row[kolom_23]</td><td $stylebtm>$fontbtn$row[kolom_24]</td><td $stylebtm>$fontbtn$row[kolom_25]</td><td $stylebtm>$fontbtn$row[kolom_26]</td><td $stylebtm>$fontbtn$row[kolom_27]</td><td $stylebtm>$fontbtn$row[kolom_28]</td><td $stylebtm>$fontbtn$row[kolom_29]</td><td $stylebtm>$fontbtn$row[kolom_30]</td><td $stylebtm>$fontbtn$row[kolom_31]</td><td $stylebtm>$fontbtn$row[kolom_32]</td><td $stylebtm>$fontbtn$row[kolom_33]</td><td $stylebtm>$fontbtn$row[kolom_34]</td><td $stylebtm>$fontbtn$row[kolom_35]</td><td $stylebtm>$fontbtn$row[kolom_36]</td><td $stylebtm>$fontbtn$row[kolom_37]</td><td $stylebtm>$fontbtn$row[kolom_38]</td><td $stylebtm>$fontbtn$row[kolom_39]</td><td $stylebtm>$fontbtn$row[kolom_40]</td><td $stylebtm>$fontbtn$row[kolom_41]</td><td $stylebtm>$fontbtn$row[kolom_42]</td><td $stylebtm>$fontbtn$row[kolom_43]</td><td $stylebtm>$fontbtn$row[kolom_44]</td><td style='font-size:10px'>$row[kolom_45]</td>";
} else {
	$htmlbuttom_rk4 = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan rk.5
if ($thn >= 2017){
$runSQL = "select * from laporan_rk5new where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=18; $i++){
		$htmltop_rk5 .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk5 ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td $stylebtm>$fontbtn$row[kolom_8]</td><td $stylebtm>$fontbtn$row[kolom_9]</td><td $stylebtm>$fontbtn$row[kolom_10]</td><td $stylebtm>$fontbtn$row[kolom_11]</td><td $stylebtm>$fontbtn$row[kolom_12]</td><td $stylebtm>$fontbtn$row[kolom_13]</td><td $stylebtm>$fontbtn$row[kolom_14]</td><td $stylebtm>$fontbtn$row[kolom_15]</td><td $stylebtm>$fontbtn$row[kolom_16]</td><td $stylebtm>$fontbtn$row[kolom_17]</td><td $stylebtm>$fontbtn$row[kolom_18]</td>";
} else {
	$htmlbuttom_rk5 = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if
} else {
$runSQL = "select * from laporan_rk5 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=19; $i++){
		$htmltop_rk5 .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk5 ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td $stylebtm>$fontbtn$row[kolom_8]</td><td $stylebtm>$fontbtn$row[kolom_9]</td><td $stylebtm>$fontbtn$row[kolom_10]</td><td $stylebtm>$fontbtn$row[kolom_11]</td><td $stylebtm>$fontbtn$row[kolom_12]</td><td $stylebtm>$fontbtn$row[kolom_13]</td><td $stylebtm>$fontbtn$row[kolom_14]</td><td $stylebtm>$fontbtn$row[kolom_15]</td><td $stylebtm>$fontbtn$row[kolom_16]</td><td $stylebtm>$fontbtn$row[kolom_17]</td><td $stylebtm>$fontbtn$row[kolom_18]</td><td style='font-size:10px'>$row[kolom_19]</td>";
} else {
	$htmlbuttom_rk5 = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if
};//if-tahun

//laporan rk.6
$runSQL = "select * from laporan_rk6 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=20; $i++){
		$htmltop_rk6 .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk6 ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td $stylebtm>$fontbtn$row[kolom_8]</td><td $stylebtm>$fontbtn$row[kolom_9]</td><td $stylebtm>$fontbtn$row[kolom_10]</td><td $stylebtm>$fontbtn$row[kolom_11]</td><td $stylebtm>$fontbtn$row[kolom_12]</td><td $stylebtm>$fontbtn$row[kolom_13]</td><td $stylebtm>$fontbtn$row[kolom_14]</td><td $stylebtm>$fontbtn$row[kolom_15]</td><td $stylebtm>$fontbtn$row[kolom_16]</td><td $stylebtm>$fontbtn$row[kolom_17]</td><td $stylebtm>$fontbtn$row[kolom_18]</td><td $stylebtm>$fontbtn$row[kolom_19]</td><td style='font-size:10px'>$row[kolom_20]</td>";
} else {
	$htmlbuttom_rk6 = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan rk.7a
$runSQL = "select * from laporan_rk7a where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=8; $i++){
		$htmltop_rk7a .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk7a ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td style='font-size:10px'>$row[kolom_8]</td>";
} else {
	$htmlbuttom_rk7a = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan rk.7b
$runSQL = "select * from laporan_rk7b where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=8; $i++){
		$htmltop_rk7b .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk7b ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td style='font-size:10px'>$row[kolom_8]</td>";
} else {
	$htmlbuttom_rk7b = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan rk.7c
$runSQL = "select * from laporan_rk7c where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=8; $i++){
		$htmltop_rk7c .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk7c ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td style='font-size:10px'>$row[kolom_8]</td>";
} else {
	$htmlbuttom_rk7c = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan rk.8a
$runSQL = "select * from laporan_rk8a where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=9; $i++){
		$htmltop_rk8a .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk8a ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td $stylebtm>$fontbtn$row[kolom_8]</td><td $stylebtm>$fontbtn$row[kolom_9]</td>";
} else {
	$htmlbuttom_rk8a = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan rk.8b
$runSQL = "select * from laporan_rk8b where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=8; $i++){
		$htmltop_rk8b .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk8b ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td $stylebtm>$fontbtn$row[kolom_8]</td>";
} else {
	$htmlbuttom_rk8b = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan rk.8c
$runSQL = "select * from laporan_rk8c where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=8; $i++){
		$htmltop_rk8c .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk8c ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td $stylebtm>$fontbtn$row[kolom_8]</td>";
} else {
	$htmlbuttom_rk8c = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan rk.9
$runSQL = "select * from laporan_rk9 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=10; $i++){
		$htmltop_rk9 .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk9 ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td $stylebtm>$fontbtn$row[kolom_8]</td><td $stylebtm>$fontbtn$row[kolom_9]</td><td $stylebtm>$fontbtn$row[kolom_10]</td>";
} else {
	$htmlbuttom_rk9 = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan rk.10
$runSQL = "select * from laporan_rk10 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=12; $i++){
		$htmltop_rk10 .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk10 ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td $stylebtm>$fontbtn$row[kolom_8]</td><td $stylebtm>$fontbtn$row[kolom_9]</td><td $stylebtm>$fontbtn$row[kolom_10]</td><td $stylebtm>$fontbtn$row[kolom_11]</td><td $stylebtm>$fontbtn$row[kolom_12]</td>";
} else {
	$htmlbuttom_rk10 = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan rk.11a
$runSQL = "select * from laporan_rk11a where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=4; $i++){
		$htmltop_rk11a .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk11a ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td>";
} else {
	$htmlbuttom_rk11a = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan rk.11b
$runSQL = "select * from laporan_rk11b where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=2; $i++){
		$htmltop_rk11b .= "<td $styletop>$i</td>";
	};//for
	for($i=5; $i<=23; $i++){
		$htmltop_rk11b .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk11b ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td $stylebtm>$fontbtn$row[kolom_8]</td><td $stylebtm>$fontbtn$row[kolom_9]</td><td $stylebtm>$fontbtn$row[kolom_10]</td><td $stylebtm>$fontbtn$row[kolom_11]</td><td $stylebtm>$fontbtn$row[kolom_12]</td><td $stylebtm>$fontbtn$row[kolom_13]</td><td $stylebtm>$fontbtn$row[kolom_14]</td><td $stylebtm>$fontbtn$row[kolom_15]</td><td $stylebtm>$fontbtn$row[kolom_16]</td><td $stylebtm>$fontbtn$row[kolom_17]</td><td $stylebtm>$fontbtn$row[kolom_18]</td><td $stylebtm>$fontbtn$row[kolom_19]</td><td $stylebtm>$fontbtn$row[kolom_20]</td><td $stylebtm>$fontbtn$row[kolom_21]</td>";
} else {
	$htmlbuttom_rk11b = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan rk.12
$runSQL = "select * from laporan_rk12 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=6; $i++){
		$htmltop_rk12 .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rk12 ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td>";
} else {
	$htmlbuttom_rk12 = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan rk.ma
$runSQL = "select * from laporan_rkma where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=12; $i++){
		$htmltop_rkma .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rkma ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td $stylebtm>$fontbtn$row[kolom_8]</td><td $stylebtm>$fontbtn$row[kolom_9]</td><td $stylebtm>$fontbtn$row[kolom_10]</td><td $stylebtm>$fontbtn$row[kolom_11]</td><td $stylebtm>$fontbtn$row[kolom_12]</td>";
} else {
	$htmlbuttom_rkma = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan rk.ekonomi syariah
$runSQL = "select * from laporan_rkesyar where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) {
	for($i=1; $i<=10; $i++){
		$htmltop_rkesyar .= "<td $styletop>$i</td>";
	};//for
	$htmlbuttom_rkesyar ="<td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td $stylebtm>$fontbtn$row[kolom_8]</td><td $stylebtm>$fontbtn$row[kolom_9]</td><td $stylebtm>$fontbtn$row[kolom_10]</td>";
} else {
	$htmlbuttom_rkesyar = "<td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td>";
};//if

//laporan layanan terpadu
$ccc = 0;
$runSQL = "select * from laporan_lyterpadu where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	if ($ccc == 0){
		for($i=1; $i<=10; $i++){
			$htmltop_lyterpadu .= "<td $styletop>$i</td>";
		};//for
	};//if
	$ccc++;
	$htmlbuttom_lyterpadu .="<tr bgcolor='#CCFA9A' onmouseover='bgColor=\"#ABE159\"' onmouseout='bgColor=\"#CCFA9A\"'><td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td $stylebtm>$fontbtn$row[kolom_8]</td><td $stylebtm>$fontbtn$row[kolom_9]</td><td $stylebtm>$fontbtn$row[kolom_10]</td></tr>";
};//while

if ($htmltop_lyterpadu == ""){
	$htmlbuttom_lyterpadu = "<tr bgcolor='#CCFA9A' onmouseover='bgColor=\"#ABE159\"' onmouseout='bgColor=\"#CCFA9A\"'><td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td></tr>";
};//if

//laporan delegasi
/*
$ccc = 0;
$runSQL = "select id_satker, tahun, bulan, id_session, lastupdate, kolom_1, kolom_2, kolom_3, kolom_4, date_format(kolom_5,'%d-%m-%Y') kolom_5,  date_format(kolom_6,'%d-%m-%Y') kolom_6, kolom_7 as kolom_7srt, date_format(kolom_7,'%d-%m-%Y') kolom_7, date_format(kolom_8,'%d-%m-%Y') kolom_8, date_format(kolom_9,'%d-%m-%Y') kolom_9, kolom_10, kolom_11, kolom_12 from laporan_delegasi where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln' order by kolom_7srt";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	if ($ccc == 0){
		for($i=1; $i<=11; $i++){
			$htmltop_delegasi .= "<td $styletop>$i</td>";
		};//for
	};//if
	$ccc++;
	$htmlbuttom_delegasi .="<tr bgcolor='#CCFA9A' onmouseover='bgColor=\"#ABE159\"' onmouseout='bgColor=\"#CCFA9A\"'><td $stylebtm>$fontbtn$row[kolom_1]</td><td $stylebtm>$fontbtn<b>$row[kolom_2]</td><td $stylebtm>$fontbtn$row[kolom_3]</td><td $stylebtm>$fontbtn$row[kolom_4]</td><td $stylebtm>$fontbtn$row[kolom_5]</td><td $stylebtm>$fontbtn$row[kolom_6]</td><td $stylebtm>$fontbtn$row[kolom_7]</td><td $stylebtm>$fontbtn$row[kolom_8]</td><td $stylebtm>$fontbtn$row[kolom_9]</td><td $stylebtm>$fontbtn$row[kolom_10]</td><td $stylebtm>$fontbtn$row[kolom_11]</td></tr>";
};//while
*/

$runSQL = "select count(*) jml_delegasi from laporan_delegasi where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$htmltop_delegasi .= "<td $styletop>1</td><td $styletop>2</td>";
	$htmlbuttom_delegasi .="<tr bgcolor='#CCFA9A' onmouseover='bgColor=\"#ABE159\"' onmouseout='bgColor=\"#CCFA9A\"'><td $stylebtm>Jumlah delegasi diterima bulan ".$bulan[$bln*1]." $thn </td><td $stylebtm>$fontbtn<b>$row[jml_delegasi]</td></tr>";
};//while

if ($htmltop_delegasi == ""){
	$htmlbuttom_delegasi = "<tr bgcolor='#CCFA9A' onmouseover='bgColor=\"#ABE159\"' onmouseout='bgColor=\"#CCFA9A\"'><td $stylebtm bgcolor='#FF0000'> <font color='#FFFF00'>-- Tidak Melaporkan --</blink> </td></tr>";
};//if

?>
<html>
<head>
  <meta name="Generator" content="EditPlus">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <meta name="Description" content="Sistem Pendaftaran Perkara Secara Online Pengadilan Agama">
  <title>Laporan Perkara <? echo $bulan[($bln*1)]." ".$thn; ?></title>
  <link rel="shortcut icon" href="favicon.ico">
  <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body bgcolor="#FFFFFF">
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="35"><b>Laporan RK.3</b> : Perkara yang Diterima Pengadilan Agama</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rk3;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rk3;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="45"><b>Laporan RK.4</b> : Perkara yang Diputus Pengadilan Agama</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rk4;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rk4;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="19"><b>Laporan RK.5</b> : Faktor-faktor penyebab terjadinya perceraian</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rk5;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rk5;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="20"><b>Laporan RK.6</b> : PP No.10 Tahun 1983 jo. PP No.45 Tahun 1990</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rk6;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rk6;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="20"><b>Laporan RK.7a</b> : Rekapitulasi Keuangan Perkara</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rk7a;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rk7a;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="20"><b>Laporan RK.7b</b> : Rekapitulasi Keuangan Perkara Eksekusi</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rk7b;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rk7b;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="20"><b>Laporan RK.7c</b> : Rekapitulasi Keuangan Perkara Konsinyasi</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rk7c;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rk7c;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="20"><b>Laporan RK.8a</b> : Pelaksanaan Sidang Keliling</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rk8a;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rk8a;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="20"><b>Laporan RK.8b</b> : Pelaksanaan Prodeo</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rk8b;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rk8b;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="20"><b>Laporan RK.8c</b> : Pelaksanaan Posbakum</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rk8c;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rk8c;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="20"><b>Laporan RK.9</b> : Rekap Perkara Banding, Kasasi, PK, Eksekusi</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rk9;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rk9;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="20"><b>Laporan RK.10</b> : Rekapitulasi Mediasi</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rk10;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rk10;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="20"><b>Laporan RK.11a</b> : Hak Kepaniteraan</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rk11a;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rk11a;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="21"><b>Laporan RK.11b</b> : Hak Kepaniteraan Lainnya</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rk11b;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rk11b;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="21"><b>Laporan RK.12</b> : Tingkat Penyelesaian Perkara</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rk12;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rk12;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="21"><b>Laporan RK.MA</b> : Rekapitulasi Perkara Diterima Diputus</td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rkma;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rkma;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="21"><b>Laporan RK.Ekonomi Syariah</b></td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_rkesyar;?></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmlbuttom_rkesyar;?></tr>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="21"><b>Laporan Pelayanan Terpadu</b></td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_lyterpadu;?></tr>
  <?=$htmlbuttom_lyterpadu;?>
</table>
<br>
<table border="0" cellpadding="5" cellspacing="1">
  <tr><td bgcolor='#339900' width="100%" colspan="21"><b>Registrasi Delegasi Panggilan/Pemberitahuan</b></td></tr>
  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'><?=$htmltop_delegasi;?></tr>
  <?=$htmlbuttom_delegasi;?>
</table>
</body>
</html>
<?
if ($connDB){ $close = mysql_close($connDB);};
?>