<?php
if (! function_exists('DMY2YMD')) {
    function DMY2YMD($tgl, $separator)  {
        $arr = explode($separator, $tgl);
        if (count($arr)==3) {
            return sprintf('%s%s%s%s%s', $arr[2], $separator, $arr[1], $separator, $arr[0]);
        } else {
            return $tgl;
        }
    }
}

	require_once('conn.php');
	require_once('nusoap.php');
	$server = new soap_server();
	$server->configureWSDL(NAMA_PA, 'urn:'.NAMA_PA);

	/************************
	 frekuensi update portal
	 ************************/
	$server->register(
		'getFreqUpdatePortal',                            
		array('tahun' => 'xsd:int', 'bulan' => 'xsd:int'),      
		array('return' => 'xsd:string'),    
		'urn:'.NAMA_PA,                   
		'urn:'.NAMA_PA.'#getFreqUpdatePortal',   
		'rpc',                             
		'encoded',                         
		'<br><blockquote>Data Frequensi Update Portal<br>
			From : Portal PA<br><br>
			To : Portal PTA<br><br>
			Info :<br><br>
			Input : PHP indexed-array<br>
			<blockquote>[tahun] => integer (misal: 2009)<br>
			[bulan] => integer (misal: 6 untuk bulan Juni)<br></blockquote>
			Output : delimiter string --> t1:j1|t2:j2|dst...<br>
			</blockquote></blockquote>'
	);

	function getFreqUpdatePortal($tahun, $bulan) {
		$link = mysql_connect('localhost', NAMA_USER, NAMA_PASS);
		if (!$link) { return -1; }

		$db_selected = mysql_select_db(NAMA_DB, $link);
		if (!$db_selected) { return -2; }
		
		$ret = '';
		$jum_hari = date('t', mktime(0,0,0,$bulan,0,$tahun));
		for ($i=1; $i<=$jum_hari; $i++) {
			$sql = "SELECT COUNT(idpta_berita) as JUM FROM pta_berita WHERE DAY(tgl_dibuat)=$i AND MONTH(tgl_dibuat)=$bulan AND YEAR(tgl_dibuat)=$tahun";
			$q = mysql_query($sql);
			if ($r = mysql_fetch_object($q)) {
				$jum = $r->JUM;
			} else {
				$jum = 0;
			}
			
			$sql = "SELECT COUNT(idpta_artikel) as JUM FROM pta_artikel WHERE DAY(tgl_artikel)=$i AND MONTH(tgl_artikel)=$bulan AND YEAR(tgl_artikel)=$tahun";
			$q = mysql_query($sql);
			if ($r = mysql_fetch_object($q)) {
				$jum += $r->JUM;
			}
			
			$sql = "SELECT COUNT(idpta_arsip) as JUM FROM pta_arsip WHERE DAY(tgl_input)=$i AND MONTH(tgl_input)=$bulan AND YEAR(tgl_input)=$tahun";
			$q = mysql_query($sql);
			if ($r = mysql_fetch_object($q)) {
				$jum += $r->JUM;
			}
			
			$ret = $ret . $i.':'.$jum.'|';
		}
		$ret = substr($ret, 0, -1);
				
		return $ret;
	}

	
	/************************
	 frekuensi total update portal
	 ************************/
	$server->register(
		'getFreqTotUpdatePortal',                            
		array('tahun' => 'xsd:int', 'bulan' => 'xsd:int'),      
		array('return' => 'xsd:int'),    
		'urn:'.NAMA_PA,                   
		'urn:'.NAMA_PA.'#getFreqTotUpdatePortal',   
		'rpc',                             
		'encoded',                         
		'<br><blockquote>Data Frequensi Total Update Portal<br>
			From : Portal PA<br><br>
			To : Portal PTA<br><br>
			Info :<br><br>
			Input : PHP indexed-array<br>
			<blockquote>[tahun] => integer (misal: 2009)<br>
			[bulan] => integer (misal: 6 untuk bulan Juni)<br></blockquote>
			Output : integer <br>
			</blockquote></blockquote>'
	);

	function getFreqTotUpdatePortal($tahun, $bulan) {
		$link = mysql_connect('localhost', NAMA_USER, NAMA_PASS);
		if (!$link) { return -1; }

		$db_selected = mysql_select_db(NAMA_DB, $link);
		if (!$db_selected) { return -2; }
		
		$sql = "SELECT COUNT(idpta_berita) as JUM FROM pta_berita WHERE MONTH(tgl_dibuat)=$bulan AND YEAR(tgl_dibuat)=$tahun";
		$q = mysql_query($sql);
		if ($r = mysql_fetch_object($q)) {
			$jum = $r->JUM;
		} else {
			$jum = 0;
		}
		
		$sql = "SELECT COUNT(idpta_artikel) as JUM FROM pta_artikel WHERE MONTH(tgl_artikel)=$bulan AND YEAR(tgl_artikel)=$tahun";
		$q = mysql_query($sql);
		if ($r = mysql_fetch_object($q)) {
			$jum += $r->JUM;
		}
		
		$sql = "SELECT COUNT(idpta_arsip) as JUM FROM pta_arsip WHERE MONTH(tgl_input)=$bulan AND YEAR(tgl_input)=$tahun";
		$q = mysql_query($sql);
		if ($r = mysql_fetch_object($q)) {
			$jum += $r->JUM;
		}
		
		return $jum;
	}

	/************************
	 push data statistik
	 ************************/
	$server->register(
		'saveStatPerJenisPerkara',                            
		array('param' => 'xsd:string'),      
		array('return' => 'xsd:int'),    
		'urn:'.NAMA_PA,                   
		'urn:'.NAMA_PA.'#saveStatPerJenisPerkara',   
		'rpc',                             
		'encoded',                         
		'<br><blockquote>Push Data Statistik per Jenis Perkara<br>
			From : Portal PA<br><br>
			To : Portal PTA<br><br>
			Info :<br><br>
			Input : PHP indexed-array<br>
			<blockquote>json_encoded data<br></blockquote>
			Output : integer <br>
			</blockquote></blockquote>'
	);

	function saveStatPerJenisPerkara($param) {
		$param = json_decode($param, true);
		$bulan = $param['bulan'];
		$tahun = $param['tahun'];
		$data  = $param['data'];
		$is_new = false;
		
		$link = mysql_connect('localhost', NAMA_USER, NAMA_PASS);
		if (!$link) { return -1; }

		$db_selected = mysql_select_db(NAMA_DB, $link);
		if (!$db_selected) { return -2; }

		$sql = "select id from `pta_stat_jenis_perkara_master` where tahun='$tahun'";
		$q = mysql_query($sql);
		if (mysql_num_rows($q) > 0) {
			if ($r=mysql_fetch_array($q)) {
				$id = $r[0];
			} else {
				$id = 0;
			}
		} else {
			$sql = "insert into `pta_stat_jenis_perkara_master` (tahun) values ('$tahun')";
			$q = mysql_query($sql);
			if ($q) {
				$id = mysql_insert_id();
				$is_new = true;
			} else {
				$id = 0;
			}
		}
		
		$is_update = false;
		if ($id > 0) {
			if (!$is_new) {
				$sql = "select count(*) from `pta_stat_jenis_perkara` where bulan='$bulan' and master_id='$id'";
				$q = mysql_query($sql);
				if ($r = mysql_fetch_array($q)) {
					$is_update = $r[0] > 0;
				}
			}
			
			foreach ($data as $k => $v) {
				if ($is_update) {
					$sql = sprintf("update `pta_stat_jenis_perkara` set jumlah='%d' 
									where   master_id='%d' and bulan='%d' and perkara='%s' and abbr='%s'", 
						   $v['jumlah'], $id, $bulan, $v['jenis_perkara'], $v['abbr']);
				} else {
					$sql = sprintf("insert into `pta_stat_jenis_perkara` (master_id,bulan,perkara,abbr,jumlah) 
						values ('%d', '%d', '%s', '%s', '%d')", $id, $bulan, $v['jenis_perkara'], $v['abbr'], $v['jumlah']);
				}
				mysql_unbuffered_query($sql);
			}
			
			if ($is_update) {
				$sql = sprintf("update `pta_stat_jenis_perkara_master` set waktupencatatan=NOW() 
								where   tahun='%d' ", $tahun);
				mysql_unbuffered_query($sql);
			}
		}
		return $r;
	}
	
	$server->register(
		'saveStatPerUsiaPenggugat',                            
		array('param' => 'xsd:string'),      
		array('return' => 'xsd:int'),    
		'urn:'.NAMA_PA,                   
		'urn:'.NAMA_PA.'#saveStatPerUsiaPenggugat',   
		'rpc',                             
		'encoded',                         
		'<br><blockquote>Push Data Statistik per Usia Penggugat<br>
			From : Portal PA<br><br>
			To : Portal PTA<br><br>
			Info :<br><br>
			Input : PHP indexed-array<br>
			<blockquote>json_encoded data<br></blockquote>
			Output : integer <br>
			</blockquote></blockquote>'
	);

	function saveStatPerUsiaPenggugat($param) {
		$param = json_decode($param, true);
		$bulan = $param['bulan'];
		$tahun = $param['tahun'];
		$data  = $param['data'];
		$is_new = false;
		
		$link = mysql_connect('localhost', NAMA_USER, NAMA_PASS);
		if (!$link) { return -1; }

		$db_selected = mysql_select_db(NAMA_DB, $link);
		if (!$db_selected) { return -2; }

		$sql = "select id from `pta_stat_umur_master` where tahun='$tahun' and pete='P'";
		$q = mysql_query($sql);
		if (mysql_num_rows($q) > 0) {
			if ($r=mysql_fetch_array($q)) {
				$id = $r[0];
			} else {
				$id = 0;
			}
		} else {
			$sql = "insert into `pta_stat_umur_master` (tahun,pete) values ('$tahun','P')";
			$q = mysql_query($sql);
			if ($q) {
				$id = mysql_insert_id();
				$is_new = true;
			} else {
				$id = 0;
			}
		}
		
		$is_update = false;
		if ($id>0) {
			if (!$is_new) {
				$sql = "select count(*) from `pta_stat_umur` where bulan='$bulan' and master_id='$id'";
				$q = mysql_query($sql);
				if ($r = mysql_fetch_array($q)) {
					$is_update = $r[0] > 0;
				}
			}
			
			if ($is_update) {
				$sql = sprintf("update `pta_stat_umur` set usia0='%d',usia1='%d',usia2='%d',usia3='%d',usia4='%d',usia5='%d' 
					where master_id='%d' and bulan='%d'", 
					$data['usia0'], $data['usia1'], $data['usia2'], $data['usia3'], $data['usia4'], $data['usia5'], $id, $bulan);
				mysql_unbuffered_query($sql);
					
				$sql = sprintf("update `pta_stat_umur_master` set waktupencatatan=NOW() 
								where   pete='P' and tahun='%d' ", $tahun);
				mysql_unbuffered_query($sql);
			} else {
				$sql = sprintf("insert into `pta_stat_umur` (master_id,bulan,usia0,usia1,usia2,usia3,usia4,usia5) 
					values ('%d', '%d', '%d', '%d', '%d', '%d', '%d', '%d')", 
					$id, $bulan, $data['usia0'], $data['usia1'], $data['usia2'], $data['usia3'], $data['usia4'], $data['usia5']);
				mysql_unbuffered_query($sql);
			}
		}
		return $r;
	}
	
	$server->register(
		'saveStatPerPekerjaanPenggugat',                            
		array('param' => 'xsd:string'),      
		array('return' => 'xsd:int'),    
		'urn:'.NAMA_PA,                   
		'urn:'.NAMA_PA.'#saveStatPerPekerjaanPenggugat',   
		'rpc',                             
		'encoded',                         
		'<br><blockquote>Push Data Statistik per Pekerjaan Penggugat<br>
			From : Portal PA<br><br>
			To : Portal PTA<br><br>
			Info :<br><br>
			Input : PHP indexed-array<br>
			<blockquote>json_encoded data<br></blockquote>
			Output : integer <br>
			</blockquote></blockquote>'
	);

	function saveStatPerPekerjaanPenggugat($param) {
		$param = json_decode($param, true);
		$bulan = $param['bulan'];
		$tahun = $param['tahun'];
		$data  = $param['data'];
		$is_new = false;
		
		$link = mysql_connect('localhost', NAMA_USER, NAMA_PASS);
		if (!$link) { return -1; }

		$db_selected = mysql_select_db(NAMA_DB, $link);
		if (!$db_selected) { return -2; }

		$sql = "select id from `pta_stat_pekerjaan_master` where tahun='$tahun' and pete='P'";
		$q = mysql_query($sql);
		if (mysql_num_rows($q) > 0) {
			if ($r=mysql_fetch_array($q)) {
				$id = $r[0];
			} else {
				$id = 0;
			}
		} else {
			$sql = "insert into `pta_stat_pekerjaan_master` (pete,tahun) values ('P', '$tahun')";
			$q = mysql_query($sql);
			if ($q) {
				$id = mysql_insert_id();
				$is_new = true;
			} else {
				$id = 0;
			}
		}
		
		$is_update = false;
		if ($id > 0) {
			if (!$is_new) {
				$sql = "select count(*) from `pta_stat_pekerjaan` where bulan='$bulan' and master_id='$id'";
				$q = mysql_query($sql);
				if ($r = mysql_fetch_array($q)) {
					$is_update = $r[0] > 0;
				}
			}
			
			foreach ($data as $k => $v) {
				if ($is_update) {
					$sql = sprintf("update `pta_stat_pekerjaan` set jumlah='%d' 
									where   master_id='%d' and bulan='%d' and pekerjaan='%s' and abbr='%s'", 
						   $v['jumlah'], $id, $bulan, $v['pekerjaan'], $v['abbr']);
				} else {
					$sql = sprintf("insert into `pta_stat_pekerjaan` (master_id,bulan,pekerjaan,abbr,jumlah) 
						values ('%d', '%d', '%s', '%s', '%d')", $id, $bulan, $v['pekerjaan'], $v['abbr'], $v['jumlah']);
				}
				mysql_unbuffered_query($sql);
			}
			
			if ($is_update) {
				$sql = sprintf("update `pta_stat_pekerjaan_master` set waktupencatatan=NOW() 
								where   pete='P' and tahun='%d' ", $tahun);
				mysql_unbuffered_query($sql);
			}
		}
		return $r;
	}

	$server->register(
		'savePerkaraMasukTerbaru',                            
		array('param' => 'xsd:string'),      
		array('return' => 'xsd:int'),    
		'urn:'.NAMA_PA,                   
		'urn:'.NAMA_PA.'#savePerkaraMasukTerbaru',   
		'rpc',                             
		'encoded',                         
		'<br><blockquote>Push Data Perkara Masuk Terbaru<br>
			From : Portal PA<br><br>
			To : Portal PTA<br><br>
			Info :<br><br>
			Input : PHP indexed-array<br>
			<blockquote>json_encoded data<br></blockquote>
			Output : integer <br>
			</blockquote></blockquote>'
	);

	function savePerkaraMasukTerbaru($param) {
		$param = json_decode($param, true);
		$data  = $param['data'];
		$is_new = false;
		
		$link = mysql_connect('localhost', NAMA_USER, NAMA_PASS);
		if (!$link) { return -1; }

		$db_selected = mysql_select_db(NAMA_DB, $link);
		if (!$db_selected) { return -2; }

		$sql = "TRUNCATE TABLE `pta_perkara_masuk_terbaru`";
		mysql_unbuffered_query($sql);
			
		foreach ($data as $k => $v) {
			$sql = sprintf("insert into `pta_perkara_masuk_terbaru` (`noreg`, `tgl_daftar`, `jenis_perkara`, `ket_jenis_perkara`, `sebab_cerai`, `waktupencatatan`) 
				values ('%s', '%s', '%s', '%s', '%s', CURRENT_TIMESTAMP)", $v['nomor'], $v['tanggal'], $v['jenis_perkara'], $v['ket_jenis_perkara'], $v['sebab']);
			mysql_unbuffered_query($sql);
		}
			
		return $r;
	}
	
	$server->register(
		'savePerkaraMasuk',
		array('param' => 'xsd:string'),      
		array('return' => 'xsd:int'),    
		'urn:'.NAMA_PA,                   
		'urn:'.NAMA_PA.'#savePerkaraMasuk',   
		'rpc',                             
		'encoded',                         
		'<br><blockquote>Push Data Perkara Masuk<br>
			From : Portal PA<br><br>
			To : Portal PTA<br><br>
			Info :<br><br>
			Input : PHP indexed-array<br>
			<blockquote>json_encoded data<br></blockquote>
			Output : integer <br>
			</blockquote></blockquote>'
	);

	function savePerkaraMasuk($param) {
		$param = json_decode($param, true);
		$data  = $param['data'];
		$bulan = $param['bulan'];
		$tahun = $param['tahun'];
		
		$link = mysql_connect('localhost', NAMA_USER, NAMA_PASS);
		if (!$link) { return -1; }

		$db_selected = mysql_select_db(NAMA_DB, $link);
		if (!$db_selected) { return -2; }

		$sql = "DELETE FROM `pta_perkara_masuk_terbaru` WHERE MONTH(STR_TO_DATE( `tgl_daftar` , '%d/%m/%Y' ))=$bulan AND YEAR(STR_TO_DATE( `tgl_daftar` , '%d/%m/%Y' ))=$tahun";
		mysql_unbuffered_query($sql);
			
		foreach ($data as $k => $v) {
			$sql = sprintf("insert into `pta_perkara_masuk_terbaru` (`noreg`, `tgl_daftar`, `jenis_perkara`, `ket_jenis_perkara`, `sebab_cerai`, `waktupencatatan`) 
				values ('%s', '%s', '%s', '%s', '%s', CURRENT_TIMESTAMP)", $v['nomor'], $v['tanggal'], $v['jenis_perkara'], $v['ket_jenis_perkara'], $v['sebab']);
			mysql_unbuffered_query($sql);
		}
			
		return $r;
	}
	
	$server->register(
		'savePerkaraPutusTerbaru',                            
		array('param' => 'xsd:string'),      
		array('return' => 'xsd:int'),    
		'urn:'.NAMA_PA,                   
		'urn:'.NAMA_PA.'#savePerkaraPutusTerbaru',   
		'rpc',                             
		'encoded',                         
		'<br><blockquote>Push Data Perkara Masuk Terbaru<br>
			From : Portal PA<br><br>
			To : Portal PTA<br><br>
			Info :<br><br>
			Input : PHP indexed-array<br>
			<blockquote>json_encoded data<br></blockquote>
			Output : integer <br>
			</blockquote></blockquote>'
	);

	function savePerkaraPutusTerbaru($param) {
		$param = json_decode($param, true);
		$data  = $param['data'];
		$is_new = false;
		
		$link = mysql_connect('localhost', NAMA_USER, NAMA_PASS);
		if (!$link) { return -1; }

		$db_selected = mysql_select_db(NAMA_DB, $link);
		if (!$db_selected) { return -2; }

		$sql = "TRUNCATE TABLE `pta_perkara_putus_terbaru`";
		mysql_unbuffered_query($sql);
			
		foreach ($data as $k => $v) {
			$sql = sprintf("insert into `pta_perkara_putus_terbaru` (`noreg`, `tgl_daftar`, `tgl_putusan`, `tgl_sidang`, `waktupencatatan`) 
				values ('%s', '%s', '%s', '%s', CURRENT_TIMESTAMP)", $v['nomor'], $v['tgl_register'], $v['tgl_putusan'], $v['tgl_sidang']);
			mysql_unbuffered_query($sql);
		}
			
		return $r;
	}
	
	$server->register(
		'savePerkaraPutus',                            
		array('param' => 'xsd:string'),      
		array('return' => 'xsd:int'),    
		'urn:'.NAMA_PA,                   
		'urn:'.NAMA_PA.'#savePerkaraPutus',   
		'rpc',                             
		'encoded',                         
		'<br><blockquote>Push Data Perkara Putus<br>
			From : Portal PA<br><br>
			To : Portal PTA<br><br>
			Info :<br><br>
			Input : PHP indexed-array<br>
			<blockquote>json_encoded data<br></blockquote>
			Output : integer <br>
			</blockquote></blockquote>'
	);

	function savePerkaraPutus($param) {
		$param = json_decode($param, true);
		$data  = $param['data'];
		$bulan = $param['bulan'];
		$tahun = $param['tahun'];
		
		$link = mysql_connect('localhost', NAMA_USER, NAMA_PASS);
		if (!$link) { return -1; }

		$db_selected = mysql_select_db(NAMA_DB, $link);
		if (!$db_selected) { return -2; }

		$sql = "DELETE TABLE `pta_perkara_putus_terbaru` WHERE MONTH(STR_TO_DATE( `tgl_putusan` , '%d/%m/%Y' ))=$bulan AND YEAR(STR_TO_DATE( `tgl_putusan` , '%d/%m/%Y' ))=$tahun";
		mysql_unbuffered_query($sql);
			
		foreach ($data as $k => $v) {
			$sql = sprintf("insert into `pta_perkara_putus_terbaru` (`noreg`, `tgl_daftar`, `tgl_putusan`, `tgl_sidang`, `waktupencatatan`) 
				values ('%s', '%s', '%s', '%s', CURRENT_TIMESTAMP)", $v['nomor'], $v['tgl_register'], $v['tgl_putusan'], $v['tgl_sidang']);
			mysql_unbuffered_query($sql);
		}
			
		return $r;
	}
	
	$server->register(
		'savePerkaraPekerjaan',                            
		array('param' => 'xsd:string'),      
		array('return' => 'xsd:int'),    
		'urn:'.NAMA_PA,                   
		'urn:'.NAMA_PA.'#savePerkaraPekerjaan',   
		'rpc',                             
		'encoded',                         
		'<br><blockquote>Push Rekap Perkara per Pekerjaan Pe<br>
			From : Portal PA<br><br>
			To : Portal PTA<br><br>
			Info :<br><br>
			Input : PHP indexed-array<br>
			<blockquote>json_encoded data<br></blockquote>
			Output : integer <br>
			</blockquote></blockquote>'
	);

	function savePerkaraPekerjaan($param) {
		$param = json_decode($param, true);
		$bulan = $param['bulan'];
		$tahun = $param['tahun'];
		$data  = $param['data'];
		$is_new = false;
		
		$link = mysql_connect('localhost', NAMA_USER, NAMA_PASS);
		if (!$link) { return -1; }

		$db_selected = mysql_select_db(NAMA_DB, $link);
		if (!$db_selected) { return -2; }

		$sql = "DELETE FROM `pta_perkara_pekerjaan` WHERE tahun=$tahun AND bulan=$bulan";
		mysql_unbuffered_query($sql);
			
		foreach ($data as $k => $v) {
			$sql = sprintf("insert into `pta_perkara_pekerjaan` (`tahun`, `bulan`, `pekerjaan`, `ct`, `cg`, `lain`, `waktupencatatan`) 
				values ('%d', '%d', '%s', '%d', '%d', '%d', CURRENT_TIMESTAMP)", $tahun, $bulan, $v['pekerjaan'], $v['cerai_talak'], $v['gugat_cerai'], $v['lain_lain']);
			mysql_unbuffered_query($sql);
		}
			
		return $r;
	}
	
	$server->register(
		'savePerkaraUmur',                            
		array('param' => 'xsd:string'),      
		array('return' => 'xsd:int'),    
		'urn:'.NAMA_PA,                   
		'urn:'.NAMA_PA.'#savePerkaraUmur',   
		'rpc',                             
		'encoded',                         
		'<br><blockquote>Push Rekap Perkara per Umur Pe<br>
			From : Portal PA<br><br>
			To : Portal PTA<br><br>
			Info :<br><br>
			Input : PHP indexed-array<br>
			<blockquote>json_encoded data<br></blockquote>
			Output : integer <br>
			</blockquote></blockquote>'
	);

	function savePerkaraUmur($param) {
		$param = json_decode($param, true);
		$bulan = $param['bulan'];
		$tahun = $param['tahun'];
		$data  = $param['data'];
		$is_new = false;
		
		$link = mysql_connect('localhost', NAMA_USER, NAMA_PASS);
		if (!$link) { return -1; }

		$db_selected = mysql_select_db(NAMA_DB, $link);
		if (!$db_selected) { return -2; }

		$sql = "DELETE FROM `pta_perkara_umur` WHERE tahun=$tahun AND bulan=$bulan";
		mysql_unbuffered_query($sql);
			
		foreach ($data as $k => $v) {
			$sql = sprintf("insert into `pta_perkara_umur` (`tahun`, `bulan`, `jenis_perkara`, `usia1`, `usia2`, `usia3`, `usia4`, `usia5`, `usia0`, `waktupencatatan`) 
				values ('%d', '%d', '%s', '%d', '%d', '%d', '%d', '%d', '%d', CURRENT_TIMESTAMP)", $tahun, $bulan, $v['jenis_perkara'], $v['umur1'], $v['umur2'], $v['umur3'], $v['umur4'], $v['umur5'], $v['umur0']);
			mysql_unbuffered_query($sql);
		}
			
		return $r;
	}
	
	
	$server->register(
		'saveJadwalSidang',                            
		array('param' => 'xsd:string'),      
		array('return' => 'xsd:int'),    
		'urn:'.NAMA_PA,                   
		'urn:'.NAMA_PA.'#saveJadwalSidang',   
		'rpc',                             
		'encoded',                         
		'<br><blockquote>Push Jadwal Sidang<br>
			From : Portal PA<br><br>
			To : Portal PTA<br><br>
			Info :<br><br>
			Input : PHP indexed-array<br>
			<blockquote>json_encoded data<br></blockquote>
			Output : integer <br>
			</blockquote></blockquote>'
	);

	function saveJadwalSidang($param) {
		$param = json_decode($param, true);
		$bulan = $param['bulan'];
		$tahun = $param['tahun'];
		$data  = $param['data'];
		$is_new = false;
		
		$link = mysql_connect('localhost', NAMA_USER, NAMA_PASS);
		if (!$link) { return -1; }

		$db_selected = mysql_select_db(NAMA_DB, $link);
		if (!$db_selected) { return -2; }

		$sql = "DELETE FROM `pta_jadwal_sidang` WHERE YEAR(tahun)=$tahun AND MONTH(bulan)=$bulan";
		mysql_unbuffered_query($sql);
			
		foreach ($data as $k => $v) {
			$tgl = DMY2YMD($v['tanggal'], '/');
			$sql = sprintf("insert into `pta_jadwal_sidang` (`nomor`, `tanggal`, `pemohon`, `termohon`, `jenis_perkara`, `ruang`, `waktupencatatan`) 
				values ('%s', '%s', '%s', '%s', '%s', '%s', CURRENT_TIMESTAMP)", $v['nomor'], $tgl, $v['pemohon'], $v['termohon'], $v['jenis_perkara'], $v['ruang']);
			mysql_unbuffered_query($sql);
		}
			
		return $r;
	}
	
	
	$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
	$server->service($HTTP_RAW_POST_DATA);
	exit();
?>
