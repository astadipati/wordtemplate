<?php
// Pusat Pelaporan dan Data Statistik Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id
// Written by iyok642@yahoo.com, lastupdate 28 Pebruari 2014

@set_time_limit(3600);
@ini_set('memory_limit','1024M');

//parameter tanggal
$bln = $_POST["bln"]*1; if($bln==""){ $bln = $_GET["bln"]*1; }
$thn = $_POST["thn"]*1; if($thn==""){ $thn = $_GET["thn"]*1; };

$view = $_POST["view"];  if($view==""){ $view = $_GET["view"]; };
$laporan = $_POST["laporan"]*1;  if($laporan==""){ $laporan = $_GET["laporan"]*1; };
if ($laporan > 1){ $bln=substr($laporan,4,2)*1; $thn=substr($laporan,0,4)*1; };

//set default bulan tahun laporan
if ($bln==""){ 
	$bln = (date('m')-1)*1; $thn = date('Y')*1;
	if (date('d')>=25){ $bln = date('m')*1; }
	if ($bln==0){ $bln=12; $thn=(date('Y')-1)*1; }
};//if

//load setting
include_once("include.php");
include("include_login.php");

$iyok642 = $_GET["iyok642"]*1;
if ($iyok642 <> ""){ $SESS_ID_SATKER = $iyok642; }

//default id_parent
$id_parent = 12;
$runSQL = "select * from laporan_satker where id_satker='$SESS_ID_SATKER'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) { 
	if ($row[tk_satker]=="PA"){ $id_parent=$row[id_parent]; };
	if ($row[tk_satker]=="PTA"){ $id_parent=$row[id_satker]; };
};//while

//profile laporan
$runSQL = "select * from laporan_satker where id_satker=$id_parent";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$kode_perkara = $row[kode_perkara];
	$nama_satker = $row[nm_satker_pjg];
	$alamat_satker = $row[almt_satker];
	$website_email = "Website: ".$row[url_satker]." Email: ".$row[email_satker];
	$nama_ketua = $row[nama_ketua];
	$nama_pansek = $row[nama_pansek];
	$nama_kota = $row[nama_kota];
};//while

$fileTemplate="master_pta_rk1.xls"; 
if ($view == "RK.1"){ $fileTemplate="master_pta_rk1.xls"; }
if ($view == "RK.2"){ $fileTemplate="master_pta_rk2.xls"; }
if ($view == "RK.3"){ $fileTemplate="master_pta_rk3.xls"; }
if ($view == "RK.4"){ $fileTemplate="master_pta_rk4.xls"; }
if ($view == "RK.5"){ $fileTemplate="master_pta_rk5.xls"; }
if (($view == "RK.5")and($thn>=2017)){ $fileTemplate="master_pta_rk52017.xls"; }
if ($view == "RK.6"){ $fileTemplate="master_pta_rk6.xls"; }
if ($view == "RK.7a"){ $fileTemplate="master_pta_rk7a.xls"; }
if ($view == "RK.7b"){ $fileTemplate="master_pta_rk7b.xls"; }
if ($view == "RK.7c"){ $fileTemplate="master_pta_rk7c.xls"; }
if ($view == "RK.8a"){ $fileTemplate="master_pta_rk8a.xls"; }
if ($view == "RK.8b"){ $fileTemplate="master_pta_rk8b.xls"; }
if ($view == "RK.8c"){ $fileTemplate="master_pta_rk8c.xls"; }
if ($view == "RK.9"){ $fileTemplate="master_pta_rk9.xls"; }
if ($view == "RK.10"){ $fileTemplate="master_pta_rk10.xls"; }
if ($view == "RK.11a"){ $fileTemplate="master_pta_rk11a.xls"; }
if ($view == "RK.11b"){ $fileTemplate="master_pta_rk11b.xls"; }
if ($view == "RK.12"){ $fileTemplate="master_pta_rk12.xls"; }
if ($view == "RK.MA"){ $fileTemplate="master_pta_rkma.xls"; }
if ($view == "RK.ESYARIAH"){ $fileTemplate="master_pta_rkesyar.xls"; }
if ($view == "Pelayanan Terpadu"){ $fileTemplate="master_pta_lyterpadu.xls"; }
if ($view == "Register Delegasi"){ $fileTemplate="master_pta_delegasi.xls"; }

/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2013 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2013 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    1.7.9, 2013-06-02
 */

/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
date_default_timezone_set('Europe/London');

if (PHP_SAPI == 'cli')
	die('This example should only be run from a Web Browser');

/** Include PHPExcel */
require_once 'excell/PHPExcel.php';

//$fileTemplate = "master_pta_rk1.xls";
$fileDownload = $view."_".strtoupper($kode_perkara)."_Januari-".$bulan[($bln*1)]."_".$thn.".xls";

// Create new PHPExcel object
//$objPHPExcel = new PHPExcel();

// Read the file
$objReader = PHPExcel_IOFactory::createReader('Excel5');
$objPHPExcel = $objReader->load($fileTemplate);


// Set document properties
$objPHPExcel->getProperties()->setCreator("iyok642@yahoo.com")
							 ->setLastModifiedBy("pta-surabaya.go.id")
							 ->setTitle("Laporan Perkara Pengadilan Agama")
							 ->setSubject("Laporan Perkara Pengadilan Agama")
							 ->setDescription("Pusat Pelaporan Data Perkara SiADPA & SiADPTA Online")
							 ->setKeywords("Pusat Pelaporan Data Perkara SiADPA & SiADPTA Online")
							 ->setCategory("Pusat Pelaporan Data Perkara SiADPA & SiADPTA Online");


//all satker dalam wil.hukum
$cc=8;
$data_satker=array();
$nm_satker=array();
$runSQL = "select * from laporan_satker where id_parent=$id_parent order by urutan_cetak, nm_satker";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$id_satker = $row["id_satker"];
	array_push($data_satker, $row["id_satker"]);
	array_push($nm_satker, $row["nm_satker"]);
};//while
if (count($data_satker)>0){ $filterSQL="and (id_satker=".implode(" or id_satker=", $data_satker).")"; };

//laporan rk.1
if ($view == "RK.1"){
	$runSQL = "select * from laporan_rk1 where tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc = 60; //baris
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+8; };
		};//for
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, ($cc-7))
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"])
				->setCellValue("G".$cc, $row["kolom_7"])
				->setCellValue("H".$cc, $row["kolom_8"])
				->setCellValue("I".$cc, $row["kolom_9"])
				->setCellValue("J".$cc, $row["kolom_10"])
				->setCellValue("K".$cc, $row["kolom_11"])
				->setCellValue("L".$cc, $row["kolom_12"])
				->setCellValue("M".$cc, $row["kolom_13"])
				->setCellValue("N".$cc, $row["kolom_14"])
				->setCellValue("O".$cc, $row["kolom_15"])
				->setCellValue("P".$cc, $row["kolom_16"])
				->setCellValue("Q".$cc, $row["kolom_17"])
				->setCellValue("R".$cc, $row["kolom_18"])
				->setCellValue("S".$cc, $row["kolom_19"])
				->setCellValue("T".$cc, $row["kolom_20"])
				->setCellValue("U".$cc, $row["kolom_21"])
				->setCellValue("V".$cc, $row["kolom_22"])
				->setCellValue("W".$cc, $row["kolom_23"])
				->setCellValue("X".$cc, $row["kolom_24"])
				->setCellValue("Y".$cc, $row["kolom_25"])
				->setCellValue("Z".$cc, $row["kolom_26"])
				->setCellValue("AA".$cc, $row["kolom_27"])
				->setCellValue("AB".$cc, $row["kolom_28"])
				->setCellValue("AC".$cc, $row["kolom_29"])
				->setCellValue("AD".$cc, $row["kolom_30"])
				->setCellValue("AE".$cc, $row["kolom_31"])
				->setCellValue("AF".$cc, $row["kolom_32"])
				->setCellValue("AG".$cc, $row["kolom_33"])
				->setCellValue("AI".$cc, $row["kolom_35"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("C48", "Ketua ".$nama_satker)
					->setCellValue("C53", $nama_ketua)
					->setCellValue("V47", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("V53", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.1

//laporan rk.2
if ($view == "RK.2"){
	$runSQL = "select * from laporan_rk2 where tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+8; };
		};//for
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, ($cc-7))
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("F".$cc, $row["kolom_6"])
				->setCellValue("G".$cc, $row["kolom_7"])
				->setCellValue("H".$cc, $row["kolom_8"])
				->setCellValue("I".$cc, $row["kolom_9"])
				->setCellValue("J".$cc, $row["kolom_10"])
				->setCellValue("K".$cc, $row["kolom_11"])
				->setCellValue("L".$cc, $row["kolom_12"])
				->setCellValue("M".$cc, $row["kolom_13"])
				->setCellValue("N".$cc, $row["kolom_14"])
				->setCellValue("O".$cc, $row["kolom_15"])
				->setCellValue("P".$cc, $row["kolom_16"])
				->setCellValue("Q".$cc, $row["kolom_17"])
				->setCellValue("R".$cc, $row["kolom_18"])
				->setCellValue("S".$cc, $row["kolom_19"])
				->setCellValue("T".$cc, $row["kolom_20"])
				->setCellValue("U".$cc, $row["kolom_21"])
				->setCellValue("V".$cc, $row["kolom_22"])
				->setCellValue("W".$cc, $row["kolom_23"])
				->setCellValue("X".$cc, $row["kolom_24"])
				->setCellValue("Y".$cc, $row["kolom_25"])
				->setCellValue("Z".$cc, $row["kolom_26"])
				->setCellValue("AA".$cc, $row["kolom_27"])
				->setCellValue("AB".$cc, $row["kolom_28"])
				->setCellValue("AC".$cc, $row["kolom_29"])
				->setCellValue("AD".$cc, $row["kolom_30"])
				->setCellValue("AE".$cc, $row["kolom_31"])
				->setCellValue("AF".$cc, $row["kolom_32"])
				->setCellValue("AG".$cc, $row["kolom_33"])
				->setCellValue("AH".$cc, $row["kolom_34"])
				->setCellValue("AI".$cc, $row["kolom_35"])
				->setCellValue("AJ".$cc, $row["kolom_36"])
				->setCellValue("AK".$cc, $row["kolom_37"])
				->setCellValue("AL".$cc, $row["kolom_38"])
				->setCellValue("AM".$cc, $row["kolom_39"])
				->setCellValue("AN".$cc, $row["kolom_40"])
				->setCellValue("AO".$cc, $row["kolom_41"])
				->setCellValue("AR".$cc, $row["kolom_44"])
				->setCellValue("AS".$cc, $row["kolom_45"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("C48", "Ketua ".$nama_satker)
					->setCellValue("C53", $nama_ketua)
					->setCellValue("AE47", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("AE53", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.2

//laporan rk.3
if ($view == "RK.3"){
	$runSQL = "select * from laporan_rk3 where tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+8; };
		};//for
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, ($cc-7))
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"])
				->setCellValue("G".$cc, $row["kolom_7"])
				->setCellValue("H".$cc, $row["kolom_8"])
				->setCellValue("I".$cc, $row["kolom_9"])
				->setCellValue("J".$cc, $row["kolom_10"])
				->setCellValue("K".$cc, $row["kolom_11"])
				->setCellValue("L".$cc, $row["kolom_12"])
				->setCellValue("M".$cc, $row["kolom_13"])
				->setCellValue("N".$cc, $row["kolom_14"])
				->setCellValue("O".$cc, $row["kolom_15"])
				->setCellValue("P".$cc, $row["kolom_16"])
				->setCellValue("Q".$cc, $row["kolom_17"])
				->setCellValue("R".$cc, $row["kolom_18"])
				->setCellValue("S".$cc, $row["kolom_19"])
				->setCellValue("T".$cc, $row["kolom_20"])
				->setCellValue("U".$cc, $row["kolom_21"])
				->setCellValue("V".$cc, $row["kolom_22"])
				->setCellValue("W".$cc, $row["kolom_23"])
				->setCellValue("X".$cc, $row["kolom_24"])
				->setCellValue("Y".$cc, $row["kolom_25"])
				->setCellValue("Z".$cc, $row["kolom_26"])
				->setCellValue("AA".$cc, $row["kolom_27"])
				->setCellValue("AB".$cc, $row["kolom_28"])
				->setCellValue("AC".$cc, $row["kolom_29"])
				->setCellValue("AD".$cc, $row["kolom_30"])
				->setCellValue("AE".$cc, $row["kolom_31"])
				->setCellValue("AF".$cc, $row["kolom_32"])
				->setCellValue("AG".$cc, $row["kolom_33"])
				->setCellValue("AI".$cc, $row["kolom_35"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("C48", "Ketua ".$nama_satker)
					->setCellValue("C53", $nama_ketua)
					->setCellValue("V47", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("V53", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.3

//laporan rk.4
if ($view == "RK.4"){
	$runSQL = "select * from laporan_rk4 where tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+8; };
		};//for
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, ($cc-7))
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("F".$cc, $row["kolom_6"])
				->setCellValue("G".$cc, $row["kolom_7"])
				->setCellValue("H".$cc, $row["kolom_8"])
				->setCellValue("I".$cc, $row["kolom_9"])
				->setCellValue("J".$cc, $row["kolom_10"])
				->setCellValue("K".$cc, $row["kolom_11"])
				->setCellValue("L".$cc, $row["kolom_12"])
				->setCellValue("M".$cc, $row["kolom_13"])
				->setCellValue("N".$cc, $row["kolom_14"])
				->setCellValue("O".$cc, $row["kolom_15"])
				->setCellValue("P".$cc, $row["kolom_16"])
				->setCellValue("Q".$cc, $row["kolom_17"])
				->setCellValue("R".$cc, $row["kolom_18"])
				->setCellValue("S".$cc, $row["kolom_19"])
				->setCellValue("T".$cc, $row["kolom_20"])
				->setCellValue("U".$cc, $row["kolom_21"])
				->setCellValue("V".$cc, $row["kolom_22"])
				->setCellValue("W".$cc, $row["kolom_23"])
				->setCellValue("X".$cc, $row["kolom_24"])
				->setCellValue("Y".$cc, $row["kolom_25"])
				->setCellValue("Z".$cc, $row["kolom_26"])
				->setCellValue("AA".$cc, $row["kolom_27"])
				->setCellValue("AB".$cc, $row["kolom_28"])
				->setCellValue("AC".$cc, $row["kolom_29"])
				->setCellValue("AD".$cc, $row["kolom_30"])
				->setCellValue("AE".$cc, $row["kolom_31"])
				->setCellValue("AF".$cc, $row["kolom_32"])
				->setCellValue("AG".$cc, $row["kolom_33"])
				->setCellValue("AH".$cc, $row["kolom_34"])
				->setCellValue("AI".$cc, $row["kolom_35"])
				->setCellValue("AJ".$cc, $row["kolom_36"])
				->setCellValue("AK".$cc, $row["kolom_37"])
				->setCellValue("AL".$cc, $row["kolom_38"])
				->setCellValue("AM".$cc, $row["kolom_39"])
				->setCellValue("AN".$cc, $row["kolom_40"])
				->setCellValue("AO".$cc, $row["kolom_41"])
				->setCellValue("AR".$cc, $row["kolom_44"])
				->setCellValue("AS".$cc, $row["kolom_45"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("C48", "Ketua ".$nama_satker)
					->setCellValue("C53", $nama_ketua)
					->setCellValue("AE47", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("AE53", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.4

//laporan rk.5
if ($view == "RK.5"){
        $table_rk5 = "laporan_rk5";
        if ($thn >= 2017){ $table_rk5 = "laporan_rk5new"; };
	$runSQL = "select * from $table_rk5 where tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+9; };
		};//for

		if ($thn >= 2017){ 
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, ($cc-8))
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"])
				->setCellValue("G".$cc, $row["kolom_7"])
				->setCellValue("H".$cc, $row["kolom_8"])
				->setCellValue("I".$cc, $row["kolom_9"])
				->setCellValue("J".$cc, $row["kolom_10"])
				->setCellValue("K".$cc, $row["kolom_11"])
				->setCellValue("L".$cc, $row["kolom_12"])
				->setCellValue("M".$cc, $row["kolom_13"])
				->setCellValue("N".$cc, $row["kolom_14"])
				->setCellValue("O".$cc, $row["kolom_15"])
				->setCellValue("P".$cc, $row["kolom_16"])
				->setCellValue("R".$cc, $row["kolom_18"]);
                } else {
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, ($cc-8))
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"])
				->setCellValue("G".$cc, $row["kolom_7"])
				->setCellValue("H".$cc, $row["kolom_8"])
				->setCellValue("I".$cc, $row["kolom_9"])
				->setCellValue("J".$cc, $row["kolom_10"])
				->setCellValue("K".$cc, $row["kolom_11"])
				->setCellValue("L".$cc, $row["kolom_12"])
				->setCellValue("M".$cc, $row["kolom_13"])
				->setCellValue("N".$cc, $row["kolom_14"])
				->setCellValue("O".$cc, $row["kolom_15"])
				->setCellValue("P".$cc, $row["kolom_16"])
				->setCellValue("Q".$cc, $row["kolom_17"])
				->setCellValue("S".$cc, $row["kolom_19"]);
                };//if

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B49", "Ketua ".$nama_satker)
					->setCellValue("B54", $nama_ketua)
					->setCellValue("L48", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("L54", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.5


//laporan rk.6
if ($view == "RK.6"){
	$runSQL = "select * from laporan_rk6 where tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+10; };
		};//for
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, ($cc-9))
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"])
				->setCellValue("G".$cc, $row["kolom_7"])
				->setCellValue("H".$cc, $row["kolom_8"])
				->setCellValue("J".$cc, $row["kolom_10"])
				->setCellValue("K".$cc, $row["kolom_11"])
				->setCellValue("L".$cc, $row["kolom_12"])
				->setCellValue("P".$cc, $row["kolom_16"])
				->setCellValue("Q".$cc, $row["kolom_17"])
				->setCellValue("R".$cc, $row["kolom_18"])
				->setCellValue("S".$cc, $row["kolom_19"])
				->setCellValue("T".$cc, $row["kolom_20"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B50", "Ketua ".$nama_satker)
					->setCellValue("B55", $nama_ketua)
					->setCellValue("N49", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("N55", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.6


//laporan rk.7a
if ($view == "RK.7a"){
	$runSQL = "select * from laporan_rk7a where (tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL) or (tahun='$thn' and (bulan >=1 and bulan <=12) and id_satker='$id_parent') order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+8; $nomor=($cc-7); };
		};//for
		if ($id_satker == $id_parent){ $cc=7; $nomor="-"; };
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, $nomor)
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"])
				->setCellValue("H".$cc, $row["kolom_8"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B48", "Ketua ".$nama_satker)
					->setCellValue("B53", $nama_ketua)
					->setCellValue("F47", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("F53", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.7a

//laporan rk.7b
if ($view == "RK.7b"){
	$runSQL = "select * from laporan_rk7b where (tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL) or (tahun='$thn' and (bulan >=1 and bulan <=12) and id_satker='$id_parent') order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+8; $nomor=($cc-7); };
		};//for
		if ($id_satker == $id_parent){ $cc=7; $nomor="-"; };
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, $nomor)
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"])
				->setCellValue("H".$cc, $row["kolom_8"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B48", "Ketua ".$nama_satker)
					->setCellValue("B53", $nama_ketua)
					->setCellValue("F47", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("F53", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.7b

//laporan rk.7c
if ($view == "RK.7c"){
	$runSQL = "select * from laporan_rk7c where (tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL) or (tahun='$thn' and (bulan >=1 and bulan <=12) and id_satker='$id_parent') order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+8; $nomor=($cc-7); };
		};//for
		if ($id_satker == $id_parent){ $cc=7; $nomor="-"; };
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, $nomor)
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"])
				->setCellValue("H".$cc, $row["kolom_8"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B48", "Ketua ".$nama_satker)
					->setCellValue("B53", $nama_ketua)
					->setCellValue("F47", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("F53", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.7c


//laporan rk.8a
if ($view == "RK.8a"){
	$runSQL = "select * from laporan_rk8a where tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+7; };
		};//for
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, ($cc-6))
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("H".$cc, $row["kolom_8"])
				->setCellValue("I".$cc, $row["kolom_9"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B47", "Ketua ".$nama_satker)
					->setCellValue("B52", $nama_ketua)
					->setCellValue("F46", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("F52", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.8a

//laporan rk.8b
if ($view == "RK.8b"){
	$runSQL = "select * from laporan_rk8b where tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+7; };
		};//for
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, ($cc-6))
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("H".$cc, $row["kolom_8"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B47", "Ketua ".$nama_satker)
					->setCellValue("B52", $nama_ketua)
					->setCellValue("F46", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("F52", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.8b

//laporan rk.8c
if ($view == "RK.8c"){
	$runSQL = "select * from laporan_rk8c where tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+8; };
		};//for
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, ($cc-7))
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("H".$cc, $row["kolom_8"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B48", "Ketua ".$nama_satker)
					->setCellValue("B53", $nama_ketua)
					->setCellValue("F47", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("F53", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.8c

//laporan rk.9
if ($view == "RK.9"){
	$runSQL = "select * from laporan_rk9 where tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+8; };
		};//for
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, ($cc-7))
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"])
				->setCellValue("G".$cc, $row["kolom_7"])
				->setCellValue("H".$cc, $row["kolom_8"])
				->setCellValue("I".$cc, $row["kolom_9"])
				->setCellValue("J".$cc, $row["kolom_10"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B48", "Ketua ".$nama_satker)
					->setCellValue("B53", $nama_ketua)
					->setCellValue("H47", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("H53", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.9

//laporan rk.10
if ($view == "RK.10"){
	$runSQL = "select * from laporan_rk10 where tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+8; };
		};//for
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, ($cc-7))
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"])
				->setCellValue("G".$cc, $row["kolom_7"])
				->setCellValue("H".$cc, $row["kolom_8"])
				->setCellValue("I".$cc, $row["kolom_9"])
				->setCellValue("J".$cc, $row["kolom_10"])
				->setCellValue("K".$cc, $row["kolom_11"])
				->setCellValue("L".$cc, $row["kolom_12"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B48", "Ketua ".$nama_satker)
					->setCellValue("B53", $nama_ketua)
					->setCellValue("I47", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("I53", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.10


//laporan rk.11a
if ($view == "RK.11a"){
	$runSQL = "select * from laporan_rk11a where tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+8; };
		};//for
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, ($cc-7))
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B48", "Ketua ".$nama_satker)
					->setCellValue("B53", $nama_ketua)
					->setCellValue("D47", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("D53", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.11a


//laporan rk.11b
if ($view == "RK.11b"){
	$runSQL = "select * from laporan_rk11b where (tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL) or (tahun='$thn'and (bulan >=1 and bulan <=12) and id_satker='$id_parent') order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+9; $nomor=($cc-8); };
		};//for
		if ($id_satker == $id_parent){ $cc=8; $nomor="-"; };
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, $nomor)
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"])
				->setCellValue("G".$cc, $row["kolom_7"])
				->setCellValue("H".$cc, $row["kolom_8"])
				->setCellValue("I".$cc, $row["kolom_9"])
				->setCellValue("J".$cc, $row["kolom_10"])
				->setCellValue("K".$cc, $row["kolom_11"])
				->setCellValue("L".$cc, $row["kolom_12"])
				->setCellValue("M".$cc, $row["kolom_13"])
				->setCellValue("N".$cc, $row["kolom_14"])
				->setCellValue("O".$cc, $row["kolom_15"])
				->setCellValue("P".$cc, $row["kolom_16"])
				->setCellValue("Q".$cc, $row["kolom_17"])
				->setCellValue("R".$cc, $row["kolom_18"])
				->setCellValue("S".$cc, $row["kolom_19"])
				->setCellValue("T".$cc, $row["kolom_20"])
				->setCellValue("U".$cc, $row["kolom_21"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B49", "Ketua ".$nama_satker)
					->setCellValue("B54", $nama_ketua)
					->setCellValue("M48", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("M54", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.11b


//laporan rk.12
if ($view == "RK.12"){

	$runSQL = "select * from laporan_rk12_lama where (tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL) or (tahun='$thn' and (bulan >=1 and bulan <=12) and id_satker='$id_parent') order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+9; $nomor=($cc-8); };
		};//for
		if ($id_satker == $id_parent){ $cc=8; $nomor="-"; };
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, $nomor)
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"]);
	};//while

	$runSQL = "select * from laporan_rk12 where (tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL) or (tahun='$thn' and (bulan >=1 and bulan <=12) and id_satker='$id_parent') order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+9; $nomor=($cc-8); };
		};//for
		if ($id_satker == $id_parent){ $cc=8; $nomor="-"; };
		
		if (($row["kolom_4"]<>"") and ($row["kolom_5"]<>"") and ($row["kolom_6"]<>"")){
			$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, $nomor)
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"]);
		} else {
			$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, $nomor)
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"]);
		};//if
		
		/*
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, $nomor)
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"]);
		*/

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B49", "Ketua ".$nama_satker)
					->setCellValue("B54", $nama_ketua)
					->setCellValue("E48", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("E54", $nama_pansek);
	};//while
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.12


//laporan rk.ma
if ($view == "RK.MA"){
	$runSQL = "select * from laporan_rkma where tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+9; };
		};//for
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, ($cc-8))
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("G".$cc, $row["kolom_7"])
				->setCellValue("H".$cc, $row["kolom_8"])
				->setCellValue("I".$cc, $row["kolom_9"])
				->setCellValue("K".$cc, $row["kolom_11"])
				->setCellValue("L".$cc, $row["kolom_12"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B49", "Ketua ".$nama_satker)
					->setCellValue("B54", $nama_ketua)
					->setCellValue("I48", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("I54", $nama_pansek);
	};//while
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);
};//RK.MA


//laporan rk.esyar
if ($view == "RK.ESYARIAH"){
	$runSQL = "select * from laporan_rkesyar where tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL order by bulan asc";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$this_bulan=$row["bulan"];
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+8; };
		};//for
		
		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("A".$cc, ($cc-7))
				->setCellValue("B".$cc, $row["kolom_2"])
				->setCellValue("C".$cc, $row["kolom_3"])
				->setCellValue("D".$cc, $row["kolom_4"])
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"])
				->setCellValue("G".$cc, $row["kolom_7"])
				->setCellValue("H".$cc, $row["kolom_8"])
				->setCellValue("I".$cc, $row["kolom_9"])
				->setCellValue("J".$cc, $row["kolom_10"]);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B48", "Ketua ".$nama_satker)
					->setCellValue("B53", $nama_ketua)
					->setCellValue("G47", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("G53", $nama_pansek);
	};//while
	
};//RK.ESYARIAH


//laporan Pelayanan Terpadu
if ($view == "Pelayanan Terpadu"){

	for ($this_bulan=1; $this_bulan<=12; $this_bulan++){

		$cc=60; $jml_5=0; $jml_6=0; $jml_7=0; $jml_8=0; $jml_9=0;
		for($i=0; $i<count($data_satker); $i++){
			$id_satker = $data_satker[$i];
			
			$kolom_1=""; $kolom_2=""; $kolom_3=""; $kolom_4=""; $kolom_5=""; $kolom_6=""; $kolom_7=""; $kolom_8=""; $kolom_9=""; $kolom_10="";
			$runSQL2 = "select * from laporan_lyterpadu where id_satker='$id_satker' and tahun='$thn' and bulan='$this_bulan'";
			$result2 = mysql_query($runSQL2, $connDB);
			while ($row2 = mysql_fetch_array ($result2)) { 
				$kolom_1 = $i;
				$kolom_2 = $row2["kolom_2"];
				$kolom_3 .= $row2["kolom_3"]."\r\n";
				$kolom_4 .= $row2["kolom_4"]."\r\n";
				$kolom_5 .= $row2["kolom_5"]."\r\n";
				$kolom_6 .= $row2["kolom_6"]."\r\n";
				$kolom_7 .= $row2["kolom_7"]."\r\n";
				$kolom_8 .= $row2["kolom_8"]."\r\n";
				$kolom_9 .= $row2["kolom_9"]."\r\n";
				$kolom_10 .= $row2["kolom_10"]."\r\n";

				$jml_5 += $row2["kolom_5"];
				$jml_6 += $row2["kolom_6"];
				$jml_7 += $row2["kolom_7"];
				$jml_8 += $row2["kolom_8"];
				$jml_9 += $row2["kolom_9"];
			};//while

			if ($kolom_2 == ""){ $kolom_2 = $nm_satker[$i]; }
			$cc = $i + 8;
			$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
						->setCellValue("A".$cc, ($cc-7))
						->setCellValue("B".$cc, $kolom_2)
						->setCellValue("C".$cc, $kolom_3)
						->setCellValue("D".$cc, $kolom_4)
						->setCellValue("E".$cc, $kolom_5)
						->setCellValue("F".$cc, $kolom_6)
						->setCellValue("G".$cc, $kolom_7)
						->setCellValue("H".$cc, $kolom_8)
						->setCellValue("I".$cc, $kolom_9)
						->setCellValue("J".$cc, $kolom_10);
		};//for-satker

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
				->setCellValue("E45", $jml_5)
				->setCellValue("F45", $jml_6)
				->setCellValue("G45", $jml_7)
				->setCellValue("H45", $jml_8)
				->setCellValue("I45", $jml_9);

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B48", "Ketua ".$nama_satker)
					->setCellValue("B53", $nama_ketua)
					->setCellValue("G47", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("G53", $nama_pansek);
	};//for this_bulan
	
	$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("A2", strtoupper($nama_satker))
				->setCellValue("A3", "BULAN JANUARI s/d DESEMBER TAHUN ".$thn);


	$runSQL = "select id_satker, sum(kolom_5) kolom_5, sum(kolom_6) kolom_6, sum(kolom_7) kolom_7, sum(kolom_8) kolom_8, sum(kolom_9) kolom_9 from laporan_lyterpadu where tahun='$thn' and (bulan >=1 and bulan <=12) $filterSQL group by id_satker";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) {
		$id_satker=$row["id_satker"];
		$cc=60;
		for($i=0; $i<count($data_satker); $i++){
			if ($id_satker == $data_satker[$i]){ $cc=$i+8; };
		};//for
		$objPHPExcel->setActiveSheetIndex(12)
				->setCellValue("E".$cc, $row["kolom_5"])
				->setCellValue("F".$cc, $row["kolom_6"])
				->setCellValue("G".$cc, $row["kolom_7"])
				->setCellValue("H".$cc, $row["kolom_8"])
				->setCellValue("I".$cc, $row["kolom_9"]);
	};//while

$this_bulan = $bln;
};//Pelayanan Terpadu

/*
//register delegasi
if ($view == "Register Delegasi"){

	for ($this_bulan=1; $this_bulan<=12; $this_bulan++){

		$cc=6;
		for($i=0; $i<count($data_satker); $i++){
			$id_satker = $data_satker[$i];
			
			$runSQL2 = "select id_satker, tahun, bulan, id_session, lastupdate, kolom_1, kolom_2, kolom_3, kolom_4, kolom_4b, date_format(kolom_5,'%d-%m-%Y') kolom_5, kolom_6 as kolom_6sql, date_format(kolom_6,'%d-%m-%Y') kolom_6, kolom_7 as kolom_7srt, date_format(kolom_7,'%d-%m-%Y') kolom_7, date_format(kolom_8,'%d-%m-%Y') kolom_8, date_format(kolom_8b,'%d-%m-%Y') kolom_8b, date_format(kolom_9,'%d-%m-%Y') kolom_9, kolom_10, kolom_11, kolom_12 from laporan_delegasi where id_satker='$id_satker' and tahun='$thn' and bulan='$this_bulan'";
			$result2 = mysql_query($runSQL2, $connDB);
			while ($row2 = mysql_fetch_array ($result2)) { 
				$cc++;
				if (($row2["kolom_5"]=="00-00-0000")or($row2["kolom_5"]=="")){ $row2["kolom_5"]=" - "; }
				if (($row2["kolom_6"]=="00-00-0000")or($row2["kolom_6"]=="")){ $row2["kolom_6"]=" - "; }
				if (($row2["kolom_7"]=="00-00-0000")or($row2["kolom_7"]=="")){ $row2["kolom_7"]=" - "; }
				if (($row2["kolom_8"]=="00-00-0000")or($row2["kolom_8"]=="")){ $row2["kolom_8"]=" - "; }
				if (($row2["kolom_8b"]=="00-00-0000")or($row2["kolom_8b"]=="")){ $row2["kolom_8b"]=" - "; }
				if (($row2["kolom_9"]=="00-00-0000")or($row2["kolom_9"]=="")){ $row2["kolom_9"]=" - "; }

				$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
						->setCellValue("A".$cc, ($cc-6))
						->setCellValue("B".$cc, $nm_satker[$i])
						->setCellValue("C".$cc, $row2["kolom_2"])
						->setCellValue("D".$cc, $row2["kolom_3"])
						->setCellValue("E".$cc, $row2["kolom_4"])
						->setCellValue("F".$cc, $row2["kolom_4b"])
						->setCellValue("G".$cc, $row2["kolom_5"])
						->setCellValue("H".$cc, $row2["kolom_6"])
						->setCellValue("I".$cc, $row2["kolom_7"])
						->setCellValue("J".$cc, $row2["kolom_8"])
						->setCellValue("K".$cc, $row2["kolom_8b"])
						->setCellValue("L".$cc, $row2["kolom_9"])
						->setCellValue("M".$cc, $row2["kolom_10"])
						->setCellValue("N".$cc, $row2["kolom_11"]);
			};//while
		};//for-satker

		$lastday = date ("t", mktime(0,0,0,$this_bulan,1,$thn));
		$numbday = date ("N", mktime(0,0,0,$this_bulan,$lastday,$thn));
		if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

		$objPHPExcel->setActiveSheetIndex(($this_bulan-1))
					->setCellValue("A2", strtoupper($nama_satker))
					->setCellValue("A3", "BULAN ".strtoupper($bulan[($this_bulan*1)])." TAHUN ".$thn)
					->setCellValue("B48", "Ketua ".$nama_satker)
					->setCellValue("B53", $nama_ketua)
					->setCellValue("G47", $nama_kota.", $lastday ".$bulan[($this_bulan*1)]." ".$thn)
					->setCellValue("G53", $nama_pansek);
	};//for this_bulan
	
$this_bulan = $bln;
};//Pelayanan Terpadu
*/

// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(($this_bulan-1));


// Redirect output to a client’s web browser (Excel5)
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="'.$fileDownload.'"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;
