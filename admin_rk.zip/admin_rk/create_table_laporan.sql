
ALTER TABLE `sys_user_access` DROP `start_access`, DROP `last_access`, DROP `location`, DROP `browser`;
ALTER TABLE `sys_user_access` ADD `var_access` text DEFAULT NULL;

CREATE TABLE IF NOT EXISTS `sys_session` (
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `session_id` varchar(32) NOT NULL,
  `ip_address` varchar(15) DEFAULT NULL,
  `id_satker` int(10) NOT NULL,
  `name_user` varchar(100) NOT NULL,
  `name_server` varchar(50),
  PRIMARY KEY (`session_id`)
);

CREATE TABLE IF NOT EXISTS `sys_location` (
  `id_location` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(15) NOT NULL DEFAULT '0.0.0.0',
  `location` varchar(225) DEFAULT NULL,
  `alias` varchar(225) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id_location`)
);

CREATE TABLE IF NOT EXISTS `sys_username` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `name_user` varchar(50) NOT NULL,
  `pass_user` varchar(50) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `id_satker` int(10) NOT NULL,
  `name_server` varchar(50) NOT NULL DEFAULT 'localhost',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id_user`,`name_user`, `name_server`)
);

CREATE TABLE IF NOT EXISTS `sys_browser` (
  `id_browser` int(11) NOT NULL AUTO_INCREMENT,
  `browser` varchar(225) DEFAULT NULL,
  `alias` varchar(225) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id_browser`)
);

CREATE TABLE IF NOT EXISTS `sys_pagename` (
  `id_page` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(225) DEFAULT NULL,
  `alias` varchar(225) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id_page`)
);

CREATE TABLE IF NOT EXISTS `sys_user_access` (
  `currentdate` date NOT NULL DEFAULT '2011-06-03',
  `session_id` varchar(32) NOT NULL DEFAULT '',
  `ipaddress` varchar(15) NOT NULL DEFAULT '0.0.0.0',
  `start_time` time NOT NULL,
  `last_time` time NOT NULL,
  `login_count` int(11) NOT NULL DEFAULT '0',
  `hit_count` bigint(20) NOT NULL DEFAULT '0',
  `id_location` int(11) NOT NULL,
  `id_browser` int(11) NOT NULL,
  `page_access` text,
  `var_access` text,
  PRIMARY KEY (`currentdate`,`session_id`,`ipaddress`)
);

CREATE TABLE IF NOT EXISTS `sys_session_history` (
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `session_id` varchar(32) NOT NULL,
  `ip_address` varchar(15) DEFAULT NULL,
  `id_satker` int(10) NOT NULL,
  `nm_user` varchar(100) NOT NULL
);


CREATE TABLE IF NOT EXISTS `laporan_session` (
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `session_id` varchar(32) NOT NULL,
  `ip_address` varchar(15) DEFAULT NULL,
  `id_satker` int(10) NOT NULL,
  `nm_user` varchar(100) NOT NULL,
  `server` varchar(20),
  PRIMARY KEY (`session_id`)
);

CREATE TABLE IF NOT EXISTS `laporan_settings` (
  `id_setting` int(11) NOT NULL AUTO_INCREMENT,
  `variable` varchar(40) NOT NULL,
  `value` text NOT NULL,
  `onload` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_setting`)
);
INSERT INTO `laporan_settings` (`id_setting`, `variable`, `value`, `onload`) VALUES
(1, 'nama_pa', 'Pengadilan Agama Sementara', 1),
(2, 'alamat_pa', 'Jl. Mayjen Sungkono No7 Surabaya', 1),
(3, 'email_pa', 'iyok642@gmail.com', 1),
(4, 'telp_pa', '03170920002', 1),
(5, 'logo_header', 'img/logo.png', 0);

CREATE TABLE IF NOT EXISTS `laporan_satker` (
  `id_satker` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nm_satker` varchar(50) NOT NULL,
  `nm_satker_pjg` varchar(100) NOT NULL,
  `almt_satker` text NOT NULL,
  `kode_perkara` varchar(10) NOT NULL,
  `tk_satker` set('MARI','BADILAG','PTA','PA') NOT NULL,
  `id_parent` int(11) NOT NULL,
  `id_sort` int(11) NOT NULL,
  `kls_satker` tinyint(3) unsigned NOT NULL,
  `telp_satker` varchar(20) NOT NULL,
  `fax_satker` varchar(20) NOT NULL,
  `url_satker` varchar(255) NOT NULL,
  `email_satker` varchar(255) NOT NULL,
  `id_satker_sai` int(10) unsigned NOT NULL,
  `nama_ketua` varchar(50) NOT NULL,
  `nama_pansek` varchar(50) NOT NULL,
  `nama_kota` varchar(30) NOT NULL,
  PRIMARY KEY (`id_satker`),
  KEY `id_parent` (`id_parent`),
  KEY `tk_satker` (`tk_satker`)
);

ALTER TABLE `laporan_satker` ADD `nama_ketua` VARCHAR( 50 ) NOT NULL ,
ADD `nama_pansek` VARCHAR( 50 ) NOT NULL ,
ADD `nama_kota` VARCHAR( 30 ) NOT NULL ;

ALTER TABLE `laporan_satker` ADD `urutan_cetak` INT(10);

CREATE TABLE IF NOT EXISTS `laporan_username` (
  `nm_user` varchar(100) NOT NULL,
  `pwd_user` varchar(100) NOT NULL,
  `nm_lengkap` varchar(100) NOT NULL,
  `id_satker` int(10) unsigned NOT NULL,
  `tk_user` enum('ADMIN','OPERATOR') DEFAULT NULL,
  PRIMARY KEY (`nm_user`),
  KEY `id_satker` (`id_satker`),
  KEY `nm_user` (`nm_user`)
);

----------------------
CREATE TABLE IF NOT EXISTS laporan_revisi (
  id_satker   int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  penjalasan  text,
  approval    int(11) NOT NULL DEFAULT 0,
  app_session varchar(32),
  app_date    datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (id_satker, approval)
);

CREATE TABLE IF NOT EXISTS laporan_lock (
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  date_lock   date NOT NULL DEFAULT '1981-10-09',
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rk1 (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  kolom_5     int(11),
  kolom_6     int(11),
  kolom_7     int(11),
  kolom_8     int(11),
  kolom_9     int(11),
  kolom_10    int(11),
  kolom_11    int(11),
  kolom_12    int(11),
  kolom_13    int(11),
  kolom_14    int(11),
  kolom_15    int(11),
  kolom_16    int(11),
  kolom_17    int(11),
  kolom_18    int(11),
  kolom_19    int(11),
  kolom_20    int(11),
  kolom_21    int(11),
  kolom_22    int(11),
  kolom_23    int(11),
  kolom_24    int(11),
  kolom_25    int(11),
  kolom_26    int(11),
  kolom_27    int(11),
  kolom_28    int(11),
  kolom_29    int(11),
  kolom_30    int(11),
  kolom_31    int(11),
  kolom_32    int(11),
  kolom_33    int(11),
  kolom_34    int(11),
  kolom_35    varchar(50),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rk2 (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  kolom_5     int(11),
  kolom_6     int(11),
  kolom_7     int(11),
  kolom_8     int(11),
  kolom_9     int(11),
  kolom_10    int(11),
  kolom_11    int(11),
  kolom_12    int(11),
  kolom_13    int(11),
  kolom_14    int(11),
  kolom_15    int(11),
  kolom_16    int(11),
  kolom_17    int(11),
  kolom_18    int(11),
  kolom_19    int(11),
  kolom_20    int(11),
  kolom_21    int(11),
  kolom_22    int(11),
  kolom_23    int(11),
  kolom_24    int(11),
  kolom_25    int(11),
  kolom_26    int(11),
  kolom_27    int(11),
  kolom_28    int(11),
  kolom_29    int(11),
  kolom_30    int(11),
  kolom_31    int(11),
  kolom_32    int(11),
  kolom_33    int(11),
  kolom_34    int(11),
  kolom_35    int(11),
  kolom_36    int(11),
  kolom_37    int(11),
  kolom_38    int(11),
  kolom_39    int(11),
  kolom_40    int(11),
  kolom_41    int(11),
  kolom_42    int(11),
  kolom_43    int(11),
  kolom_44    int(11),
  kolom_45    varchar(50),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rk3 (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  kolom_5     int(11),
  kolom_6     int(11),
  kolom_7     int(11),
  kolom_8     int(11),
  kolom_9     int(11),
  kolom_10    int(11),
  kolom_11    int(11),
  kolom_12    int(11),
  kolom_13    int(11),
  kolom_14    int(11),
  kolom_15    int(11),
  kolom_16    int(11),
  kolom_17    int(11),
  kolom_18    int(11),
  kolom_19    int(11),
  kolom_20    int(11),
  kolom_21    int(11),
  kolom_22    int(11),
  kolom_23    int(11),
  kolom_24    int(11),
  kolom_25    int(11),
  kolom_26    int(11),
  kolom_27    int(11),
  kolom_28    int(11),
  kolom_29    int(11),
  kolom_30    int(11),
  kolom_31    int(11),
  kolom_32    int(11),
  kolom_33    int(11),
  kolom_34    int(11),
  kolom_35    varchar(50),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rk4 (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  kolom_5     int(11),
  kolom_6     int(11),
  kolom_7     int(11),
  kolom_8     int(11),
  kolom_9     int(11),
  kolom_10    int(11),
  kolom_11    int(11),
  kolom_12    int(11),
  kolom_13    int(11),
  kolom_14    int(11),
  kolom_15    int(11),
  kolom_16    int(11),
  kolom_17    int(11),
  kolom_18    int(11),
  kolom_19    int(11),
  kolom_20    int(11),
  kolom_21    int(11),
  kolom_22    int(11),
  kolom_23    int(11),
  kolom_24    int(11),
  kolom_25    int(11),
  kolom_26    int(11),
  kolom_27    int(11),
  kolom_28    int(11),
  kolom_29    int(11),
  kolom_30    int(11),
  kolom_31    int(11),
  kolom_32    int(11),
  kolom_33    int(11),
  kolom_34    int(11),
  kolom_35    int(11),
  kolom_36    int(11),
  kolom_37    int(11),
  kolom_38    int(11),
  kolom_39    int(11),
  kolom_40    int(11),
  kolom_41    int(11),
  kolom_42    int(11),
  kolom_43    int(11),
  kolom_44    int(11),
  kolom_45    varchar(50),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rk5 (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  kolom_5     int(11),
  kolom_6     int(11),
  kolom_7     int(11),
  kolom_8     int(11),
  kolom_9     int(11),
  kolom_10    int(11),
  kolom_11    int(11),
  kolom_12    int(11),
  kolom_13    int(11),
  kolom_14    int(11),
  kolom_15    int(11),
  kolom_16    int(11),
  kolom_17    int(11),
  kolom_18    int(11),
  kolom_19    varchar(50),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rk6 (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  kolom_5     int(11),
  kolom_6     int(11),
  kolom_7     int(11),
  kolom_8     int(11),
  kolom_9     int(11),
  kolom_10    int(11),
  kolom_11    int(11),
  kolom_12    int(11),
  kolom_13    int(11),
  kolom_14    int(11),
  kolom_15    int(11),
  kolom_16    int(11),
  kolom_17    int(11),
  kolom_18    int(11),
  kolom_19    int(11),
  kolom_20    varchar(50),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rk7a (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  kolom_5     int(11),
  kolom_6     int(11),
  kolom_7     int(11),
  kolom_8     varchar(50),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rk8a (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  kolom_5     int(11),
  kolom_6     int(11),
  kolom_7     int(11),
  kolom_8     int(11),
  kolom_9     int(11),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rk8b (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  kolom_5     int(11),
  kolom_6     int(11),
  kolom_7     int(11),
  kolom_8     int(11),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rk8c (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  kolom_5     int(11),
  kolom_6     int(11),
  kolom_7     int(11),
  kolom_8     int(11),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rk9 (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  kolom_5     int(11),
  kolom_6     int(11),
  kolom_7     int(11),
  kolom_8     int(11),
  kolom_9     int(11),
  kolom_10    int(11),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rk10 (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  kolom_5     int(11),
  kolom_6     int(11),
  kolom_7     int(11),
  kolom_8     int(11),
  kolom_9     int(11),
  kolom_10    int(11),
  kolom_11    int(11),
  kolom_12    varchar(50),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rk11a (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rk11b (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  kolom_5     int(11),
  kolom_6     int(11),
  kolom_7     int(11),
  kolom_8     int(11),
  kolom_9     int(11),
  kolom_10    int(11),
  kolom_11    int(11),
  kolom_12    int(11),
  kolom_13    int(11),
  kolom_14    int(11),
  kolom_15    int(11),
  kolom_16    int(11),
  kolom_17    int(11),
  kolom_18    int(11),
  kolom_19    int(11),
  kolom_20    int(11),
  kolom_21    int(11),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rk12 (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  kolom_5     int(11),
  kolom_6     int(11),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rkma (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     int(11),
  kolom_4     int(11),
  kolom_5     int(11),
  kolom_6     int(11),
  kolom_7     int(11),
  kolom_8     int(11),
  kolom_9     int(11),
  kolom_10    int(11),
  kolom_11    int(11),
  kolom_12    int(11),
  PRIMARY KEY (id_satker, tahun, bulan)
);

CREATE TABLE IF NOT EXISTS laporan_rkesyar (
  id_satker   int(11) NOT NULL,
  tahun       int(11) NOT NULL,
  bulan       int(11) NOT NULL,
  id_session  varchar(32),
  lastupdate  datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  kolom_1     int(11),
  kolom_2     varchar(30),
  kolom_3     varchar(15),
  kolom_4     varchar(100),
  kolom_5     varchar(20),
  kolom_6     varchar(20),
  kolom_7     varchar(100),
  kolom_8     varchar(100),
  kolom_9     varchar(100),
  kolom_10    varchar(30),
  PRIMARY KEY (id_satker, tahun, bulan)
);