<?php
// Aplikasi Pendaftaran Perkara Online
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id
// lastupdate 10 Juli 2013

date_default_timezone_set("Asia/Calcutta");

//seting koneksi database
$hostserver = "localhost";
$database   = "ptasura1_laporan";

$dbusername = "ptasura1_laporan";
$dbpassword = "alhamdulillah";

//$dbusername = "root";
//$dbpassword = "";

/*
$hostserver = "localhost";
$dbusername = "smac6212_new";
$dbpassword = "telkom135";
$database   = "smac6212_laporan";
*/

//-------------------------------------
//Langkah-langkah instalasi
// 1. copy direktori pendaftaran ke website
// 2. buat username dan database pendaftaran lewat cpanel
// 3. buka file @konfigurasi.php dan sesuaikan settingnya
// 4. buka phpmyadmin, masuk pada database pendaftaran
// 5. import data, file sql: 
//    - sql_pendaftaran_online.sql
//    - sql_radius.sql



//=====================================
//Jika mengalami kendala silakan kontak
//Tim IT PTA Surabaya :
//031-3988888 (tim-it-pta)
//081216112552 (priyo)
?>