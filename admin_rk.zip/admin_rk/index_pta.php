<?
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id
// lastupdate 03 Pebruari 2015

$dbusername = "ptasurab_panitra"; //"root";
$dbpassword = "surabaya2013"; //"";
$hostserver = "localhost";
$database   = "ptasurab_laporan";

session_start();
$SESSION_ID = session_id();

//try to connect database
if (!$connDB){ $connDB = mysql_connect($hostserver, $dbusername, $dbpassword); };
if (!$useDB){ $useDB = mysql_select_db($database, $connDB); };

//preset parameter
$REMOTE_ADDR = get_ip_address();   //getenv("REMOTE_ADDR");
$QUERY_STRING = @getenv("QUERY_STRING");
$HTTP_USER_AGENT = @getenv("HTTP_USER_AGENT");

//get parameter script_name
$tmp_script = $_SERVER["SCRIPT_NAME"];
$SCRIPT_NAME = $tmp_script;
$pos = @strrpos(" ".$tmp_script, "/");
if($pos == true){
	$SCRIPT_NAME = substr($tmp_script, $pos);
};//id

//set parameter script_name for history
$runSQL = "select id_page from webpta_pagename where file_name='$SCRIPT_NAME'";
$result = @mysql_query($runSQL, $connDB);
if ($row = @mysql_fetch_array ($result)) { 
	$id_page = $row[id_page];
} else {
  $runSQL = "insert into webpta_pagename (file_name, created) values ('$SCRIPT_NAME', NOW())";
  $insert = @mysql_query($runSQL, $connDB);
  $id_page = @mysql_insert_id($connDB);
};//if

//set parameter browser for history
$runSQL = "select id_browser from webpta_browser where browser='$HTTP_USER_AGENT'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) { 
	$id_browser = $row[id_browser];
} else {
  $runSQL = "insert into webpta_browser (browser, created) values ('$HTTP_USER_AGENT', NOW())";
  $insert = mysql_query($runSQL, $connDB);
  $id_browser = mysql_insert_id($connDB);
};//if

//set parameter ipaddress for history
$runSQL = "select id_location from webpta_location where ipaddress='$REMOTE_ADDR'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) { 
	$id_location = $row[id_location];
} else {
  $runSQL = "insert into webpta_location (ipaddress, created) values ('$REMOTE_ADDR', NOW())";
  $insert = mysql_query($runSQL, $connDB);
  $id_location = mysql_insert_id($connDB);
};//if

//recorder log history web access
$runSQL = "select currentdate, session_id, page_access from webpta_user_access where currentdate=CURDATE() and session_id='$SESSION_ID' and ipaddress='$REMOTE_ADDR'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) { 
	$page_access = $row[page_access];
	unset($found_pa);
	$content = explode ("#", $page_access);
	for($i=0; $i<count($content); $i++){
		unset($variabel, $found_page);
		$variabel = explode(";", $content[$i]);
		if ($variabel[0]=="$c_pta:$c_pa"){
			$found_pa = 1;
			for($j=1; $j<count($variabel); $j++){
				unset($value);
				$value = explode(":", $variabel[$j]);
				if ($value[0]==$id_page){ $value[1]=$value[1]+1; $found_page=1; };
				$variabel[$j] = implode(":",$value);
			};//for
			if ($found_page <> 1){ $variabel[$j+1] = "$id_page:1"; };
		};//if
		$content[$i] = implode(";",$variabel);
	};//for
	if ($found_pa <> 1){ $content[$i+1] = "$c_pta:$c_pa;$id_page:1"; };
	$page_access = implode("#",$content);
	
	//echo $page_access;
	$runSQL = "update webpta_user_access set last_time=CURTIME(), hit_count=hit_count+1, page_access='$page_access' where currentdate=CURDATE() and session_id='$SESSION_ID' and ipaddress='$REMOTE_ADDR'";
	$update = mysql_query($runSQL, $connDB);
} else {
	$page_access = "$c_pta:$c_pa;$id_page:1";
	$runSQL = "insert into webpta_user_access (currentdate, session_id, ipaddress, start_time, last_time, hit_count, id_location, id_browser, page_access, var_access) values (CURDATE(), '$SESSION_ID', '$REMOTE_ADDR', CURTIME(), CURTIME(), 1, '$id_location', '$id_browser', '$page_access', ':')";
	$insert = mysql_query($runSQL, $connDB);
};//if
?>
<html>
<head>
  <meta name="Generator" content="EditPlus">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <meta name="Description" content="Pengadilan Tinggi Agama Surabaya">
  <title>Pengadilan Tinggi Agama Surabaya</title>
  <link rel="shortcut icon" href="favicon.ico">
  <link rel="stylesheet" href="pta.css" type="text/css">
</head>
<body bgcolor="#003300">
<table width="100%" height="100%" bgcolor="#003300" border="0" cellpadding="0" cellspacing="0">
  <tr>
	<td width="100%" height="95%" align="center">

		<table border="0" cellpadding="20" cellspacing="0" width="300">
		  <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
			<td width="100%" align="center">
			  <a href="/old/"><b>Masuk</b></a> 
			</td>
		  </tr>
		</table>   

	</td>
  </tr>
  <tr>
	<td width="100%" height="5%" align="right">
	<i>Landing Page Pengadilan Tinggi Agama Surabaya<br>
	<font size="1"><? echo $HTTP_USER_AGENT."<br>Access from ".$REMOTE_ADDR.", View ".$SCRIPT_NAME.$QUERY_STRING;?>
	</i>
	</td>
  </tr>
</table>
</body>
</html>
<?
function get_ip_address() {
	// check for shared internet/ISP IP
	if (!empty($_SERVER['HTTP_CLIENT_IP']) && validate_ip($_SERVER['HTTP_CLIENT_IP'])) {
		return $_SERVER['HTTP_CLIENT_IP'];
	};
	 
	// check for IPs passing through proxies
	if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		// check if multiple ips exist in var
		if (strpos($_SERVER['HTTP_X_FORWARDED_FOR'], ',') !== false) {
			$iplist = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
			foreach ($iplist as $ip) {
				if (validate_ip($ip))
					return $ip;
			};
		} else {
			if (validate_ip($_SERVER['HTTP_X_FORWARDED_FOR']))
				return $_SERVER['HTTP_X_FORWARDED_FOR'];
		};
	};
	if (!empty($_SERVER['HTTP_X_FORWARDED']) && validate_ip($_SERVER['HTTP_X_FORWARDED']))
		return $_SERVER['HTTP_X_FORWARDED'];
	if (!empty($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']) && validate_ip($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
		return $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
	if (!empty($_SERVER['HTTP_FORWARDED_FOR']) && validate_ip($_SERVER['HTTP_FORWARDED_FOR']))
		return $_SERVER['HTTP_FORWARDED_FOR'];
	if (!empty($_SERVER['HTTP_FORWARDED']) && validate_ip($_SERVER['HTTP_FORWARDED']))
		return $_SERVER['HTTP_FORWARDED'];
	 
	// return unreliable ip since all else failed
	if (isset($_SERVER)) {
		return $_SERVER['REMOTE_ADDR'];
	} else {
		return getenv('REMOTE_ADDR');
	};//if
};//get_ip_address

function validate_ip($ip) {
	if (strtolower($ip) === 'unknown')
	return false;
	 
	// generate ipv4 network address
	$ip = ip2long($ip);
	 
	// if the ip is set and not equivalent to 255.255.255.255
	if ($ip !== false && $ip !== -1) {
		// make sure to get unsigned long representation of ip
		// due to discrepancies between 32 and 64 bit OSes and
		// signed numbers (ints default to signed in PHP)
		$ip = sprintf('%u', $ip);
		// do private network range checking
		if ($ip >= 0 && $ip <= 50331647) return false;
		if ($ip >= 167772160 && $ip <= 184549375) return false;
		if ($ip >= 2130706432 && $ip <= 2147483647) return false;
		if ($ip >= 2851995648 && $ip <= 2852061183) return false;
		if ($ip >= 2886729728 && $ip <= 2887778303) return false;
		if ($ip >= 3221225984 && $ip <= 3221226239) return false;
		if ($ip >= 3232235520 && $ip <= 3232301055) return false;
		if ($ip >= 4294967040) return false;
	}
	return true;
};//validate_ip

if ($connDB){ $close = mysql_close($connDB);};
?>