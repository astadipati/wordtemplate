<?php
// Data Statistik dan Pusat Pelaporan Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id
// Contact iyok642@yahoo.com, lastupdate 28 Pebruari 2014

//load setting
include_once("include.php");
include("include_login.php");

//post variable
$run      = $_POST["run"];
$penjalasan  = substr($_POST["penjalasan"],0,200);

//data satker
$runSQL = "select * from laporan_revisi where id_satker=$SESS_ID_SATKER and approval=0";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) { 
	if (strlen($run) < 1){ 
		$penjalasan = $row["penjalasan"];
   };//if
};//if

//submit form
if (strlen($run) > 1){ 
	$runSQL = "select * from laporan_revisi where id_satker=$SESS_ID_SATKER and approval=0";
	$result = mysql_query($runSQL, $connDB);
	if ($row = mysql_fetch_array($result)) {
		$submitValid = 1;
		$runSQL = "update laporan_revisi set penjalasan='$penjalasan' where id_satker=$SESS_ID_SATKER and approval=0";
		$update = mysql_query($runSQL, $connDB);
		//echo "$runSQL<br>";
	} else {
		$submitValid = 1;
		$runSQL = "insert into laporan_revisi (id_satker, id_session, lastupdate, penjalasan, approval) VALUES ('$SESS_ID_SATKER', '$SESSION_ID', now(), '$penjalasan', 0)";
		$insert = mysql_query($runSQL, $connDB);
		//echo "$runSQL<br>";
	};//if
};//end-if-submit

?>
<html>
<head>
  <meta name="Generator" content="EditPlus">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <meta name="Description" content="Sistem Pendaftaran Perkara Secara Online Pengadilan Agama">
  <title>Pengajuan Revisi Laporan</title>
  <link rel="shortcut icon" href="favicon.ico">
  <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
 <tr>
   <td align="center">
	<table width="980" border="0" cellpadding="0" cellspacing="0">
	</table>
	<table width="980" height="450" border="0" cellpadding="0" cellspacing="0" align="center">
	  <tr><td width="100%" colspan="2"><?php include("header.php"); ?></td></tr>
	  <tr>
        <td width="200" valign="top" bgcolor="#336600"><?php include("menu.php"); ?></td>
        <td width="780" valign="top">
		<table width="100%" height="450" bgcolor="#FFFFFF" border="1" cellpadding="10" cellspacing="0" style="border-collapse:collapse" bordercolor="#003300">
		 <tr>
			<td width="100%" vAlign="top">
			<!--content-->
	
<? if ($submitValid <> 1){?>

    <form method="POST" name="form" ENCTYPE="multipart/form-data" action="<? echo $_SERVER["PHP_SELF"]; ?>">
    <table align="center" border="0" cellpadding="5" cellspacing="1" width="750">
      <tr>
        <td width="100%" colspan="5" align="center">
		<font color="#0000FF" size="3"><b>Pengajuan Revisi Laporan</b></font>
        <hr size="1" color="#003300">
		</td>
      </tr>
    </table>
    <table align="center" border="0" cellpadding="5" cellspacing="1" width="500">
      <tr>
        <td bgcolor='#339900' width="100%" colspan="5"><b>Pengajuan Revisi Laporan</b></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="30%" align="left" nowrap>Penjelasan<br>Pengajuan<br>Revisi</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="69%"><textarea rows="4" cols="40" name="penjalasan"><? echo $penjalasan; ?></textarea><?=$ipenjelasan;?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
		<td width="100%" height="60" colspan="4" align="center" valign="middle">
		<input type="submit" value="    Simpan   " name="run" class="button">
		</td>
	  </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
		<td width="100%" height="120" colspan="4" valign="middle">
		1. Uraikan penjelasan dilakukannya revisi laporan, kemudian klik simpan.<br>
		2. Halaman selanjutnya pilih RK yang ingin dilakukan revisi<br>
		3. Pada halaman cetak laporan RK PA akan muncul RK Revisi.<br>
		4. Hasil revisi akan masuk perhitungan setelah mendapat approval.
		</td>
      </tr>

	</table>
    </form>
    <table height="400" align="center" border="0" cellpadding="5" cellspacing="1">
      <tr><td width="100%"> &nbsp; </td></tr>
    </table>

<? }else{?>

    <table align="center" border="0" cellpadding="5" cellspacing="1" width="750">
      <tr>
        <td width="100%" align="center"><font color="#0000FF" size="3"><b>Pejabat Penandatangan Laporan</b></font>
        <hr size="1" color="#003300">
		</td>
      </tr>
    </table>
    <table align="center" border="0" cellpadding="20" cellspacing="1" width="500">
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="100%" align="center">
		Pejabat Penandatangan Laporan <?=$nm_satker_pjg;?> berhasil disimpan.
		</td>
      </tr>
    </table>
    <table height="500" align="center" border="0" cellpadding="5" cellspacing="1">
      <tr>
        <td width="100%">[ <a href="ttd_input.php">Kembali ke Penandatangan</a> ]</td>
      </tr>
    </table>

<? };?>

			<!--end.content-->
			</td>
		 </tr>
		</table>
		</td>
	  </tr>
	  <tr>
        <td width="100%" bgcolor="#004A00" colspan="2"><?php include("footer.php"); ?></td>
	  </tr>
	</table>
    </td>
  </tr>
</table>
</body>
</html>
<?
if ($connDB){ $close = mysql_close($connDB);};
?>