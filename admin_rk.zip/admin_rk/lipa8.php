<?php
// Data Statistik dan Pusat Pelaporan Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id/laporan
// Contact iyok642@yahoo.com, lastupdate 28 Pebruari 2014

//parameter tanggal
$bln = $_POST["bln"]*1; if($bln==""){ $bln = $_GET["bln"]*1; }
$thn = $_POST["thn"]*1; if($thn==""){ $thn = $_GET["thn"]*1; };
$id_satker = $_POST["id_satker"]*1; if($id_satker==""){ $id_satker = $_GET["id_satker"]*1; };

//set default bulan tahun laporan
if ($bln==""){ 
	$bln = (date('m')-1)*1; $thn = date('Y')*1;
	if (date('d')>=25){ $bln = date('m')*1; }
	if ($bln==0){ $bln=12; $thn=(date('Y')-1)*1; }
};//if

//load setting
include_once("include.php");
include("include_login.php");

//data satker
$view_this_satker=$SESS_ID_SATKER;
$runSQL = "select * from laporan_satker where id_satker='$SESS_ID_SATKER'";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$nm_satker_pjg = $row[nm_satker_pjg];
	if (($row[tk_satker]=="PTA")or($row[tk_satker]=="BADILAG")){ $view_this_satker=$id_satker; }
};//while

$styletop = "align='center' style='font-size:8px' nowrap";
$stylebtm = "align='center' style='font-size:10px' nowrap";
$fontbtn = "<b>";

if ($bln<=9){ $this_bln='0'.$bln; }else { $this_bln=$bln; };
$url_request = "id_parent=12&id_satker=$view_this_satker&blnAll=$this_bln&thn=$thn";
$fcontents = @file("http://infoperkara.badilag.net/fungsi_model/lipa/laporan_lipa8_wsdl.php?".$url_request);
//$fcontents = file("http://localhost/lipa/laporan_lipa8_wsdl.php?".$url_request);
//echo "<font size='1'>$url_request</font>";

unset($thisdata);
for ($i=0; $i<count($fcontents); $i++){
	//echo "<pre>".htmlentities($fcontents[$i])."<hr>";
	$pos = strpos ($fcontents[$i], "DATA>");
	if ($pos == true) {
		$fcontents[$i] = substr($fcontents[$i], $pos+5);
		$pos2 = strpos ($fcontents[$i], "</DATA>");
		if ($pos2 == true) {
			$thisdata = substr($fcontents[$i], 0, $pos2);
			//echo "<hr>".$thisdata;
		};//if-pos2
	};//if-pos
};//for

$arr_jenis = array('sisa_lalu', 'diterima', 'jml_1', 'dicabut', 'dikabulkan', 'ditolak', 'tdk_diterima', 'gugur', 'coret', 'jml_2', 'sisa_akhir', 'banding', 'kasasi', 'pk', 'ket');
if ($thisdata <> ""){
	$thisdata = base64_decode(base64_decode($thisdata));
	$linedata = @explode("|#", $thisdata);
	$jumlahrecord = count($linedata);
	//echo "<hr>".$thisdata;

	for ($i=0; $i<$jumlahrecord; $i++){
		//echo "$i. ".$linedata[$i]."<hr>";
		if (strlen($linedata[$i]) > 40){
			$colmdata = @explode("|:", $linedata[$i]);
			//echo $linedata[$i]."<br>";
				
			$id_jenis_perkara = $colmdata[0];
			//echo $colmdata[2];
			for ($ii=0; $ii<count($arr_jenis); $ii++){
				$field_name = $arr_jenis[$ii];
				$data[$id_jenis_perkara][$field_name] += $colmdata[($ii+2)];
				$total[$field_name] += $colmdata[($ii+2)];
				if ($data[$id_jenis_perkara][$field_name] <= 0){ $data[$id_jenis_perkara][$field_name]="<font color='#B5B5B5'>0</font>"; }
			};//for

			$salah=0; 
			$jml_masuk = $colmdata[2]+$colmdata[3];
			$jml_putus = $colmdata[6]+$colmdata[7]+$colmdata[8]+$colmdata[9]+$colmdata[10];
			$jml_sisa = $jml_masuk - ($colmdata[5] + $jml_putus);
			if ($jml_masuk<>$colmdata[4]){ $data[$id_jenis_perkara]['jml_1']="<font color='#FF0000'><strike>".$data[$id_jenis_perkara]['jml_1']."</strike></font><br><font size='1'><i>$jml_masuk"; $salah=1; }
			if ($jml_putus<>$colmdata[11]){ $data[$id_jenis_perkara]['jml_2']="<font color='#FF0000'><strike>".$data[$id_jenis_perkara]['jml_2']."</strike></font><br><font size='1'><i>$jml_putus"; $salah=1; }
			if ($jml_sisa<>$colmdata[12]){ $data[$id_jenis_perkara]['sisa_akhir']="<font color='#FF0000'><strike>".$data[$id_jenis_perkara]['sisa_akhir']."</strike></font><br><font size='1'><i>$jml_sisa"; $salah=1; }
			if ($salah==1){ $data[$id_jenis_perkara]['ket']=$data[$id_jenis_perkara]['ket']."<br><font size='1' color='#FF0000'><i>Salah hitung !!!</font>"; }

		};//if strlen($linedata[$i]>10
	};//for
};//if

/*
$runSQL = "select * from laporan_lipa8 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$id_jenis_perkara = $row[id_jenis_perkara];
	for ($i=0; $i<mysql_num_fields($result); $i++){
		$field_name = mysql_field_name($result, $i);
		$data[$id_jenis_perkara][$field_name] += $row[$field_name];
		$total[$field_name] += $row[$field_name];
		if ($data[$id_jenis_perkara][$field_name] <= 0){ $data[$id_jenis_perkara][$field_name]="<font color='#B5B5B5'>0</font>"; }
	};//for
};//while
*/

?>
<html>
<head>
  <meta name="Generator" content="EditPlus">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <meta name="Description" content="Sistem Pendaftaran Perkara Secara Online Pengadilan Agama">
  <title>Laporan Perkara <? echo $bulan[($bln*1)]." ".$thn; ?></title>
  <link rel="shortcut icon" href="favicon.ico">
  <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body bgcolor="#FFFFFF">

	 <table width="100%" cellspacing="1" cellpadding="3">
	 <tr bgcolor='#339900' height="25">
		<td align="center" rowspan="3">NO<br>URUT</td>
		<td align="center" rowspan="3">JENIS PERKARA</td>
		<td align="center" colspan="3">BANYAKNYA PERKARA</td>
		<td align="center" rowspan="3">DI<br>CABUT</td>
		<td align="center" colspan="6">PUTUS BULAN INI</td>
		<td align="center" rowspan="3">SISA<br>AKHIR<br>BULAN<br>5-(6+12)</td>
		<td align="center" rowspan="3">BAN<br>DING</td>
		<td align="center" rowspan="3">KA<br>SASI</td>
		<td align="center" rowspan="3">PK</td>
		<td align="center" rowspan="3">KETE<br>RANG<br>AN</td>
	 </tr>
	 <tr bgcolor="#339900" height="25">
		<td align="center" rowspan="2">SISA<br>BULAN<br>LALU<?=$thisNamaBulan;?></td>
		<td align="center" colspan="2">DITERIMA</td>
		<td align="center" rowspan="2">DI<br>KABUL<br>KAN</td>
		<td align="center" rowspan="2">DI<br>TOLAK</td>
		<td align="center" rowspan="2">TIDAK<br>DITE<br>RIMA</td>
		<td align="center" rowspan="2">DI<br>GUGUR<br>KAN</td>
		<td align="center" rowspan="2">DI<br>CORET<br>DARI<br>REGIS<br>TER</td>
		<td align="center" rowspan="2">JUMLAH<br>LAJUR<br>7,8,9,<br>10,11</td>
	 </tr>
	 <tr bgcolor="#339900" height="25">
		<td align="center">BULAN<br>INI</td>
		<td align="center">JUMLAH</td>
	 </tr>
	 <tr bgcolor="#339900" height="25">
		<td align="center">1</td>
		<td align="center">2</td>
		<td align="center">3</td>
		<td align="center">4</td>
		<td align="center">5</td>
		<td align="center">6</td>
		<td align="center">7</td>
		<td align="center">8</td>
		<td align="center">9</td>
		<td align="center">10</td>
		<td align="center">11</td>
		<td align="center">12</td>
		<td align="center">13</td>
		<td align="center">14</td>
		<td align="center">15</td>
		<td align="center">16</td>
		<td align="center">17</td>
	 </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center">A</td> <td>PERKAWINAN</td> <td align="center"></td> <td align="center"></td> <td align="center"></td> <td align="center"></td> <td align="center"></td> <td align="center"></td> <td align="center"></td> <td align="center"></td> <td align="center"></td> <td align="center"></td> <td align="center"></td> <td align="center"></td> <td align="center"></td> <td align="center"></td> <td align="center"></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center"></td> <td nowrap><font size='2'>1. Izin Poligami</td> <td align="center"><?=$data['1']['sisa_lalu'];?></td> <td align="center"><?=$data['1']['diterima'];?></td> <td align="center"><?=$data['1']['jml_1'];?></td> <td align="center"><?=$data['1']['dicabut'];?></td> <td align="center"><?=$data['1']['dikabulkan'];?></td> <td align="center"><?=$data['1']['ditolak'];?></td> <td align="center"><?=$data['1']['tdk_diterima'];?></td> <td align="center"><?=$data['1']['gugur'];?></td> <td align="center"><?=$data['1']['coret'];?></td> <td align="center"><?=$data['1']['jml_2'];?></td> <td align="center"><?=$data['1']['sisa_akhir'];?></td> <td align="center"><?=$data['1']['banding'];?></td> <td align="center"><?=$data['1']['kasasi'];?></td> <td align="center"><?=$data['1']['pk'];?></td> <td align="center" nowrap><?=$data['1']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center"></td> <td nowrap><font size='2'>2. Pencegahan Perkawinan</td> <td align="center"><?=$data['2']['sisa_lalu'];?></td> <td align="center"><?=$data['2']['diterima'];?></td> <td align="center"><?=$data['2']['jml_1'];?></td> <td align="center"><?=$data['2']['dicabut'];?></td> <td align="center"><?=$data['2']['dikabulkan'];?></td> <td align="center"><?=$data['2']['ditolak'];?></td> <td align="center"><?=$data['2']['tdk_diterima'];?></td> <td align="center"><?=$data['2']['gugur'];?></td> <td align="center"><?=$data['2']['coret'];?></td> <td align="center"><?=$data['2']['jml_2'];?></td> <td align="center"><?=$data['2']['sisa_akhir'];?></td> <td align="center"><?=$data['2']['banding'];?></td> <td align="center"><?=$data['2']['kasasi'];?></td> <td align="center"><?=$data['2']['pk'];?></td> <td align="center" nowrap><?=$data['2']['ket'];?></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center"></td> <td nowrap><font size='2'>3. Penolakan Perkawinan oleh PPN</td> <td align="center"><?=$data['3']['sisa_lalu'];?></td> <td align="center"><?=$data['3']['diterima'];?></td> <td align="center"><?=$data['3']['jml_1'];?></td> <td align="center"><?=$data['3']['dicabut'];?></td> <td align="center"><?=$data['3']['dikabulkan'];?></td> <td align="center"><?=$data['3']['ditolak'];?></td> <td align="center"><?=$data['3']['tdk_diterima'];?></td> <td align="center"><?=$data['3']['gugur'];?></td> <td align="center"><?=$data['3']['coret'];?></td> <td align="center"><?=$data['3']['jml_2'];?></td> <td align="center"><?=$data['3']['sisa_akhir'];?></td> <td align="center"><?=$data['3']['banding'];?></td> <td align="center"><?=$data['3']['kasasi'];?></td> <td align="center"><?=$data['3']['pk'];?></td> <td align="center" nowrap><?=$data['3']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center"></td> <td nowrap><font size='2'>4. Pembatalan Perkawinan</td> <td align="center"><?=$data['4']['sisa_lalu'];?></td> <td align="center"><?=$data['4']['diterima'];?></td> <td align="center"><?=$data['4']['jml_1'];?></td> <td align="center"><?=$data['4']['dicabut'];?></td> <td align="center"><?=$data['4']['dikabulkan'];?></td> <td align="center"><?=$data['4']['ditolak'];?></td> <td align="center"><?=$data['4']['tdk_diterima'];?></td> <td align="center"><?=$data['4']['gugur'];?></td> <td align="center"><?=$data['4']['coret'];?></td> <td align="center"><?=$data['4']['jml_2'];?></td> <td align="center"><?=$data['4']['sisa_akhir'];?></td> <td align="center"><?=$data['4']['banding'];?></td> <td align="center"><?=$data['4']['kasasi'];?></td> <td align="center"><?=$data['4']['pk'];?></td> <td align="center" nowrap><?=$data['4']['ket'];?></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center"></td> <td nowrap><font size='2'>5. Kelalaian Atas Kewajiban Suami/Istri</td> <td align="center"><?=$data['5']['sisa_lalu'];?></td> <td align="center"><?=$data['5']['diterima'];?></td> <td align="center"><?=$data['5']['jml_1'];?></td> <td align="center"><?=$data['5']['dicabut'];?></td> <td align="center"><?=$data['5']['dikabulkan'];?></td> <td align="center"><?=$data['5']['ditolak'];?></td> <td align="center"><?=$data['5']['tdk_diterima'];?></td> <td align="center"><?=$data['5']['gugur'];?></td> <td align="center"><?=$data['5']['coret'];?></td> <td align="center"><?=$data['5']['jml_2'];?></td> <td align="center"><?=$data['5']['sisa_akhir'];?></td> <td align="center"><?=$data['5']['banding'];?></td> <td align="center"><?=$data['5']['kasasi'];?></td> <td align="center"><?=$data['5']['pk'];?></td> <td align="center" nowrap><?=$data['5']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center"></td> <td nowrap><font size='2'>6. Cerai Talak</td> <td align="center"><?=$data['6']['sisa_lalu'];?></td> <td align="center"><?=$data['6']['diterima'];?></td> <td align="center"><?=$data['6']['jml_1'];?></td> <td align="center"><?=$data['6']['dicabut'];?></td> <td align="center"><?=$data['6']['dikabulkan'];?></td> <td align="center"><?=$data['6']['ditolak'];?></td> <td align="center"><?=$data['6']['tdk_diterima'];?></td> <td align="center"><?=$data['6']['gugur'];?></td> <td align="center"><?=$data['6']['coret'];?></td> <td align="center"><?=$data['6']['jml_2'];?></td> <td align="center"><?=$data['6']['sisa_akhir'];?></td> <td align="center"><?=$data['6']['banding'];?></td> <td align="center"><?=$data['6']['kasasi'];?></td> <td align="center"><?=$data['6']['pk'];?></td> <td align="center" nowrap><?=$data['6']['ket'];?></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center"></td> <td nowrap><font size='2'>7. Cerai Gugat</td> <td align="center"><?=$data['7']['sisa_lalu'];?></td> <td align="center"><?=$data['7']['diterima'];?></td> <td align="center"><?=$data['7']['jml_1'];?></td> <td align="center"><?=$data['7']['dicabut'];?></td> <td align="center"><?=$data['7']['dikabulkan'];?></td> <td align="center"><?=$data['7']['ditolak'];?></td> <td align="center"><?=$data['7']['tdk_diterima'];?></td> <td align="center"><?=$data['7']['gugur'];?></td> <td align="center"><?=$data['7']['coret'];?></td> <td align="center"><?=$data['7']['jml_2'];?></td> <td align="center"><?=$data['7']['sisa_akhir'];?></td> <td align="center"><?=$data['7']['banding'];?></td> <td align="center"><?=$data['7']['kasasi'];?></td> <td align="center"><?=$data['7']['pk'];?></td> <td align="center" nowrap><?=$data['7']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center"></td> <td nowrap><font size='2'>8. Harta Bersama</td> <td align="center"><?=$data['8']['sisa_lalu'];?></td> <td align="center"><?=$data['8']['diterima'];?></td> <td align="center"><?=$data['8']['jml_1'];?></td> <td align="center"><?=$data['8']['dicabut'];?></td> <td align="center"><?=$data['8']['dikabulkan'];?></td> <td align="center"><?=$data['8']['ditolak'];?></td> <td align="center"><?=$data['8']['tdk_diterima'];?></td> <td align="center"><?=$data['8']['gugur'];?></td> <td align="center"><?=$data['8']['coret'];?></td> <td align="center"><?=$data['8']['jml_2'];?></td> <td align="center"><?=$data['8']['sisa_akhir'];?></td> <td align="center"><?=$data['8']['banding'];?></td> <td align="center"><?=$data['8']['kasasi'];?></td> <td align="center"><?=$data['8']['pk'];?></td> <td align="center" nowrap><?=$data['8']['ket'];?></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center"></td> <td nowrap><font size='2'>9. Penguasaan Anak</td> <td align="center"><?=$data['9']['sisa_lalu'];?></td> <td align="center"><?=$data['9']['diterima'];?></td> <td align="center"><?=$data['9']['jml_1'];?></td> <td align="center"><?=$data['9']['dicabut'];?></td> <td align="center"><?=$data['9']['dikabulkan'];?></td> <td align="center"><?=$data['9']['ditolak'];?></td> <td align="center"><?=$data['9']['tdk_diterima'];?></td> <td align="center"><?=$data['9']['gugur'];?></td> <td align="center"><?=$data['9']['coret'];?></td> <td align="center"><?=$data['9']['jml_2'];?></td> <td align="center"><?=$data['9']['sisa_akhir'];?></td> <td align="center"><?=$data['9']['banding'];?></td> <td align="center"><?=$data['9']['kasasi'];?></td> <td align="center"><?=$data['9']['pk'];?></td> <td align="center" nowrap><?=$data['9']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center"></td> <td nowrap><font size='2'>10. Nafkah Anak Oleh Ibu Karena Ayah Tidak Mampu</td> <td align="center"><?=$data['10']['sisa_lalu'];?></td> <td align="center"><?=$data['10']['diterima'];?></td> <td align="center"><?=$data['10']['jml_1'];?></td> <td align="center"><?=$data['10']['dicabut'];?></td> <td align="center"><?=$data['10']['dikabulkan'];?></td> <td align="center"><?=$data['10']['ditolak'];?></td> <td align="center"><?=$data['10']['tdk_diterima'];?></td> <td align="center"><?=$data['10']['gugur'];?></td> <td align="center"><?=$data['10']['coret'];?></td> <td align="center"><?=$data['10']['jml_2'];?></td> <td align="center"><?=$data['10']['sisa_akhir'];?></td> <td align="center"><?=$data['10']['banding'];?></td> <td align="center"><?=$data['10']['kasasi'];?></td> <td align="center"><?=$data['10']['pk'];?></td> <td align="center" nowrap><?=$data['10']['ket'];?></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center"></td> <td nowrap><font size='2'>11. Hak - Hak Bekas Istri/Kewajiban Bekas Suami</td> <td align="center"><?=$data['11']['sisa_lalu'];?></td> <td align="center"><?=$data['11']['diterima'];?></td> <td align="center"><?=$data['11']['jml_1'];?></td> <td align="center"><?=$data['11']['dicabut'];?></td> <td align="center"><?=$data['11']['dikabulkan'];?></td> <td align="center"><?=$data['11']['ditolak'];?></td> <td align="center"><?=$data['11']['tdk_diterima'];?></td> <td align="center"><?=$data['11']['gugur'];?></td> <td align="center"><?=$data['11']['coret'];?></td> <td align="center"><?=$data['11']['jml_2'];?></td> <td align="center"><?=$data['11']['sisa_akhir'];?></td> <td align="center"><?=$data['11']['banding'];?></td> <td align="center"><?=$data['11']['kasasi'];?></td> <td align="center"><?=$data['11']['pk'];?></td> <td align="center" nowrap><?=$data['11']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center"></td> <td nowrap><font size='2'>12. Pengesahan Anak</td> <td align="center"><?=$data['12']['sisa_lalu'];?></td> <td align="center"><?=$data['12']['diterima'];?></td> <td align="center"><?=$data['12']['jml_1'];?></td> <td align="center"><?=$data['12']['dicabut'];?></td> <td align="center"><?=$data['12']['dikabulkan'];?></td> <td align="center"><?=$data['12']['ditolak'];?></td> <td align="center"><?=$data['12']['tdk_diterima'];?></td> <td align="center"><?=$data['12']['gugur'];?></td> <td align="center"><?=$data['12']['coret'];?></td> <td align="center"><?=$data['12']['jml_2'];?></td> <td align="center"><?=$data['12']['sisa_akhir'];?></td> <td align="center"><?=$data['12']['banding'];?></td> <td align="center"><?=$data['12']['kasasi'];?></td> <td align="center"><?=$data['12']['pk'];?></td> <td align="center" nowrap><?=$data['12']['ket'];?></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center"></td> <td nowrap><font size='2'>13. Pencabutan Kekuasaan Orang Tua</td> <td align="center"><?=$data['13']['sisa_lalu'];?></td> <td align="center"><?=$data['13']['diterima'];?></td> <td align="center"><?=$data['13']['jml_1'];?></td> <td align="center"><?=$data['13']['dicabut'];?></td> <td align="center"><?=$data['13']['dikabulkan'];?></td> <td align="center"><?=$data['13']['ditolak'];?></td> <td align="center"><?=$data['13']['tdk_diterima'];?></td> <td align="center"><?=$data['13']['gugur'];?></td> <td align="center"><?=$data['13']['coret'];?></td> <td align="center"><?=$data['13']['jml_2'];?></td> <td align="center"><?=$data['13']['sisa_akhir'];?></td> <td align="center"><?=$data['13']['banding'];?></td> <td align="center"><?=$data['13']['kasasi'];?></td> <td align="center"><?=$data['13']['pk'];?></td> <td align="center" nowrap><?=$data['13']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center"></td> <td nowrap><font size='2'>14. Perwalian</td> <td align="center"><?=$data['14']['sisa_lalu'];?></td> <td align="center"><?=$data['14']['diterima'];?></td> <td align="center"><?=$data['14']['jml_1'];?></td> <td align="center"><?=$data['14']['dicabut'];?></td> <td align="center"><?=$data['14']['dikabulkan'];?></td> <td align="center"><?=$data['14']['ditolak'];?></td> <td align="center"><?=$data['14']['tdk_diterima'];?></td> <td align="center"><?=$data['14']['gugur'];?></td> <td align="center"><?=$data['14']['coret'];?></td> <td align="center"><?=$data['14']['jml_2'];?></td> <td align="center"><?=$data['14']['sisa_akhir'];?></td> <td align="center"><?=$data['14']['banding'];?></td> <td align="center"><?=$data['14']['kasasi'];?></td> <td align="center"><?=$data['14']['pk'];?></td> <td align="center" nowrap><?=$data['14']['ket'];?></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center"></td> <td nowrap><font size='2'>15. Pencabutan Kekuasaan Wali</td> <td align="center"><?=$data['15']['sisa_lalu'];?></td> <td align="center"><?=$data['15']['diterima'];?></td> <td align="center"><?=$data['15']['jml_1'];?></td> <td align="center"><?=$data['15']['dicabut'];?></td> <td align="center"><?=$data['15']['dikabulkan'];?></td> <td align="center"><?=$data['15']['ditolak'];?></td> <td align="center"><?=$data['15']['tdk_diterima'];?></td> <td align="center"><?=$data['15']['gugur'];?></td> <td align="center"><?=$data['15']['coret'];?></td> <td align="center"><?=$data['15']['jml_2'];?></td> <td align="center"><?=$data['15']['sisa_akhir'];?></td> <td align="center"><?=$data['15']['banding'];?></td> <td align="center"><?=$data['15']['kasasi'];?></td> <td align="center"><?=$data['15']['pk'];?></td> <td align="center" nowrap><?=$data['15']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center"></td> <td nowrap><font size='2'>16. Penunjukan Orang Lain Sebagai Wali</td> <td align="center"><?=$data['16']['sisa_lalu'];?></td> <td align="center"><?=$data['16']['diterima'];?></td> <td align="center"><?=$data['16']['jml_1'];?></td> <td align="center"><?=$data['16']['dicabut'];?></td> <td align="center"><?=$data['16']['dikabulkan'];?></td> <td align="center"><?=$data['16']['ditolak'];?></td> <td align="center"><?=$data['16']['tdk_diterima'];?></td> <td align="center"><?=$data['16']['gugur'];?></td> <td align="center"><?=$data['16']['coret'];?></td> <td align="center"><?=$data['16']['jml_2'];?></td> <td align="center"><?=$data['16']['sisa_akhir'];?></td> <td align="center"><?=$data['16']['banding'];?></td> <td align="center"><?=$data['16']['kasasi'];?></td> <td align="center"><?=$data['16']['pk'];?></td> <td align="center" nowrap><?=$data['16']['ket'];?></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center"></td> <td nowrap><font size='2'>17. Ganti Rugi Terhadap Wali</td> <td align="center"><?=$data['17']['sisa_lalu'];?></td> <td align="center"><?=$data['17']['diterima'];?></td> <td align="center"><?=$data['17']['jml_1'];?></td> <td align="center"><?=$data['17']['dicabut'];?></td> <td align="center"><?=$data['17']['dikabulkan'];?></td> <td align="center"><?=$data['17']['ditolak'];?></td> <td align="center"><?=$data['17']['tdk_diterima'];?></td> <td align="center"><?=$data['17']['gugur'];?></td> <td align="center"><?=$data['17']['coret'];?></td> <td align="center"><?=$data['17']['jml_2'];?></td> <td align="center"><?=$data['17']['sisa_akhir'];?></td> <td align="center"><?=$data['17']['banding'];?></td> <td align="center"><?=$data['17']['kasasi'];?></td> <td align="center"><?=$data['17']['pk'];?></td> <td align="center" nowrap><?=$data['17']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center"></td> <td nowrap><font size='2'>18. Asal Usul Anak</td> <td align="center"><?=$data['18']['sisa_lalu'];?></td> <td align="center"><?=$data['18']['diterima'];?></td> <td align="center"><?=$data['18']['jml_1'];?></td> <td align="center"><?=$data['18']['dicabut'];?></td> <td align="center"><?=$data['18']['dikabulkan'];?></td> <td align="center"><?=$data['18']['ditolak'];?></td> <td align="center"><?=$data['18']['tdk_diterima'];?></td> <td align="center"><?=$data['18']['gugur'];?></td> <td align="center"><?=$data['18']['coret'];?></td> <td align="center"><?=$data['18']['jml_2'];?></td> <td align="center"><?=$data['18']['sisa_akhir'];?></td> <td align="center"><?=$data['18']['banding'];?></td> <td align="center"><?=$data['18']['kasasi'];?></td> <td align="center"><?=$data['18']['pk'];?></td> <td align="center" nowrap><?=$data['18']['ket'];?></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center"></td> <td nowrap><font size='2'>19. Penetapan Kawin Campuran</td> <td align="center"><?=$data['19']['sisa_lalu'];?></td> <td align="center"><?=$data['19']['diterima'];?></td> <td align="center"><?=$data['19']['jml_1'];?></td> <td align="center"><?=$data['19']['dicabut'];?></td> <td align="center"><?=$data['19']['dikabulkan'];?></td> <td align="center"><?=$data['19']['ditolak'];?></td> <td align="center"><?=$data['19']['tdk_diterima'];?></td> <td align="center"><?=$data['19']['gugur'];?></td> <td align="center"><?=$data['19']['coret'];?></td> <td align="center"><?=$data['19']['jml_2'];?></td> <td align="center"><?=$data['19']['sisa_akhir'];?></td> <td align="center"><?=$data['19']['banding'];?></td> <td align="center"><?=$data['19']['kasasi'];?></td> <td align="center"><?=$data['19']['pk'];?></td> <td align="center" nowrap><?=$data['19']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center"></td> <td nowrap><font size='2'>20. Istbat Nikah</td> <td align="center"><?=$data['20']['sisa_lalu'];?></td> <td align="center"><?=$data['20']['diterima'];?></td> <td align="center"><?=$data['20']['jml_1'];?></td> <td align="center"><?=$data['20']['dicabut'];?></td> <td align="center"><?=$data['20']['dikabulkan'];?></td> <td align="center"><?=$data['20']['ditolak'];?></td> <td align="center"><?=$data['20']['tdk_diterima'];?></td> <td align="center"><?=$data['20']['gugur'];?></td> <td align="center"><?=$data['20']['coret'];?></td> <td align="center"><?=$data['20']['jml_2'];?></td> <td align="center"><?=$data['20']['sisa_akhir'];?></td> <td align="center"><?=$data['20']['banding'];?></td> <td align="center"><?=$data['20']['kasasi'];?></td> <td align="center"><?=$data['20']['pk'];?></td> <td align="center" nowrap><?=$data['20']['ket'];?></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center"></td> <td nowrap><font size='2'>21. Izin Kawin</td> <td align="center"><?=$data['21']['sisa_lalu'];?></td> <td align="center"><?=$data['21']['diterima'];?></td> <td align="center"><?=$data['21']['jml_1'];?></td> <td align="center"><?=$data['21']['dicabut'];?></td> <td align="center"><?=$data['21']['dikabulkan'];?></td> <td align="center"><?=$data['21']['ditolak'];?></td> <td align="center"><?=$data['21']['tdk_diterima'];?></td> <td align="center"><?=$data['21']['gugur'];?></td> <td align="center"><?=$data['21']['coret'];?></td> <td align="center"><?=$data['21']['jml_2'];?></td> <td align="center"><?=$data['21']['sisa_akhir'];?></td> <td align="center"><?=$data['21']['banding'];?></td> <td align="center"><?=$data['21']['kasasi'];?></td> <td align="center"><?=$data['21']['pk'];?></td> <td align="center" nowrap><?=$data['21']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center"></td> <td nowrap><font size='2'>22. Dispensasi Kawin</td> <td align="center"><?=$data['22']['sisa_lalu'];?></td> <td align="center"><?=$data['22']['diterima'];?></td> <td align="center"><?=$data['22']['jml_1'];?></td> <td align="center"><?=$data['22']['dicabut'];?></td> <td align="center"><?=$data['22']['dikabulkan'];?></td> <td align="center"><?=$data['22']['ditolak'];?></td> <td align="center"><?=$data['22']['tdk_diterima'];?></td> <td align="center"><?=$data['22']['gugur'];?></td> <td align="center"><?=$data['22']['coret'];?></td> <td align="center"><?=$data['22']['jml_2'];?></td> <td align="center"><?=$data['22']['sisa_akhir'];?></td> <td align="center"><?=$data['22']['banding'];?></td> <td align="center"><?=$data['22']['kasasi'];?></td> <td align="center"><?=$data['22']['pk'];?></td> <td align="center" nowrap><?=$data['22']['ket'];?></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center"></td> <td nowrap><font size='2'>23. Wali Adhol</td> <td align="center"><?=$data['23']['sisa_lalu'];?></td> <td align="center"><?=$data['23']['diterima'];?></td> <td align="center"><?=$data['23']['jml_1'];?></td> <td align="center"><?=$data['23']['dicabut'];?></td> <td align="center"><?=$data['23']['dikabulkan'];?></td> <td align="center"><?=$data['23']['ditolak'];?></td> <td align="center"><?=$data['23']['tdk_diterima'];?></td> <td align="center"><?=$data['23']['gugur'];?></td> <td align="center"><?=$data['23']['coret'];?></td> <td align="center"><?=$data['23']['jml_2'];?></td> <td align="center"><?=$data['23']['sisa_akhir'];?></td> <td align="center"><?=$data['23']['banding'];?></td> <td align="center"><?=$data['23']['kasasi'];?></td> <td align="center"><?=$data['23']['pk'];?></td> <td align="center" nowrap><?=$data['23']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center"></td> <td nowrap><font size='2'>24. Pengangkatan Anak</td> <td align="center"><?=$data['24']['sisa_lalu'];?></td> <td align="center"><?=$data['24']['diterima'];?></td> <td align="center"><?=$data['24']['jml_1'];?></td> <td align="center"><?=$data['24']['dicabut'];?></td> <td align="center"><?=$data['24']['dikabulkan'];?></td> <td align="center"><?=$data['24']['ditolak'];?></td> <td align="center"><?=$data['24']['tdk_diterima'];?></td> <td align="center"><?=$data['24']['gugur'];?></td> <td align="center"><?=$data['24']['coret'];?></td> <td align="center"><?=$data['24']['jml_2'];?></td> <td align="center"><?=$data['24']['sisa_akhir'];?></td> <td align="center"><?=$data['24']['banding'];?></td> <td align="center"><?=$data['24']['kasasi'];?></td> <td align="center"><?=$data['24']['pk'];?></td> <td align="center" nowrap><?=$data['24']['ket'];?></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center">B</td> <td nowrap>EKONOMI SYARIAH</td> <td align="center"><?=$data['25']['sisa_lalu'];?></td> <td align="center"><?=$data['25']['diterima'];?></td> <td align="center"><?=$data['25']['jml_1'];?></td> <td align="center"><?=$data['25']['dicabut'];?></td> <td align="center"><?=$data['25']['dikabulkan'];?></td> <td align="center"><?=$data['25']['ditolak'];?></td> <td align="center"><?=$data['25']['tdk_diterima'];?></td> <td align="center"><?=$data['25']['gugur'];?></td> <td align="center"><?=$data['25']['coret'];?></td> <td align="center"><?=$data['25']['jml_2'];?></td> <td align="center"><?=$data['25']['sisa_akhir'];?></td> <td align="center"><?=$data['25']['banding'];?></td> <td align="center"><?=$data['25']['kasasi'];?></td> <td align="center"><?=$data['25']['pk'];?></td> <td align="center" nowrap><?=$data['25']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center">C</td> <td nowrap>KEWARISAN</td> <td align="center"><?=$data['26']['sisa_lalu'];?></td> <td align="center"><?=$data['26']['diterima'];?></td> <td align="center"><?=$data['26']['jml_1'];?></td> <td align="center"><?=$data['26']['dicabut'];?></td> <td align="center"><?=$data['26']['dikabulkan'];?></td> <td align="center"><?=$data['26']['ditolak'];?></td> <td align="center"><?=$data['26']['tdk_diterima'];?></td> <td align="center"><?=$data['26']['gugur'];?></td> <td align="center"><?=$data['26']['coret'];?></td> <td align="center"><?=$data['26']['jml_2'];?></td> <td align="center"><?=$data['26']['sisa_akhir'];?></td> <td align="center"><?=$data['26']['banding'];?></td> <td align="center"><?=$data['26']['kasasi'];?></td> <td align="center"><?=$data['26']['pk'];?></td> <td align="center" nowrap><?=$data['26']['ket'];?></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center">D</td> <td nowrap>WASIAT</td> <td align="center"><?=$data['27']['sisa_lalu'];?></td> <td align="center"><?=$data['27']['diterima'];?></td> <td align="center"><?=$data['27']['jml_1'];?></td> <td align="center"><?=$data['27']['dicabut'];?></td> <td align="center"><?=$data['27']['dikabulkan'];?></td> <td align="center"><?=$data['27']['ditolak'];?></td> <td align="center"><?=$data['27']['tdk_diterima'];?></td> <td align="center"><?=$data['27']['gugur'];?></td> <td align="center"><?=$data['27']['coret'];?></td> <td align="center"><?=$data['27']['jml_2'];?></td> <td align="center"><?=$data['27']['sisa_akhir'];?></td> <td align="center"><?=$data['27']['banding'];?></td> <td align="center"><?=$data['27']['kasasi'];?></td> <td align="center"><?=$data['27']['pk'];?></td> <td align="center" nowrap><?=$data['27']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center">E</td> <td nowrap>HIBAH</td> <td align="center"><?=$data['28']['sisa_lalu'];?></td> <td align="center"><?=$data['28']['diterima'];?></td> <td align="center"><?=$data['28']['jml_1'];?></td> <td align="center"><?=$data['28']['dicabut'];?></td> <td align="center"><?=$data['28']['dikabulkan'];?></td> <td align="center"><?=$data['28']['ditolak'];?></td> <td align="center"><?=$data['28']['tdk_diterima'];?></td> <td align="center"><?=$data['28']['gugur'];?></td> <td align="center"><?=$data['28']['coret'];?></td> <td align="center"><?=$data['28']['jml_2'];?></td> <td align="center"><?=$data['28']['sisa_akhir'];?></td> <td align="center"><?=$data['28']['banding'];?></td> <td align="center"><?=$data['28']['kasasi'];?></td> <td align="center"><?=$data['28']['pk'];?></td> <td align="center" nowrap><?=$data['28']['ket'];?></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center">F</td> <td nowrap>WAKAF</td> <td align="center"><?=$data['29']['sisa_lalu'];?></td> <td align="center"><?=$data['29']['diterima'];?></td> <td align="center"><?=$data['29']['jml_1'];?></td> <td align="center"><?=$data['29']['dicabut'];?></td> <td align="center"><?=$data['29']['dikabulkan'];?></td> <td align="center"><?=$data['29']['ditolak'];?></td> <td align="center"><?=$data['29']['tdk_diterima'];?></td> <td align="center"><?=$data['29']['gugur'];?></td> <td align="center"><?=$data['29']['coret'];?></td> <td align="center"><?=$data['29']['jml_2'];?></td> <td align="center"><?=$data['29']['sisa_akhir'];?></td> <td align="center"><?=$data['29']['banding'];?></td> <td align="center"><?=$data['29']['kasasi'];?></td> <td align="center"><?=$data['29']['pk'];?></td> <td align="center" nowrap><?=$data['29']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center">G</td> <td nowrap>ZAKAT/INFAQ/SHODAQOH</td> <td align="center"><?=$data['30']['sisa_lalu'];?></td> <td align="center"><?=$data['30']['diterima'];?></td> <td align="center"><?=$data['30']['jml_1'];?></td> <td align="center"><?=$data['30']['dicabut'];?></td> <td align="center"><?=$data['30']['dikabulkan'];?></td> <td align="center"><?=$data['30']['ditolak'];?></td> <td align="center"><?=$data['30']['tdk_diterima'];?></td> <td align="center"><?=$data['30']['gugur'];?></td> <td align="center"><?=$data['30']['coret'];?></td> <td align="center"><?=$data['30']['jml_2'];?></td> <td align="center"><?=$data['30']['sisa_akhir'];?></td> <td align="center"><?=$data['30']['banding'];?></td> <td align="center"><?=$data['30']['kasasi'];?></td> <td align="center"><?=$data['30']['pk'];?></td> <td align="center" nowrap><?=$data['30']['ket'];?></td> </tr>
	 <tr bgcolor="#EEFBE1" height="25"> <td align="center">H</td> <td nowrap>P3HP/Penetapan Ahli Waris</td> <td align="center"><?=$data['31']['sisa_lalu'];?></td> <td align="center"><?=$data['31']['diterima'];?></td> <td align="center"><?=$data['31']['jml_1'];?></td> <td align="center"><?=$data['31']['dicabut'];?></td> <td align="center"><?=$data['31']['dikabulkan'];?></td> <td align="center"><?=$data['31']['ditolak'];?></td> <td align="center"><?=$data['31']['tdk_diterima'];?></td> <td align="center"><?=$data['31']['gugur'];?></td> <td align="center"><?=$data['31']['coret'];?></td> <td align="center"><?=$data['31']['jml_2'];?></td> <td align="center"><?=$data['31']['sisa_akhir'];?></td> <td align="center"><?=$data['31']['banding'];?></td> <td align="center"><?=$data['31']['kasasi'];?></td> <td align="center"><?=$data['31']['pk'];?></td> <td align="center" nowrap><?=$data['31']['ket'];?></td> </tr>
	 <tr bgcolor="#CCFA9A" height="25"> <td align="center">I</td> <td nowrap>LAIN-LAIN *)</td> <td align="center"><?=$data['32']['sisa_lalu'];?></td> <td align="center"><?=$data['32']['diterima'];?></td> <td align="center"><?=$data['32']['jml_1'];?></td> <td align="center"><?=$data['32']['dicabut'];?></td> <td align="center"><?=$data['32']['dikabulkan'];?></td> <td align="center"><?=$data['32']['ditolak'];?></td> <td align="center"><?=$data['32']['tdk_diterima'];?></td> <td align="center"><?=$data['32']['gugur'];?></td> <td align="center"><?=$data['32']['coret'];?></td> <td align="center"><?=$data['32']['jml_2'];?></td> <td align="center"><?=$data['32']['sisa_akhir'];?></td> <td align="center"><?=$data['32']['banding'];?></td> <td align="center"><?=$data['32']['kasasi'];?></td> <td align="center"><?=$data['32']['pk'];?></td> <td align="center" nowrap><?=$data['32']['ket'];?></td> </tr>
	 <tr bgcolor="#339900" height="25"> <td align="center" colspan="2" nowrap>JUMLAH</td> <td align="center"><?=$total['sisa_lalu'];?></td> <td align="center"><?=$total['diterima'];?></td> <td align="center"><?=$total['jml_1'];?></td> <td align="center"><?=$total['dicabut'];?></td> <td align="center"><?=$total['dikabulkan'];?></td> <td align="center"><?=$total['ditolak'];?></td> <td align="center"><?=$total['tdk_diterima'];?></td> <td align="center"><?=$total['gugur'];?></td> <td align="center"><?=$total['coret'];?></td> <td align="center"><?=$total['jml_2'];?></td> <td align="center"><?=$total['sisa_akhir'];?></td> <td align="center"><?=$total['banding'];?></td> <td align="center"><?=$total['kasasi'];?></td> <td align="center"><?=$total['pk'];?></td> <td align="center" nowrap><?=$total['ket'];?></td> </tr>
	 </table>


</body>
</html>
<?
if ($connDB){ $close = mysql_close($connDB);};
?>