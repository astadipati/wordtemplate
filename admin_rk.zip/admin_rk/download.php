<?php
// Data Statistik dan Pusat Pelaporan Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id
// Contact iyok642@yahoo.com, lastupdate 28 Pebruari 2014

@set_time_limit(3600);
@ini_set('memory_limit','1024M');

//parameter tanggal
$bln = $_POST["bln"]*1; if($bln==""){ $bln = $_GET["bln"]*1; }
$thn = $_POST["thn"]*1; if($thn==""){ $thn = $_GET["thn"]*1; };
$id_satker = $_POST["id_satker"]*1; if($id_satker==""){ $id_satker = $_GET["id_satker"]*1; };

//set default bulan tahun laporan
if ($bln==""){ 
	$bln = (date('m')-1)*1; $thn = date('Y')*1;
	if (date('d')>=25){ $bln = date('m')*1; }
	if ($bln==0){ $bln=12; $thn=(date('Y')-1)*1; }
};//if

$lastday = date ("t", mktime(0,0,0,$bln,1,$thn));
$numbday = date ("N", mktime(0,0,0,$bln,$lastday,$thn));
if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

//load setting
include_once("include.php");
include("include_login.php");

//satker user akses
$view_this_satker=$SESS_ID_SATKER;
$runSQL = "select * from laporan_satker where id_satker='$SESS_ID_SATKER'";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	if (($row[tk_satker]=="PTA")or($row[tk_satker]=="BADILAG")){ $view_this_satker=$id_satker; }
};//while

//profile satker
$runSQL = "select * from laporan_satker where id_satker='$view_this_satker'";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$kode_perkara = $row[kode_perkara];
	$nama_satker = $row[nm_satker_pjg];
	$alamat_satker = $row[almt_satker];
	$website_email = "Website: ".$row[url_satker]." Email: ".$row[email_satker];
	$nama_ketua = $row[nama_ketua];
	$nama_pansek = $row[nama_pansek];
	$nama_kota = $row[nama_kota];
};//while



/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2013 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2013 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    1.7.9, 2013-06-02
 */

/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
date_default_timezone_set('Europe/London');

if (PHP_SAPI == 'cli')
	die('This example should only be run from a Web Browser');

/** Include PHPExcel */
require_once 'excell/PHPExcel.php';

if ($thn >= 2017){
  $fileTemplate = "master_rk_pa2017.xls";
} else {
  $fileTemplate = "master_rk_pa.xls";
};//if
$fileDownload = "RK_".strtoupper($kode_perkara)."_".$bulan[($bln*1)]."_".$thn.".xls";

// Create new PHPExcel object
//$objPHPExcel = new PHPExcel();

// Read the file
$objReader = PHPExcel_IOFactory::createReader('Excel5');
$objPHPExcel = $objReader->load($fileTemplate);


// Set document properties
$objPHPExcel->getProperties()->setCreator("iyok642")
							 ->setLastModifiedBy("pta-surabaya.go.id")
							 ->setTitle("Laporan Perkara Pengadilan Agama")
							 ->setSubject("Laporan Perkara Pengadilan Agama")
							 ->setDescription("Pusat Pelaporan Data Perkara SiADPA & SiADPTA Online")
							 ->setKeywords("Pusat Pelaporan Data Perkara SiADPA & SiADPTA Online")
							 ->setCategory("Pusat Pelaporan Data Perkara SiADPA & SiADPTA Online");

// Add some data
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A1", strtoupper($nama_satker))
            ->setCellValue("A2", $alamat_satker)
            ->setCellValue("A3", $website_email)
            ->setCellValue("A5", "BULAN ".strtoupper($bulan[($bln*1)])." TAHUN ".$thn)
            ->setCellValue("C76", "Ketua ".$nama_satker)
            ->setCellValue("C81", $nama_ketua)
            ->setCellValue("AA75", $nama_kota.", ".$lastday." ".$bulan[($bln*1)]." ".$thn)
            ->setCellValue("AA81", $nama_pansek);
			
//laporan rk.3
$runSQL = "select * from laporan_rk3 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk3 = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A9", "1")
            ->setCellValue("B9", $rk3["kolom_2"])
            ->setCellValue("C9", $rk3["kolom_3"])
            ->setCellValue("D9", $rk3["kolom_4"])
            ->setCellValue("E9", $rk3["kolom_5"])
            ->setCellValue("F9", $rk3["kolom_6"])
            ->setCellValue("G9", $rk3["kolom_7"])
            ->setCellValue("H9", $rk3["kolom_8"])
            ->setCellValue("I9", $rk3["kolom_9"])
            ->setCellValue("J9", $rk3["kolom_10"])
            ->setCellValue("K9", $rk3["kolom_11"])
            ->setCellValue("L9", $rk3["kolom_12"])
            ->setCellValue("M9", $rk3["kolom_13"])
            ->setCellValue("N9", $rk3["kolom_14"])
            ->setCellValue("O9", $rk3["kolom_15"])
            ->setCellValue("P9", $rk3["kolom_16"])
            ->setCellValue("Q9", $rk3["kolom_17"])
            ->setCellValue("R9", $rk3["kolom_18"])
            ->setCellValue("S9", $rk3["kolom_19"])
            ->setCellValue("T9", $rk3["kolom_20"])
            ->setCellValue("U9", $rk3["kolom_21"])
            ->setCellValue("V9", $rk3["kolom_22"])
            ->setCellValue("W9", $rk3["kolom_23"])
            ->setCellValue("X9", $rk3["kolom_24"])
            ->setCellValue("Y9", $rk3["kolom_25"])
            ->setCellValue("Z9", $rk3["kolom_26"])
            ->setCellValue("AA9", $rk3["kolom_27"])
            ->setCellValue("AB9", $rk3["kolom_28"])
            ->setCellValue("AC9", $rk3["kolom_29"])
            ->setCellValue("AD9", $rk3["kolom_30"])
            ->setCellValue("AE9", $rk3["kolom_31"])
            ->setCellValue("AF9", $rk3["kolom_32"])
            ->setCellValue("AG9", $rk3["kolom_33"])
            ->setCellValue("AH9", $rk3["kolom_34"])
            ->setCellValue("AI9", $rk3["kolom_35"]);

//laporan rk.4
$runSQL = "select * from laporan_rk4 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk4 = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A13", "1")
            ->setCellValue("B13", $rk4["kolom_2"])
            ->setCellValue("C13", $rk4["kolom_3"])
            ->setCellValue("D13", $rk4["kolom_4"])
            ->setCellValue("E13", $rk4["kolom_5"])
            ->setCellValue("F13", $rk4["kolom_6"])
            ->setCellValue("G13", $rk4["kolom_7"])
            ->setCellValue("H13", $rk4["kolom_8"])
            ->setCellValue("I13", $rk4["kolom_9"])
            ->setCellValue("J13", $rk4["kolom_10"])
            ->setCellValue("K13", $rk4["kolom_11"])
            ->setCellValue("L13", $rk4["kolom_12"])
            ->setCellValue("M13", $rk4["kolom_13"])
            ->setCellValue("N13", $rk4["kolom_14"])
            ->setCellValue("O13", $rk4["kolom_15"])
            ->setCellValue("P13", $rk4["kolom_16"])
            ->setCellValue("Q13", $rk4["kolom_17"])
            ->setCellValue("R13", $rk4["kolom_18"])
            ->setCellValue("S13", $rk4["kolom_19"])
            ->setCellValue("T13", $rk4["kolom_20"])
            ->setCellValue("U13", $rk4["kolom_21"])
            ->setCellValue("V13", $rk4["kolom_22"])
            ->setCellValue("W13", $rk4["kolom_23"])
            ->setCellValue("X13", $rk4["kolom_24"])
            ->setCellValue("Y13", $rk4["kolom_25"])
            ->setCellValue("Z13", $rk4["kolom_26"])
            ->setCellValue("AA13", $rk4["kolom_27"])
            ->setCellValue("AB13", $rk4["kolom_28"])
            ->setCellValue("AC13", $rk4["kolom_29"])
            ->setCellValue("AD13", $rk4["kolom_30"])
            ->setCellValue("AE13", $rk4["kolom_31"])
            ->setCellValue("AF13", $rk4["kolom_32"])
            ->setCellValue("AG13", $rk4["kolom_33"])
            ->setCellValue("AH13", $rk4["kolom_34"])
            ->setCellValue("AI13", $rk4["kolom_35"])
            ->setCellValue("AJ13", $rk4["kolom_36"])
            ->setCellValue("AK13", $rk4["kolom_37"])
            ->setCellValue("AL13", $rk4["kolom_38"])
            ->setCellValue("AM13", $rk4["kolom_39"])
            ->setCellValue("AN13", $rk4["kolom_40"])
            ->setCellValue("AO13", $rk4["kolom_41"])
            ->setCellValue("AP13", $rk4["kolom_42"])
            ->setCellValue("AQ13", $rk4["kolom_43"])
            ->setCellValue("AR13", $rk4["kolom_44"])
            ->setCellValue("AS13", $rk4["kolom_45"]);


//laporan rk.5
if ($thn >= 2017){
$runSQL = "select * from laporan_rk5new where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk5 = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A17", "1")
            ->setCellValue("B17", $rk5["kolom_2"])
            ->setCellValue("C17", $rk5["kolom_3"])
            ->setCellValue("D17", $rk5["kolom_4"])
            ->setCellValue("E17", $rk5["kolom_5"])
            ->setCellValue("F17", $rk5["kolom_6"])
            ->setCellValue("G17", $rk5["kolom_7"])
            ->setCellValue("H17", $rk5["kolom_8"])
            ->setCellValue("I17", $rk5["kolom_9"])
            ->setCellValue("J17", $rk5["kolom_10"])
            ->setCellValue("K17", $rk5["kolom_11"])
            ->setCellValue("L17", $rk5["kolom_12"])
            ->setCellValue("M17", $rk5["kolom_13"])
            ->setCellValue("N17", $rk5["kolom_14"])
            ->setCellValue("O17", $rk5["kolom_15"])
            ->setCellValue("P17", $rk5["kolom_16"])
            ->setCellValue("Q17", $rk5["kolom_17"])
            ->setCellValue("R17", $rk5["kolom_18"]);
}else{
$runSQL = "select * from laporan_rk5 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk5 = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A17", "1")
            ->setCellValue("B17", $rk5["kolom_2"])
            ->setCellValue("C17", $rk5["kolom_3"])
            ->setCellValue("D17", $rk5["kolom_4"])
            ->setCellValue("E17", $rk5["kolom_5"])
            ->setCellValue("F17", $rk5["kolom_6"])
            ->setCellValue("G17", $rk5["kolom_7"])
            ->setCellValue("H17", $rk5["kolom_8"])
            ->setCellValue("I17", $rk5["kolom_9"])
            ->setCellValue("J17", $rk5["kolom_10"])
            ->setCellValue("K17", $rk5["kolom_11"])
            ->setCellValue("L17", $rk5["kolom_12"])
            ->setCellValue("M17", $rk5["kolom_13"])
            ->setCellValue("N17", $rk5["kolom_14"])
            ->setCellValue("O17", $rk5["kolom_15"])
            ->setCellValue("P17", $rk5["kolom_16"])
            ->setCellValue("Q17", $rk5["kolom_17"])
            ->setCellValue("R17", $rk5["kolom_18"])
            ->setCellValue("S17", $rk5["kolom_19"]);
};//if


//laporan rk.6
$runSQL = "select * from laporan_rk6 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk6 = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A21", "1")
            ->setCellValue("B21", $rk6["kolom_2"])
            ->setCellValue("C21", $rk6["kolom_3"])
            ->setCellValue("D21", $rk6["kolom_4"])
            ->setCellValue("E21", $rk6["kolom_5"])
            ->setCellValue("F21", $rk6["kolom_6"])
            ->setCellValue("G21", $rk6["kolom_7"])
            ->setCellValue("H21", $rk6["kolom_8"])
            ->setCellValue("I21", $rk6["kolom_9"])
            ->setCellValue("J21", $rk6["kolom_10"])
            ->setCellValue("K21", $rk6["kolom_11"])
            ->setCellValue("L21", $rk6["kolom_12"])
            ->setCellValue("M21", $rk6["kolom_13"])
            ->setCellValue("N21", $rk6["kolom_14"])
            ->setCellValue("O21", $rk6["kolom_15"])
            ->setCellValue("P21", $rk6["kolom_16"])
            ->setCellValue("Q21", $rk6["kolom_17"])
            ->setCellValue("R21", $rk6["kolom_18"])
            ->setCellValue("S21", $rk6["kolom_19"])
            ->setCellValue("T21", $rk6["kolom_20"]);


//laporan rk.7a
$runSQL = "select * from laporan_rk7a where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk7a = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A25", "1")
            ->setCellValue("B25", $rk7a["kolom_2"])
            ->setCellValue("C25", $rk7a["kolom_3"])
            ->setCellValue("G25", $rk7a["kolom_4"])
            ->setCellValue("K25", $rk7a["kolom_5"])
            ->setCellValue("O25", $rk7a["kolom_6"])
            ->setCellValue("S25", $rk7a["kolom_7"])
            ->setCellValue("X25", $rk7a["kolom_8"]);


//laporan rk.7b
$runSQL = "select * from laporan_rk7b where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk7b = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A29", "1")
            ->setCellValue("B29", $rk7b["kolom_2"])
            ->setCellValue("C29", $rk7b["kolom_3"])
            ->setCellValue("G29", $rk7b["kolom_4"])
            ->setCellValue("K29", $rk7b["kolom_5"])
            ->setCellValue("O29", $rk7b["kolom_6"])
            ->setCellValue("S29", $rk7b["kolom_7"])
            ->setCellValue("X29", $rk7b["kolom_8"]);

			
//laporan rk.7c
$runSQL = "select * from laporan_rk7c where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk7c = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A33", "1")
            ->setCellValue("B33", $rk7c["kolom_2"])
            ->setCellValue("C33", $rk7c["kolom_3"])
            ->setCellValue("G33", $rk7c["kolom_4"])
            ->setCellValue("K33", $rk7c["kolom_5"])
            ->setCellValue("O33", $rk7c["kolom_6"])
            ->setCellValue("S33", $rk7c["kolom_7"])
            ->setCellValue("X33", $rk7c["kolom_8"]);
	
			
//laporan rk.8a
$runSQL = "select * from laporan_rk8a where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk8a = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A37", "1")
            ->setCellValue("B37", $rk8a["kolom_2"])
            ->setCellValue("C37", $rk8a["kolom_3"])
            ->setCellValue("E37", $rk8a["kolom_4"])
            ->setCellValue("G37", $rk8a["kolom_5"])
            ->setCellValue("J37", $rk8a["kolom_6"])
            ->setCellValue("M37", $rk8a["kolom_7"])
            ->setCellValue("P37", $rk8a["kolom_8"])
            ->setCellValue("S37", $rk8a["kolom_9"]);

//laporan rk.8b
$runSQL = "select * from laporan_rk8b where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk8b = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A41", "1")
            ->setCellValue("B41", $rk8b["kolom_2"])
            ->setCellValue("C41", $rk8b["kolom_3"])
            ->setCellValue("E41", $rk8b["kolom_4"])
            ->setCellValue("G41", $rk8b["kolom_5"])
            ->setCellValue("J41", $rk8b["kolom_6"])
            ->setCellValue("M41", $rk8b["kolom_7"])
            ->setCellValue("P41", $rk8b["kolom_8"]);

//laporan rk.8c
$runSQL = "select * from laporan_rk8c where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk8c = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A45", "1")
            ->setCellValue("B45", $rk8c["kolom_2"])
            ->setCellValue("C45", $rk8c["kolom_3"])
            ->setCellValue("E45", $rk8c["kolom_4"])
            ->setCellValue("G45", $rk8c["kolom_5"])
            ->setCellValue("J45", $rk8c["kolom_6"])
            ->setCellValue("M45", $rk8c["kolom_7"])
            ->setCellValue("P45", $rk8c["kolom_8"]);

//laporan rk.9
$runSQL = "select * from laporan_rk9 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk9 = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A49", "1")
            ->setCellValue("B49", $rk9["kolom_2"])
            ->setCellValue("C49", $rk9["kolom_3"])
            ->setCellValue("E49", $rk9["kolom_4"])
            ->setCellValue("G49", $rk9["kolom_5"])
            ->setCellValue("I49", $rk9["kolom_6"])
            ->setCellValue("K49", $rk9["kolom_7"])
            ->setCellValue("M49", $rk9["kolom_8"])
            ->setCellValue("O49", $rk9["kolom_9"])
            ->setCellValue("Q49", $rk9["kolom_10"]);


//laporan rk.10
$runSQL = "select * from laporan_rk10 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk10 = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A53", "1")
            ->setCellValue("B53", $rk10["kolom_2"])
            ->setCellValue("C53", $rk10["kolom_3"])
            ->setCellValue("E53", $rk10["kolom_4"])
            ->setCellValue("G53", $rk10["kolom_5"])
            ->setCellValue("I53", $rk10["kolom_6"])
            ->setCellValue("K53", $rk10["kolom_7"])
            ->setCellValue("M53", $rk10["kolom_8"])
            ->setCellValue("O53", $rk10["kolom_9"])
            ->setCellValue("Q53", $rk10["kolom_10"])
            ->setCellValue("S53", $rk10["kolom_11"])
            ->setCellValue("U53", $rk10["kolom_12"]);


//laporan rk.11a
$runSQL = "select * from laporan_rk11a where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk11a = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A57", "1")
            ->setCellValue("B57", $rk11a["kolom_2"])
            ->setCellValue("C57", $rk11a["kolom_3"])
            ->setCellValue("F57", $rk11a["kolom_4"]);


//laporan rk.11b
$runSQL = "select * from laporan_rk11b where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk11b = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A61", "1")
            ->setCellValue("B61", $rk11b["kolom_2"])
            ->setCellValue("C61", $rk11b["kolom_3"])
            ->setCellValue("E61", $rk11b["kolom_4"])
            ->setCellValue("G61", $rk11b["kolom_5"])
            ->setCellValue("I61", $rk11b["kolom_6"])
            ->setCellValue("K61", $rk11b["kolom_7"])
            ->setCellValue("M61", $rk11b["kolom_8"])
            ->setCellValue("O61", $rk11b["kolom_9"])
            ->setCellValue("Q61", $rk11b["kolom_10"])
            ->setCellValue("S61", $rk11b["kolom_11"])
            ->setCellValue("U61", $rk11b["kolom_12"])
            ->setCellValue("W61", $rk11b["kolom_13"])
            ->setCellValue("Y61", $rk11b["kolom_14"])
            ->setCellValue("AA61", $rk11b["kolom_15"])
            ->setCellValue("AC61", $rk11b["kolom_16"])
            ->setCellValue("AE61", $rk11b["kolom_17"])
            ->setCellValue("AH61", $rk11b["kolom_18"])
            ->setCellValue("AK61", $rk11b["kolom_19"])
            ->setCellValue("AN61", $rk11b["kolom_20"])
            ->setCellValue("AQ61", $rk11b["kolom_21"]);


//laporan rk.12
$runSQL = "select * from laporan_rk12 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rk12 = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A65", "1")
            ->setCellValue("B65", $rk12["kolom_2"])
            ->setCellValue("C65", $rk12["kolom_3"])
            ->setCellValue("E65", $rk12["kolom_4"])
            ->setCellValue("G65", $rk12["kolom_5"])
            ->setCellValue("I65", $rk12["kolom_6"]);

//laporan rk.ma
$runSQL = "select * from laporan_rkma where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rkma = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A69", "1")
            ->setCellValue("B69", $rkma["kolom_2"])
            ->setCellValue("C69", $rkma["kolom_3"])
            ->setCellValue("E69", $rkma["kolom_4"])
            ->setCellValue("G69", $rkma["kolom_5"])
            ->setCellValue("I69", $rkma["kolom_6"])
            ->setCellValue("K69", $rkma["kolom_7"])
            ->setCellValue("M69", $rkma["kolom_8"])
            ->setCellValue("O69", $rkma["kolom_9"])
            ->setCellValue("Q69", $rkma["kolom_10"])
            ->setCellValue("S69", $rkma["kolom_11"])
            ->setCellValue("U69", $rkma["kolom_12"]);


//laporan rk.esyar
$runSQL = "select * from laporan_rkesyar where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
if ($rkesyar = mysql_fetch_array ($result)) { };//if

$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A73", "1")
            ->setCellValue("B73", $rkesyar["kolom_2"])
            ->setCellValue("C73", $rkesyar["kolom_3"])
            ->setCellValue("G73", $rkesyar["kolom_4"])
            ->setCellValue("O73", $rkesyar["kolom_5"])
            ->setCellValue("S73", $rkesyar["kolom_6"])
            ->setCellValue("W73", $rkesyar["kolom_7"])
            ->setCellValue("AD73", $rkesyar["kolom_8"])
            ->setCellValue("AI73", $rkesyar["kolom_9"])
            ->setCellValue("AN73", $rkesyar["kolom_10"]);


//laporan layanan terpadu
$jml_5=""; $jml_6=""; $jml_7=""; $jml_8=""; $jml_9="";
$i=0; $kolom_1=""; $kolom_2=""; $kolom_3=""; $kolom_4=""; $kolom_5=""; $kolom_6=""; $kolom_7=""; $kolom_8=""; $kolom_9=""; $kolom_10="";
$runSQL = "select * from laporan_lyterpadu where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$i++;
	$kolom_1 .= $i."\r\n";
	//$kolom_2 .= $row["kolom_2"]."\r\n";
	$kolom_3 .= $row["kolom_3"]."\r\n";
	$kolom_4 .= $row["kolom_4"]."\r\n";
	$kolom_5 .= $row["kolom_5"]."\r\n";
	$kolom_6 .= $row["kolom_6"]."\r\n";
	$kolom_7 .= $row["kolom_7"]."\r\n";
	$kolom_8 .= $row["kolom_8"]."\r\n";
	$kolom_9 .= $row["kolom_9"]."\r\n";
	$kolom_10 .= $row["kolom_10"]."\r\n";

	$jml_5 += $row["kolom_5"];
	$jml_6 += $row["kolom_6"];
	$jml_7 += $row["kolom_7"];
	$jml_8 += $row["kolom_8"];
	$jml_9 += $row["kolom_9"];
};//while

$objPHPExcel->setActiveSheetIndex(18)
            ->setCellValue("A8", $kolom_1)
            ->setCellValue("B8", $kolom_3)
            ->setCellValue("C8", $kolom_4)
            ->setCellValue("D8", $kolom_5)
            ->setCellValue("E8", $kolom_6)
            ->setCellValue("F8", $kolom_7)
            ->setCellValue("G8", $kolom_8)
            ->setCellValue("H8", $kolom_9)
            ->setCellValue("I8", $kolom_10);

$objPHPExcel->setActiveSheetIndex(18)
				->setCellValue("D9", $jml_5)
				->setCellValue("E9", $jml_6)
				->setCellValue("F9", $jml_7)
				->setCellValue("G9", $jml_8)
				->setCellValue("H9", $jml_9);


//register delegasi
/*
$baris = 0;
$runSQL = "select id_satker, tahun, bulan, id_session, lastupdate, kolom_1, kolom_2, kolom_3, kolom_4, kolom_4b, date_format(kolom_5,'%d-%m-%Y') kolom_5, kolom_6 as kolom_6sql, date_format(kolom_6,'%d-%m-%Y') kolom_6, kolom_7 as kolom_7srt, date_format(kolom_7,'%d-%m-%Y') kolom_7, date_format(kolom_8,'%d-%m-%Y') kolom_8, date_format(kolom_8b,'%d-%m-%Y') kolom_8b, date_format(kolom_9,'%d-%m-%Y') kolom_9, kolom_10, kolom_11, kolom_12 from laporan_delegasi where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln' order by kolom_7srt asc";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$baris++;
	$cc = 6 + $baris;
	if (($row["kolom_5"]=="00-00-0000")or($row["kolom_5"]=="")){ $row["kolom_5"]=" - "; }
	if (($row["kolom_6"]=="00-00-0000")or($row["kolom_6"]=="")){ $row["kolom_6"]=" - "; }
	if (($row["kolom_7"]=="00-00-0000")or($row["kolom_7"]=="")){ $row["kolom_7"]=" - "; }
	if (($row["kolom_8"]=="00-00-0000")or($row["kolom_8"]=="")){ $row["kolom_8"]=" - "; }
	if (($row["kolom_8b"]=="00-00-0000")or($row["kolom_8b"]=="")){ $row["kolom_8b"]=" - "; }
	if (($row["kolom_9"]=="00-00-0000")or($row["kolom_9"]=="")){ $row["kolom_9"]=" - "; }
    $objPHPExcel->setActiveSheetIndex(19)
            ->setCellValue("A".$cc, $baris)
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_4b"])
            ->setCellValue("F".$cc, $row["kolom_5"])
            ->setCellValue("G".$cc, $row["kolom_6"])
            ->setCellValue("H".$cc, $row["kolom_7"])
            ->setCellValue("I".$cc, $row["kolom_8"])
            ->setCellValue("J".$cc, $row["kolom_8b"])
            ->setCellValue("K".$cc, $row["kolom_9"])
            ->setCellValue("L".$cc, $row["kolom_10"])
            ->setCellValue("M".$cc, $row["kolom_11"]);
};
*/
//while


// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0);


// Redirect output to a client’s web browser (Excel5)
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="'.$fileDownload.'"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;
