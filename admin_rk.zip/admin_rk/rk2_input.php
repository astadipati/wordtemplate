<?php
// Pusat Pelaporan dan Data Statistik Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id
// Written by iyok642@yahoo.com, lastupdate 28 Pebruari 2014

//parameter tanggal
$bln = $_POST["bln"]*1; if($bln==""){ $bln = $_GET["bln"]*1; };
$thn = $_POST["thn"]*1; if($thn==""){ $thn = $_GET["thn"]*1; };
$laporan = $_POST["laporan"]*1; if($laporan==""){ $laporan = $_GET["laporan"]*1; };
$kolom_1 = $_POST["kolom_1"]*1; if($kolom_1==""){ $kolom_1 = $_GET["kolom_1"]*1; };

//set default bulan tahun laporan
if ($bln==""){ 
	$bln = (date('m')-1)*1; $thn = date('Y')*1;
	if (date('d')>=20){ $bln = date('m')*1; }
	if ($bln==0){ $bln=12; $thn=(date('Y')-1)*1; }
};//if
if ($laporan == ""){ $laporan="$thn$bln"; };

//load setting
include_once("include.php");
include("include_login.php");

//post variable
$run     =$_POST["run"];        $kolom_11=$_POST["kolom_11"]*1; $kolom_21=$_POST["kolom_21"]*1; $kolom_31=$_POST["kolom_31"]*1; $kolom_41 =$_POST["kolom_41"]*1; 
$kolom_2 =$_POST["kolom_2"];    $kolom_12=$_POST["kolom_12"]*1; $kolom_22=$_POST["kolom_22"]*1; $kolom_32=$_POST["kolom_32"]*1;	$kolom_42 =$_POST["kolom_42"]*1;
$kolom_3 =$_POST["kolom_3"]*1;  $kolom_13=$_POST["kolom_13"]*1; $kolom_23=$_POST["kolom_23"]*1; $kolom_33=$_POST["kolom_33"]*1; $kolom_43 =$_POST["kolom_43"]*1; 
$kolom_4 =$_POST["kolom_4"]*1;  $kolom_14=$_POST["kolom_14"]*1; $kolom_24=$_POST["kolom_24"]*1; $kolom_34=$_POST["kolom_34"]*1; $kolom_44 =$_POST["kolom_44"]*1; 
$kolom_5 =$_POST["kolom_5"]*1;  $kolom_15=$_POST["kolom_15"]*1; $kolom_25=$_POST["kolom_25"]*1; $kolom_35=$_POST["kolom_35"]*1; $kolom_45 =substr($_POST["kolom_45"],0,50); 
$kolom_6 =$_POST["kolom_6"]*1;  $kolom_16=$_POST["kolom_16"]*1; $kolom_26=$_POST["kolom_26"]*1; $kolom_36=$_POST["kolom_36"]*1; 
$kolom_7 =$_POST["kolom_7"]*1;  $kolom_17=$_POST["kolom_17"]*1; $kolom_27=$_POST["kolom_27"]*1; $kolom_37=$_POST["kolom_37"]*1; 
$kolom_8 =$_POST["kolom_8"]*1;  $kolom_18=$_POST["kolom_18"]*1; $kolom_28=$_POST["kolom_28"]*1; $kolom_38=$_POST["kolom_38"]*1; 
$kolom_9 =$_POST["kolom_9"]*1;  $kolom_19=$_POST["kolom_19"]*1; $kolom_29=$_POST["kolom_29"]*1; $kolom_39=$_POST["kolom_39"]*1; 
$kolom_10=$_POST["kolom_10"]*1; $kolom_20=$_POST["kolom_20"]*1; $kolom_30=$_POST["kolom_30"]*1; $kolom_40=$_POST["kolom_40"]*1;

//data satker
$runSQL = "select * from laporan_satker where id_satker='$SESS_ID_SATKER' order by urutan_cetak";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$nm_satker_pjg = $row[nm_satker_pjg];
	$tk_satker = strtoupper($row[tk_satker]);
};//while

//variabel bulan tahun laporan
$bulan_laporan=array(); $value_laporan=array();
for($i=1; $i<=$bln; $i++){
	$nama_bln = $bulan[$i];
	array_push($bulan_laporan, " $nama_bln $thn ");
	array_push($value_laporan, "$thn$i");
};//for

//pilihan bulan tahun laporan
for($i=0; $i<count($bulan_laporan); $i++){
	if ($value_laporan[$i]==$laporan) { $cek="selected"; $bln=substr($laporan,4,2)*1; $thn=substr($laporan,0,4)*1; }else{ unset($cek); }
	$selectlaporan .= "<option value=\"".$value_laporan[$i]."&kolom_1=$kolom_1\" $cek> &nbsp; ".$bulan_laporan[$i]." &nbsp; </option>"; 
};//for
$selectlaporan = "<select size=1 name=\"laporan\" onChange=\"runJump(this.value)\" class=\"laporanfree\"> $selectlaporan </select>";

//data satker
$data_satker=array();
$runSQL = "select * from laporan_satker where id_parent='$SESS_ID_SATKER' order by urutan_cetak";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	if ($kolom_1=="") { $kolom_1=$row[id_satker]; $kolom_2=$row[nm_satker]; };
	if ($kolom_1==$row[id_satker]) { $cek="selected"; $kolom_2=$row[nm_satker]; }else{ unset($cek); }
	$selectkolom1 .= "<option value=\"$laporan&kolom_1=".$row[id_satker]."\" $cek>".$row[nm_satker]."</option>"; 
};//while
$selectkolom1 = "<select size=1 name=\"laporan\" onChange=\"runJump(this.value)\" class=\"laporanfree\"> $selectkolom1 </select>";

//baca rk2 yang tersimpan
if (strlen($run) < 1){ 
	$runSQL="select * from laporan_rk2 where id_satker='$kolom_1' and tahun='$thn' and bulan='$bln'";
	$result=mysql_query($runSQL, $connDB);
    if ($row=mysql_fetch_array ($result)) {
		$kolom_1 =$row["kolom_1"];  $kolom_11=$row["kolom_11"]; $kolom_21=$row["kolom_21"]; $kolom_31=$row["kolom_31"]; $kolom_41=$row["kolom_41"]; 
		$kolom_2 =$row["kolom_2"];  $kolom_12=$row["kolom_12"]; $kolom_22=$row["kolom_22"]; $kolom_32=$row["kolom_32"]; $kolom_42=$row["kolom_42"];
		$kolom_3 =$row["kolom_3"];  $kolom_13=$row["kolom_13"]; $kolom_23=$row["kolom_23"]; $kolom_33=$row["kolom_33"]; $kolom_43=$row["kolom_43"]; 
		$kolom_4 =$row["kolom_4"];  $kolom_14=$row["kolom_14"]; $kolom_24=$row["kolom_24"]; $kolom_34=$row["kolom_34"]; $kolom_44=$row["kolom_44"]; 
		$kolom_5 =$row["kolom_5"];  $kolom_15=$row["kolom_15"]; $kolom_25=$row["kolom_25"]; $kolom_35=$row["kolom_35"]; $kolom_45=$row["kolom_45"]; 
		$kolom_6 =$row["kolom_6"];  $kolom_16=$row["kolom_16"]; $kolom_26=$row["kolom_26"]; $kolom_36=$row["kolom_36"]; 
		$kolom_7 =$row["kolom_7"];  $kolom_17=$row["kolom_17"]; $kolom_27=$row["kolom_27"]; $kolom_37=$row["kolom_37"]; 
		$kolom_8 =$row["kolom_8"];  $kolom_18=$row["kolom_18"]; $kolom_28=$row["kolom_28"]; $kolom_38=$row["kolom_38"]; 
		$kolom_9 =$row["kolom_9"];  $kolom_19=$row["kolom_19"]; $kolom_29=$row["kolom_29"]; $kolom_39=$row["kolom_39"]; 
		$kolom_10=$row["kolom_10"]; $kolom_20=$row["kolom_20"]; $kolom_30=$row["kolom_30"]; $kolom_40=$row["kolom_40"];
   };//if
};//if-id

//sisa perkara bulan lalu RK.2
$bln_lalu=$bln-1;  $thn_lalu=$thn;
if ($bln_lalu==0){ $bln_lalu=12; $thn_lalu=$thn-1; }
$runSQL="select * from laporan_rk2 where id_satker=$kolom_1 and tahun=$thn_lalu and bulan=$bln_lalu";
//echo "$runSQL<br>";
$result=mysql_query($runSQL, $connDB);
if ($row=mysql_fetch_array($result)) {
	$sisa_perkara_bulan=$row[kolom_43];
};//if
//echo "$sisa_perkara_bulan<br>";

//jumlah perkara diterima RK.1
$runSQL="select * from laporan_rk1 where id_satker=$kolom_1 and tahun=$thn and bulan=$bln";
$result=mysql_query($runSQL, $connDB);
if ($row=mysql_fetch_array($result)) {
	$jml_perkara_diterima=$row[kolom_34];
};//if

//cek konsistensi data antar laporan
if ($jml_perkara_diterima<>$kolom_4){ $kolom_4 = $jml_perkara_diterima; $runUpdate=1; };//if
if ($bln > 1){
	if ($sisa_perkara_bulan<>$kolom_3){ $kolom_3 = $sisa_perkara_bulan; $runUpdate=1; };
	$readonly="readonly";
};//if

$kolom_5 = $kolom_3 + $kolom_4;
$kolom_42 = $kolom_7 + $kolom_8 + $kolom_9 + $kolom_10 + $kolom_11 + $kolom_12 + $kolom_13 + $kolom_14 + $kolom_15 + $kolom_16 + $kolom_17 + $kolom_18 + $kolom_19 + $kolom_20 + $kolom_21 + $kolom_22 + $kolom_23 + $kolom_24 + $kolom_25 + $kolom_26 + $kolom_27 + $kolom_28 + $kolom_29 + $kolom_30 + $kolom_31 + $kolom_32 + $kolom_33 + $kolom_34 + $kolom_35 + $kolom_36 + $kolom_37 + $kolom_38 + $kolom_39 + $kolom_40 + $kolom_41;
$kolom_43 = ($kolom_5 - $kolom_6) - $kolom_42;

if ($runUpdate == 1){
	$runSQL="select * from laporan_rk2 where id_satker=$kolom_1 and tahun=$thn and bulan=$bln";
	$result=mysql_query($runSQL, $connDB);
	if ($row=mysql_fetch_array($result)) {
		$runSQL="update laporan_rk2 set id_session='$SESSION_ID', lastupdate=now(), kolom_1='$kolom_1', kolom_2='$kolom_2', kolom_3='$kolom_3', kolom_4='$kolom_4', kolom_5='$kolom_5', kolom_6='$kolom_6', kolom_7='$kolom_7', kolom_8='$kolom_8', kolom_9='$kolom_9', kolom_10='$kolom_10', kolom_11='$kolom_11', kolom_12='$kolom_12', kolom_13='$kolom_13', kolom_14='$kolom_14', kolom_15='$kolom_15', kolom_16='$kolom_16', kolom_17='$kolom_17', kolom_18='$kolom_18', kolom_19='$kolom_19', kolom_20='$kolom_20', kolom_21='$kolom_21', kolom_22='$kolom_22', kolom_23='$kolom_23', kolom_24='$kolom_24', kolom_25='$kolom_25', kolom_26='$kolom_26', kolom_27='$kolom_27', kolom_28='$kolom_28', kolom_29='$kolom_29', kolom_30='$kolom_30', kolom_31='$kolom_31', kolom_32='$kolom_32', kolom_33='$kolom_33', kolom_34='$kolom_34', kolom_35='$kolom_35', kolom_36='$kolom_36', kolom_37='$kolom_37', kolom_38='$kolom_38', kolom_39='$kolom_39', kolom_40='$kolom_40', kolom_41='$kolom_41', kolom_42='$kolom_42', kolom_43='$kolom_43', kolom_44='$kolom_44', kolom_45='$kolom_45' where id_satker=$kolom_1 and tahun=$thn and bulan=$bln";
		$update=mysql_query($runSQL, $connDB);
	};//if
};//if

//submit form
if (strlen($run) > 1){ 
	$runSQL="select * from laporan_rk2 where id_satker=$kolom_1 and tahun=$thn and bulan=$bln";
	$result=mysql_query($runSQL, $connDB);
	if ($row=mysql_fetch_array($result)) {
		$submitValid=1;
		$runSQL="update laporan_rk2 set id_session='$SESSION_ID', lastupdate=now(), kolom_1='$kolom_1', kolom_2='$kolom_2', kolom_3='$kolom_3', kolom_4='$kolom_4', kolom_5='$kolom_5', kolom_6='$kolom_6', kolom_7='$kolom_7', kolom_8='$kolom_8', kolom_9='$kolom_9', kolom_10='$kolom_10', kolom_11='$kolom_11', kolom_12='$kolom_12', kolom_13='$kolom_13', kolom_14='$kolom_14', kolom_15='$kolom_15', kolom_16='$kolom_16', kolom_17='$kolom_17', kolom_18='$kolom_18', kolom_19='$kolom_19', kolom_20='$kolom_20', kolom_21='$kolom_21', kolom_22='$kolom_22', kolom_23='$kolom_23', kolom_24='$kolom_24', kolom_25='$kolom_25', kolom_26='$kolom_26', kolom_27='$kolom_27', kolom_28='$kolom_28', kolom_29='$kolom_29', kolom_30='$kolom_30', kolom_31='$kolom_31', kolom_32='$kolom_32', kolom_33='$kolom_33', kolom_34='$kolom_34', kolom_35='$kolom_35', kolom_36='$kolom_36', kolom_37='$kolom_37', kolom_38='$kolom_38', kolom_39='$kolom_39', kolom_40='$kolom_40', kolom_41='$kolom_41', kolom_42='$kolom_42', kolom_43='$kolom_43', kolom_44='$kolom_44', kolom_45='$kolom_45' where id_satker=$kolom_1 and tahun=$thn and bulan=$bln";
		$update=mysql_query($runSQL, $connDB);
	} else {
		$submitValid=1;
		$runSQL="insert into laporan_rk2 (id_satker, tahun, bulan, id_session, lastupdate, kolom_1, kolom_2, kolom_3, kolom_4, kolom_5, kolom_6, kolom_7, kolom_8, kolom_9, kolom_10, kolom_11, kolom_12, kolom_13, kolom_14, kolom_15, kolom_16, kolom_17, kolom_18, kolom_19, kolom_20, kolom_21, kolom_22, kolom_23, kolom_24, kolom_25, kolom_26, kolom_27, kolom_28, kolom_29, kolom_30, kolom_31, kolom_32, kolom_33, kolom_34, kolom_35, kolom_36, kolom_37, kolom_38, kolom_39, kolom_40, kolom_41, kolom_42, kolom_43, kolom_44, kolom_45) VALUES ('$kolom_1', '$thn', '$bln', '$SESSION_ID', now(), '$kolom_1', '$kolom_2', '$kolom_3', '$kolom_4', '$kolom_5', '$kolom_6', '$kolom_7', '$kolom_8', '$kolom_9', '$kolom_10', '$kolom_11', '$kolom_12', '$kolom_13', '$kolom_14', '$kolom_15', '$kolom_16', '$kolom_17', '$kolom_18', '$kolom_19', '$kolom_20', '$kolom_21', '$kolom_22', '$kolom_23', '$kolom_24', '$kolom_25', '$kolom_26', '$kolom_27', '$kolom_28', '$kolom_29', '$kolom_30', '$kolom_31', '$kolom_32', '$kolom_33', '$kolom_34', '$kolom_35', '$kolom_36', '$kolom_37', '$kolom_38', '$kolom_39', '$kolom_40', '$kolom_41', '$kolom_42', '$kolom_43', '$kolom_44', '$kolom_45')";
		$insert=mysql_query($runSQL, $connDB);
		//echo "$runSQL<br>";
	};//if
};//end-if-submit

?>
<html>
<head>
  <meta name="Generator" content="EditPlus">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <meta name="Description" content="Sistem Pendaftaran Perkara Secara Online Pengadilan Agama">
  <title>Laporan Perkara RK.2 <? echo $bulan[($bln*1)]." ".$thn; ?></title>
  <link rel="shortcut icon" href="favicon.ico">
  <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
 <tr>
   <td align="center">
	<table width="980" border="0" cellpadding="0" cellspacing="0">
	</table>
	<table width="980" height="450" border="0" cellpadding="0" cellspacing="0" align="center">
	  <tr><td width="100%" colspan="2"><?php include("header.php"); ?></td></tr>
	  <tr>
        <td width="200" valign="top" bgcolor="#336600"><?php include("menu.php"); ?></td>
        <td width="780" valign="top">
		<table width="100%" height="450" bgcolor="#FFFFFF" border="1" cellpadding="10" cellspacing="0" style="border-collapse:collapse" bordercolor="#003300">
		 <tr>
			<td width="100%" vAlign="top">
			<!--content-->
	
<? if ($tk_satker <> "PTA"){?>

    <table align="center" border="0" cellpadding="5" cellspacing="1" width="750">
      <tr>
        <td width="100%" align="center">
		<font color="#0000FF" size="3"><b>Pengisian RK.2 <? echo $bulan[($bln*1)]." ".$thn; ?></b></font>
        <br><font color="#0000FF">Laporan Rekapitulasi Perkara Tingkat Banding yang Diputus.
        <hr size="1" color="#003300">
		</td>
      </tr>
      <tr>
        <td width="100%" height="650" align="center">
		<font color="#FF0000" size="4"><b>Pengisian RK.2 hanya untuk user Tingkat Banding
		</td>
      </tr>
    </table>

<? } else if ($submitValid <> 1){?>

    <form method="POST" name="form" ENCTYPE="multipart/form-data" action="<? echo $_SERVER["PHP_SELF"]; ?>">
    <table align="center" border="0" cellpadding="5" cellspacing="1" width="750">
      <tr>
        <td width="100%" colspan="5" align="center">
		<? echo $selectlaporan; ?><br>
		<font color="#0000FF" size="3"><b>Pengisian RK.2 <? echo $bulan[($bln*1)]." ".$thn; ?></b></font>
        <br><font color="#0000FF">Laporan Rekapitulasi Perkara Tingkat Banding yang Diputus.
        <hr size="1" color="#003300">
		</td>
      </tr>
    </table>
    <table align="center" border="0" cellpadding="5" cellspacing="1" width="500">
      <tr>
        <td bgcolor='#339900' width="100%" colspan="5"><b>Laporan RK.2 bulan <? echo $bulan[($bln*1)]." ".$thn; ?></b></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>1</td>
        <td width="30%" align="left" nowrap>Nomor</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input readonly type="text" name="kolom_1" size="<?=strlen($kolom_1)+3;?>" value="<?=htmlentities(stripslashes($kolom_1));?>"><? echo $ikolom_1; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>2</td>
        <td width="30%" align="left" nowrap>Nama Pengadilan</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><? echo $selectkolom1; ?><? echo $ikolom_2; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>3</td>
        <td width="30%" align="left" nowrap>Sisa Bulan Lalu</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input <?=$readonly;?> type="text" name="kolom_3" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_3));?>"><? echo $ikolom_3; ?> <font size="1"><i><? if($readonly==""){ echo "<font color='#FF0000'>Input Sisa Bulan Lalu *)</font><br>[Sisa ".$bulan[($bln_lalu*1)]." $thn_lalu sebesar $sisa_perkara_bulan]"; }else{ echo "<font color='#6600FF'>Dari Lap. Sebelumnya"; }; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>4</td>
        <td width="30%" align="left" nowrap>Perkara yang Diterima</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input readonly type="text" name="kolom_4" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_4));?>"><? echo $ikolom_4; ?> <font size="1" color="#6600FF"><i>Dari Lap. RK.1</td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>5</td>
        <td width="30%" align="left" nowrap>Jumlah</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input readonly type="text" name="kolom_5" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_5));?>"><? echo $ikolom_5; ?> <font size="1" color="#6600FF"><i>Jumlah Otomatis</td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>6</td>
        <td width="30%" align="left" nowrap>Dicabut</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_6" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_6));?>"><? echo $ikolom_6; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>7</td>
        <td width="30%" align="left" nowrap>Izin Poligami</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_7" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_7));?>"><? echo $ikolom_7; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>8</td>
        <td width="30%" align="left" nowrap>Pencegahan Perkawinan</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_8" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_8));?>"><? echo $ikolom_8; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>9</td>
        <td width="30%" align="left" nowrap>Penolakan Perkawinan oleh PPN</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_9" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_9));?>"><? echo $ikolom_9; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>10</td>
        <td width="30%" align="left" nowrap>Pembatalan Perkawinan</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_10" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_10));?>"><? echo $ikolom_10; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>11</td>
        <td width="30%" align="left" nowrap>Kelalaian Atas Kewajiban Suami/Istri</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_11" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_11));?>"><? echo $ikolom_11; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>12</td>
        <td width="30%" align="left" nowrap>Cerai Talak</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_12" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_12));?>"><? echo $ikolom_12; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>13</td>
        <td width="30%" align="left" nowrap>Cerai Gugat</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_13" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_13));?>"><? echo $ikolom_13; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>14</td>
        <td width="30%" align="left" nowrap>Harta Bersama</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_14" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_14));?>"><? echo $ikolom_14; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>15</td>
        <td width="30%" align="left" nowrap>Penguasaan Anak/Hadhonah</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_15" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_15));?>"><? echo $ikolom_15; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>16</td>
        <td width="30%" align="left" nowrap>Nafkah Anak oleh Ibu</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_16" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_16));?>"><? echo $ikolom_16; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>17</td>
        <td width="30%" align="left" nowrap>Hak Hak Bekas Istri</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_17" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_17));?>"><? echo $ikolom_17; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>18</td>
        <td width="30%" align="left" nowrap>Pengesahan/Pengangkatan Anak</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_18" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_18));?>"><? echo $ikolom_18; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>19</td>
        <td width="30%" align="left" nowrap>Pencabutan Kekuasaan Orang Tua</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_19" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_19));?>"><? echo $ikolom_19; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>20</td>
        <td width="30%" align="left" nowrap>Perwalian</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_20" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_20));?>"><? echo $ikolom_20; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>21</td>
        <td width="30%" align="left" nowrap>Pencabutan Kekuasaan Wali</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_21" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_21));?>"><? echo $ikolom_21; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>22</td>
        <td width="30%" align="left" nowrap>Penunjukan Orang Lain sebagai Wali</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_22" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_22));?>"><? echo $ikolom_22; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>23</td>
        <td width="30%" align="left" nowrap>Ganti Rugi Terhadap Wali</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_23" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_23));?>"><? echo $ikolom_23; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>24</td>
        <td width="30%" align="left" nowrap>Asal Usul Anak</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_24" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_24));?>"><? echo $ikolom_24; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>25</td>
        <td width="30%" align="left" nowrap>Penetapan Kawin Campuran</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_25" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_25));?>"><? echo $ikolom_25; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>26</td>
        <td width="30%" align="left" nowrap>Isbat Nikah</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_26" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_26));?>"><? echo $ikolom_26; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>27</td>
        <td width="30%" align="left" nowrap>Izin Kawin</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_27" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_27));?>"><? echo $ikolom_27; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>28</td>
        <td width="30%" align="left" nowrap>Dispensasi Kawin</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_28" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_28));?>"><? echo $ikolom_28; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>29</td>
        <td width="30%" align="left" nowrap>Wali Adhal</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_29" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_29));?>"><? echo $ikolom_29; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>30</td>
        <td width="30%" align="left" nowrap>Ekonomi Syariah</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_30" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_30));?>"><? echo $ikolom_30; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>31</td>
        <td width="30%" align="left" nowrap>Kewarisan</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_31" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_31));?>"><? echo $ikolom_31; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>32</td>
        <td width="30%" align="left" nowrap>Wasiat</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_32" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_32));?>"><? echo $ikolom_32; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>33</td>
        <td width="30%" align="left" nowrap>Hibah</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_33" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_33));?>"><? echo $ikolom_33; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>34</td>
        <td width="30%" align="left" nowrap>Wakaf</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_34" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_34));?>"><? echo $ikolom_34; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>35</td>
        <td width="30%" align="left" nowrap>Zakat/Infak/Shadaqah</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_35" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_35));?>"><? echo $ikolom_35; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>36</td>
        <td width="30%" align="left" nowrap>P3HP / Penetapan Ahli Waris</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_36" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_36));?>"><? echo $ikolom_36; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>37</td>
        <td width="30%" align="left" nowrap>Lain-Lain</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_37" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_37));?>"><? echo $ikolom_37; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>38</td>
        <td width="30%" align="left" nowrap>Ditolak</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_38" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_38));?>"><? echo $ikolom_38; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>39</td>
        <td width="30%" align="left" nowrap>Tidak Diterima</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_39" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_39));?>"><? echo $ikolom_39; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>40</td>
        <td width="30%" align="left" nowrap>Gugur</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_40" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_40));?>"><? echo $ikolom_40; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>41</td>
        <td width="30%" align="left" nowrap>Dicoret Dari Register</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_41" size="5" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_41));?>"><? echo $ikolom_41; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>42</td>
        <td width="30%" align="left" nowrap>Jumlah</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input readonly type="text" name="kolom_42" size="5" value="<?=htmlentities(stripslashes($kolom_42));?>"><? echo $ikolom_42; ?> <font size="1" color="#6600FF"><i>Jumlah Otomatis</td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>43</td>
        <td width="30%" align="left" nowrap>Sisa Akhir Bulan</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input readonly type="text" name="kolom_43" size="5" value="<?=htmlentities(stripslashes($kolom_43));?>"><? echo $ikolom_43; ?> <font size="1" color="#6600FF"><i>Sisa Otomatis</td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>44</td>
        <td width="30%" align="left" nowrap>Perkara yang sudah Diminutasi</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_44" size="5" value="<?=htmlentities(stripslashes($kolom_44));?>"><? echo $ikolom_44; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>45</td>
        <td width="30%" align="left" nowrap>Keterangan</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_45" size="35" value="<?=htmlentities(stripslashes($kolom_45));?>"><? echo $ikolom_45; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
		<td width="100%" height="50" colspan="5" align="center" valign="middle">
		<input type="hidden" name="bln" value="<?=$bln;?>"><input type="hidden" name="thn" value="<?=$thn;?>">
		<input type="submit" value="    Simpan   " name="run" class="button">
		</td>
	  </tr>
	  <? if($readonly==""){ echo "<tr><td colspan='5' height='40' valign='bottom' align='right'><font color='#FF0000' size='1'><i>*) Sisa bulan lalu dapat diubah pada awal tahun pelaporan, bulan januari.</td></tr>"; }; ?>
	</table>
    </form>
	<script language="Javascript" type="text/javascript">
	function runJump(val) {
	  window.location='<?=$_SERVER["PHP_SELF"];?>?laporan='+val; //make connection
	}

	function calculate() {
	 document.form.kolom_5.value = eval(document.form.kolom_3.value) + eval(document.form.kolom_4.value);
	 jmlputus = eval(document.form.kolom_7.value) + eval(document.form.kolom_8.value) + eval(document.form.kolom_9.value) + eval(document.form.kolom_10.value) + eval(document.form.kolom_11.value) + eval(document.form.kolom_12.value) + eval(document.form.kolom_13.value) + eval(document.form.kolom_14.value) + eval(document.form.kolom_15.value) + eval(document.form.kolom_16.value) + eval(document.form.kolom_17.value) + eval(document.form.kolom_18.value) + eval(document.form.kolom_19.value) + eval(document.form.kolom_20.value) + eval(document.form.kolom_21.value) + eval(document.form.kolom_22.value) + eval(document.form.kolom_23.value) + eval(document.form.kolom_24.value) + eval(document.form.kolom_25.value) + eval(document.form.kolom_26.value) + eval(document.form.kolom_27.value) + eval(document.form.kolom_28.value) + eval(document.form.kolom_29.value) + eval(document.form.kolom_30.value) + eval(document.form.kolom_31.value) + eval(document.form.kolom_32.value) + eval(document.form.kolom_33.value) + eval(document.form.kolom_34.value) + eval(document.form.kolom_35.value) + eval(document.form.kolom_36.value) + eval(document.form.kolom_37.value) + eval(document.form.kolom_38.value) + eval(document.form.kolom_39.value) + eval(document.form.kolom_40.value) + eval(document.form.kolom_41.value);
	 document.form.kolom_42.value = jmlputus;
	 document.form.kolom_43.value = eval(document.form.kolom_5.value) - eval(document.form.kolom_6.value) - jmlputus;
	}
	</script>

<? }else{?>

    <table align="center" border="0" cellpadding="5" cellspacing="1" width="750">
      <tr>
        <td width="100%" align="center"><font color="#0000FF" size="3"><b>Laporan RK.2 berhasil disimpan</b></font>
        <hr size="1" color="#003300">
		</td>
      </tr>
    </table>
    <table align="center" border="0" cellpadding="20" cellspacing="1" width="500">
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="100%" align="center">
		Laporan RK.2 bulan <?=$bulan[($bln*1)]." ".$thn;?> Satker <?=$kolom_2;?> berhasil disimpan.
		</td>
      </tr>
    </table>
    <table height="500" align="center" border="0" cellpadding="5" cellspacing="1">
      <tr>
        <td width="100%">[ <a href="rk2_input.php?<?="laporan=$laporan&kolom_1=$kolom_1";?>">Kembali ke Pengisian RK.2</a> ]</td>
      </tr>
    </table>

<? };?>

			<!--end.content-->
			</td>
		 </tr>
		</table>
		</td>
	  </tr>
	  <tr>
        <td width="100%" bgcolor="#004A00" colspan="2"><?php include("footer.php"); ?></td>
	  </tr>
	</table>
    </td>
  </tr>
</table>
</body>
</html>
<?
if ($connDB){ $close=mysql_close($connDB);};
?>