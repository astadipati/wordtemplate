<?php
// Aplikasi Pendaftaran Perkara Online
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id
// Contact Tim IT PTA Surabaya, lastupdate 15 Mei 2013

//load setting
include_once("include.php");

//post variable
if ($run == ""){ $run = $_POST["run"]; };
if ($sqlcommand == ""){ $sqlcommand = $_POST["sqlcommand"]; };

//submit form
if (strlen($run) > 1){ 
    $valid = 1;
	if (strlen($sqlcommand) < 10){ $isqlcommand = "<br><font color='#FF0000' size='1'><i>* Perintah SQL tidak valid"; $valid = 0; }
    
    if ($valid == 1){

		$result = @mysql_query($sqlcommand, $connDB);
		$affected .= mysql_affected_rows($connDB);
		$error .= mysql_error($connDB);
		
		if ($affected <> ""){ $htmlData .= $affected ." rows affected.<br>"; }
		if ($error <> ""){ $htmlData .= $error ." error message.<br>"; }

		$htmlData .= "<table width='100%' cellspacing='1' cellpadding='2'>";
		$htmlData .= "<tr bgcolor='#ECECFF'>";
		for ($i=0; $i<@mysql_num_fields($result); $i++){
			$htmlData .= "<td align='center'><font size='1'>".@mysql_field_name($result, $i)."</td>";
		};//for
		$htmlData .= "</tr>";

		while ($row = @mysql_fetch_array ($result)) {
		   $ccc++;if ($ccc%2 > 0){ $color="#EEFBE1"; }else{ $color="#CCFA9A"; };

		   $htmlData .= "<tr bgcolor='$color' onmouseover='bgColor=\"#ABE159\"' onmouseout='bgColor=\"$color\"'>";
		   for ($i=0; $i<@mysql_num_fields($result); $i++){
				$nama_kolom = @mysql_field_name($result, $i);
				$htmlData .= "<td valign='top'><font size='1'>".$row[$nama_kolom]."</td>";
		   };//for
		   $htmlData .= "</tr>";

		};//end-while
		$htmlData .= "</table>";

	};//isian valid
};//end-if-submit

?>
<html>
<head>
  <meta name="Generator" content="EditPlus">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <meta name="Description" content="Sistem Pendaftaran Perkara Secara Online Pengadilan Agama">
  <title>DB Tools Laporan Perkara </title>
  <link rel="shortcut icon" href="favicon.ico">
  <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
 <tr>
   <td align="center">
	<table width="980" border="0" cellpadding="0" cellspacing="0">
	</table>
	<table width="980" height="450" border="0" cellpadding="0" cellspacing="0" align="center">
	  <tr><td width="100%" colspan="2"><?php include("header.php"); ?></td></tr>
	  <tr>
        <td width="200" valign="top" bgcolor="#336600"><?php include("menu.php"); ?></td>
        <td width="780" valign="top">
		<table width="100%" height="650" bgcolor="#FFFFFF" border="1" cellpadding="10" cellspacing="0" style="border-collapse:collapse" bordercolor="#003300">
		 <tr>
			<td width="100%" vAlign="top">
			<!--content-->

    <form method="POST" name="form" action="<? echo $_SERVER["PHP_SELF"]; ?>">
    <table border="0" cellpadding="5" cellspacing="1" width="750">
      <tr>
        <td width="100%" colspan="3" align="center"><font color="#0000FF" size="3"><b>Database Tools</b></font>
        <hr size="1" color="#003300">
		</td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="30%" align="right" nowrap>User Database  : </td>
        <td width="70%"><font size="1"><b><? echo "$hostserver/$dbusername"; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="30%" align="right" nowrap>Nama Database : </td>
        <td width="70%"><font size="1"><b><? echo $database; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="30%" align="right" valign="top" nowrap>SQL Command : </td>
        <td width="70%"><textarea rows="8" cols="63" name="sqlcommand"><?=htmlentities(stripslashes($sqlcommand));?></textarea><?=$isqlcommand;?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="30%"></td>
        <td width="70%"><input type="submit" value="  Jalankan  " name="run" class="button"></td>
      </tr>
	</table>
    </form>
	   

			<? echo $htmlData; ?>

			<!--end.content-->
			</td>
		 </tr>
		</table>
		</td>
	  </tr>
	  <tr>
        <td width="100%" bgcolor="#004A00" colspan="2"><?php include("footer.php"); ?></td>
	  </tr>
	</table>
    </td>
  </tr>
</table>
</body>
</html>
<?php
if ($connDB){ $close = mysql_close($connDB);};
?>