<table width="100%" height="120" bgcolor="#003300" border="0" cellpadding="0" cellspacing="0">
  <tr>
	<td width="20%" align="center"><img src="img/logo.png" height="110"></td>
	<td width="80%" align="center"><font color="#FFFFFF" size="5"><b>Pusat Pelaporan dan Data Statistik Perkara<br>Pengadilan Tinggi Agama Surabaya</td>
  </tr>
</table>
