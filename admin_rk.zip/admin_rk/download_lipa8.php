<?php
// Data Statistik dan Pusat Pelaporan Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id
// Contact iyok642@yahoo.com, lastupdate 28 Pebruari 2014

//parameter tanggal
$bln = $_POST["bln"]*1; if($bln==""){ $bln = $_GET["bln"]*1; }
$thn = $_POST["thn"]*1; if($thn==""){ $thn = $_GET["thn"]*1; };
$id_satker = $_POST["id_satker"]*1; if($id_satker==""){ $id_satker = $_GET["id_satker"]*1; };

//set default bulan tahun laporan
if ($bln==""){ 
	$bln = (date('m')-1)*1; $thn = date('Y')*1;
	if (date('d')>=25){ $bln = date('m')*1; }
	if ($bln==0){ $bln=12; $thn=(date('Y')-1)*1; }
};//if

$lastday = date ("t", mktime(0,0,0,$bln,1,$thn));
$numbday = date ("N", mktime(0,0,0,$bln,$lastday,$thn));
if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

//load setting
include_once("include.php");
include("include_login.php");

//satker user akses
$view_this_satker=$SESS_ID_SATKER;
$runSQL = "select * from laporan_satker where id_satker='$SESS_ID_SATKER'";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	if (($row[tk_satker]=="PTA")or($row[tk_satker]=="BADILAG")){ $view_this_satker=$id_satker; }
};//while

//profile satker
$runSQL = "select * from laporan_satker where id_satker='$view_this_satker'";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$kode_perkara = $row[kode_perkara];
	$nama_satker = $row[nm_satker_pjg];
	$alamat_satker = $row[almt_satker];
	$website_email = "Website: ".$row[url_satker]." Email: ".$row[email_satker];
	$nama_ketua = $row[nama_ketua];
	$nama_pansek = $row[nama_pansek];
	$nama_kota = $row[nama_kota];
};//while



/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2013 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2013 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    1.7.9, 2013-06-02
 */

/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
date_default_timezone_set('Europe/London');

if (PHP_SAPI == 'cli')
	die('This example should only be run from a Web Browser');

/** Include PHPExcel */
require_once 'excell/PHPExcel.php';

$fileTemplate = "master_lipa8.xls";
$fileDownload = "LIPA.8_".strtoupper($kode_perkara)."_".$bulan[($bln*1)]."_".$thn.".xls";

// Create new PHPExcel object
//$objPHPExcel = new PHPExcel();

// Read the file
$objReader = PHPExcel_IOFactory::createReader('Excel5');
$objPHPExcel = $objReader->load($fileTemplate);


// Set document properties
$objPHPExcel->getProperties()->setCreator("iyok642@yahoo.com")
							 ->setLastModifiedBy("pta-surabaya.go.id")
							 ->setTitle("Laporan Perkara Pengadilan Agama")
							 ->setSubject("Laporan Perkara Pengadilan Agama")
							 ->setDescription("Pusat Pelaporan Data Perkara SiADPA & SiADPTA Online")
							 ->setKeywords("Pusat Pelaporan Data Perkara SiADPA & SiADPTA Online")
							 ->setCategory("Pusat Pelaporan Data Perkara SiADPA & SiADPTA Online");

// Add some data
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A2", strtoupper($nama_satker))
            ->setCellValue("A3", "BULAN ".strtoupper($bulan[($bln*1)])." TAHUN ".$thn)
            ->setCellValue("B43", "Ketua ".$nama_satker)
            ->setCellValue("B46", $nama_ketua)
            ->setCellValue("L42", $nama_kota.", ".$lastday." ".$bulan[($bln*1)]." ".$thn)
            ->setCellValue("L46", $nama_pansek);
			
$url_request = "id_parent=12&id_satker=$view_this_satker&blnAll=$bln&thn=$thn";
$fcontents = @file("http://infoperkara.badilag.net/fungsi_model/lipa/laporan_lipa8_wsdl.php?".$url_request);
//$fcontents = file("http://localhost/lipa/laporan_lipa8_wsdl.php?".$url_request);

unset($thisdata);
for ($i=0; $i<count($fcontents); $i++){
	//echo "<pre>".htmlentities($fcontents[$i])."<hr>";
	$pos = strpos ($fcontents[$i], "DATA>");
	if ($pos == true) {
		$fcontents[$i] = substr($fcontents[$i], $pos+5);
		$pos2 = strpos ($fcontents[$i], "</DATA>");
		if ($pos2 == true) {
			$thisdata = substr($fcontents[$i], 0, $pos2);
			//echo "<hr>".$thisdata;
		};//if-pos2
	};//if-pos
};//for

$arr_jenis = array('sisa_lalu', 'diterima', 'jml_1', 'dicabut', 'dikabulkan', 'ditolak', 'tdk_diterima', 'gugur', 'coret', 'jml_2', 'sisa_akhir', 'banding', 'kasasi', 'pk', 'ket');
if ($thisdata <> ""){
	$thisdata = base64_decode(base64_decode($thisdata));
	$linedata = @explode("|#", $thisdata);
	$jumlahrecord = count($linedata);
	//echo "<hr>".$thisdata;

	for ($i=0; $i<$jumlahrecord; $i++){
		//echo "$i. ".$linedata[$i]."<hr>";
		if (strlen($linedata[$i]) > 40){
			$colmdata = @explode("|:", $linedata[$i]);
			//echo $linedata[$i]."<br>";
				
			$id_jenis_perkara = $colmdata[0];
			for ($ii=0; $ii<count($arr_jenis); $ii++){
				$field_name = $arr_jenis[$ii];
				if ($colmdata[($ii+2)] <= 0){ $colmdata[($ii+2)]=""; }
			};//for

			$cc = $id_jenis_perkara + 8;
			$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue("C".$cc, $colmdata[2])
					->setCellValue("D".$cc, $colmdata[3])
					->setCellValue("F".$cc, $colmdata[5])
					->setCellValue("G".$cc, $colmdata[6])
					->setCellValue("H".$cc, $colmdata[7])
					->setCellValue("I".$cc, $colmdata[8])
					->setCellValue("J".$cc, $colmdata[9])
					->setCellValue("K".$cc, $colmdata[10])
					->setCellValue("N".$cc, $colmdata[13])
					->setCellValue("O".$cc, $colmdata[14])
					->setCellValue("P".$cc, $colmdata[15])
					->setCellValue("Q".$cc, $colmdata[16]);

		};//if strlen($linedata[$i]>10
	};//for
};//if



/*
//laporan lipa8
$runSQL = "select * from laporan_lipa8 where id_satker='$view_this_satker' and tahun='$thn' and bulan='$bln'";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	for ($i=0; $i<mysql_num_fields($result); $i++){
		$field_name = mysql_field_name($result, $i);
		if ($row[$field_name] == 0){ $row[$field_name]=""; }
	};//for

	$cc = $row["id_jenis_perkara"] + 8;
	$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("C".$cc, $row["sisa_lalu"])
            ->setCellValue("D".$cc, $row["diterima"])
            ->setCellValue("F".$cc, $row["dicabut"])
            ->setCellValue("G".$cc, $row["dikabulkan"])
            ->setCellValue("H".$cc, $row["ditolak"])
            ->setCellValue("I".$cc, $row["tdk_diterima"])
            ->setCellValue("J".$cc, $row["gugur"])
            ->setCellValue("K".$cc, $row["coret"])
            ->setCellValue("N".$cc, $row["banding"])
            ->setCellValue("O".$cc, $row["kasasi"])
            ->setCellValue("P".$cc, $row["pk"])
            ->setCellValue("Q".$cc, $row["ket"]);
};//while
*/

// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0);

// Redirect output to a client’s web browser (Excel5)
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="'.$fileDownload.'"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;
