<?php
// Pusat Pelaporan dan Data Statistik Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id
// Written by iyok642@yahoo.com, lastupdate 28 Pebruari 2014

@set_time_limit(3600);
@ini_set('memory_limit','1024M');

//parameter tanggal
$bln = $_POST["bln"]*1; if($bln==""){ $bln = $_GET["bln"]*1; }
$thn = $_POST["thn"]*1; if($thn==""){ $thn = $_GET["thn"]*1; };

//set default bulan tahun laporan
if ($bln==""){ 
	$bln = (date('m')-1)*1; $thn = date('Y')*1;
	if (date('d')>=25){ $bln = date('m')*1; }
	if ($bln==0){ $bln=12; $thn=(date('Y')-1)*1; }
};//if

$lastday = date ("t", mktime(0,0,0,$bln,1,$thn));
$numbday = date ("N", mktime(0,0,0,$bln,$lastday,$thn));
if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

//load setting
include_once("include.php");
include("include_login.php");

$iyok642 = $_GET["iyok642"]*1;
if ($iyok642 <> ""){ $SESS_ID_SATKER = $iyok642; }

//default id_parent
$id_parent = 12;
$runSQL = "select * from laporan_satker where id_satker='$SESS_ID_SATKER'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) { 
	if ($row[tk_satker]=="PA"){ $id_parent=$row[id_parent]; };
	if ($row[tk_satker]=="PTA"){ $id_parent=$row[id_satker]; };
};//while

//profile laporan
$runSQL = "select * from laporan_satker where id_satker=$id_parent";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$kode_perkara = $row[kode_perkara];
	$nama_satker = $row[nm_satker_pjg];
	$alamat_satker = $row[almt_satker];
	$website_email = "Website: ".$row[url_satker]." Email: ".$row[email_satker];
	$nama_ketua = $row[nama_ketua];
	$nama_pansek = $row[nama_pansek];
	$nama_kota = $row[nama_kota];
};//while

/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2013 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2013 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    1.7.9, 2013-06-02
 */

/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
date_default_timezone_set('Europe/London');

if (PHP_SAPI == 'cli')
	die('This example should only be run from a Web Browser');

/** Include PHPExcel */
require_once 'excell/PHPExcel.php';

if ($thn >= 2017){
  $fileTemplate = "master_delegasi_keluar_pta2017.xls";
} else {
  $fileTemplate = "master_rk_pta.xls";
};//if
$fileDownload = "DELEGASIKELUAR_".strtoupper($kode_perkara)."_".$bulan[($bln*1)]."_".$thn.".xls";

// Create new PHPExcel object
//$objPHPExcel = new PHPExcel();

// Read the file
$objReader = PHPExcel_IOFactory::createReader('Excel5');
$objPHPExcel = $objReader->load($fileTemplate);


// Set document properties
$objPHPExcel->getProperties()->setCreator("iyok642@yahoo.com")
							 ->setLastModifiedBy("pta-surabaya.go.id")
							 ->setTitle("Laporan Perkara Pengadilan Agama")
							 ->setSubject("Laporan Perkara Pengadilan Agama")
							 ->setDescription("Pusat Pelaporan Data Perkara SiADPA & SiADPTA Online")
							 ->setKeywords("Pusat Pelaporan Data Perkara SiADPA & SiADPTA Online")
							 ->setCategory("Pusat Pelaporan Data Perkara SiADPA & SiADPTA Online");

// Add some data
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A2", strtoupper($nama_satker))
            ->setCellValue("A3", "BULAN ".strtoupper($bulan[($bln*1)])." TAHUN ".$thn);
$this_nama_satker = $nama_satker;

//all satker dalam wil.hukum
$cc=8;
$data_satker=array();
$nama_satker=array();
$runSQL = "select * from laporan_satker where id_parent=$id_parent order by urutan_cetak, nm_satker";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	array_push($data_satker, $row["id_satker"]);
	array_push($nama_satker, $row["nm_satker"]);
	
	$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A".$cc, ($cc-7))
            ->setCellValue("B".$cc, $row["nm_satker"]);
	$cc++;
};//while
if (count($data_satker)>0){ $filterSQL="and (id_satker=".implode(" or id_satker=", $data_satker).")"; };


//regitrasi delegasi
$cc=6;
for($i=0; $i<count($data_satker); $i++){
	$id_satker = $data_satker[$i];
	$nm_satker = $nama_satker[$i];
	
	
	$runSQL2 = "select id_satker, tahun, bulan, id_session, lastupdate, kolom_1, kolom_2, kolom_3, kolom_4, kolom_5, kolom_6, kolom_7 as kolom_7srt, date_format(kolom_7,'%d-%m-%Y') kolom_7, date_format(kolom_8,'%d-%m-%Y') kolom_8, date_format(kolom_9,'%d-%m-%Y') kolom_9, date_format(kolom_10,'%d-%m-%Y') kolom_10, date_format(kolom_11,'%d-%m-%Y') kolom_11, kolom_12, id from laporan_delegasi_keluar where id_satker='$id_satker' and tahun='$thn' and bulan='$bln' order by kolom_6 asc";
	$result2 = mysql_query($runSQL2, $connDB);
	while ($row2 = mysql_fetch_array ($result2)) { 
		if (($row2["kolom_7"]=="00-00-0000")or($row2["kolom_7"]=="")){ $row2["kolom_7"]=" - "; }
		if (($row2["kolom_8"]=="00-00-0000")or($row2["kolom_8"]=="")){ $row2["kolom_8"]=" - "; }
		if (($row2["kolom_9"]=="00-00-0000")or($row2["kolom_9"]=="")){ $row2["kolom_9"]=" - "; }
		if (($row2["kolom_10"]=="00-00-0000")or($row2["kolom_10"]=="")){ $row2["kolom_10"]=" - "; }
		if (($row2["kolom_11"]=="00-00-0000")or($row2["kolom_11"]=="")){ $row2["kolom_11"]=" - "; }
		$cc++;
		$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A".$cc, ($cc-6))
				->setCellValue("B".$cc, $nama_satker[$i])
				->setCellValue("C".$cc, $row2["kolom_3"])
				->setCellValue("D".$cc, $row2["kolom_4"])
				->setCellValue("E".$cc, $row2["kolom_5"])
				->setCellValue("F".$cc, $row2["kolom_6"])
				->setCellValue("G".$cc, $row2["kolom_7"])
				->setCellValue("H".$cc, $row2["kolom_8"])
				->setCellValue("I".$cc, $row2["kolom_9"])
				->setCellValue("J".$cc, $row2["kolom_10"])
				->setCellValue("K".$cc, $row2["kolom_11"]);
	};//while
};//for


// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("C".($cc+3), "Ketua ".$this_nama_satker)
            ->setCellValue("C".($cc+7), $nama_ketua)
            ->setCellValue("K".($cc+2), $nama_kota.", ".$lastday." ".$bulan[($bln*1)]." ".$thn)
            ->setCellValue("K".($cc+3), "Panitera")
            ->setCellValue("K".($cc+7), $nama_pansek);
            

// Redirect output to a client’s web browser (Excel5)
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="'.$fileDownload.'"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;
