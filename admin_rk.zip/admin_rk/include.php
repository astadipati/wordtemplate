<?php
// Aplikasi Pendaftaran Perkara Online
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id
// Contact Tim IT PTA Surabaya, lastupdate 15 Mei 2013

session_start();
$SESSION_ID = session_id();
error_reporting(0);
date_default_timezone_set("Asia/Calcutta");
//error_reporting (E_ALL ^ E_NOTICE); 

//load setting
include_once("@konfigurasi.php");

//hapus php error_log
if ((date("i")*1) < 10){ @unlink("error_log"); }

//try to connect database
if (!$connDB){ $connDB = mysql_connect($hostserver, $dbusername, $dbpassword) or die("User/Password Database Failed."); };
if (!$useDB){ $useDB = mysql_select_db($database, $connDB) or die("Database Name Invalid."); };

//preset parameter
$REMOTE_ADDR = get_ip_address();   //getenv("REMOTE_ADDR");
$QUERY_STRING = getenv("QUERY_STRING");
$HTTP_USER_AGENT = getenv("HTTP_USER_AGENT");

//get parameter script_name
$tmp_script = $_SERVER["SCRIPT_NAME"];
$SCRIPT_NAME = $tmp_script;
$pos = strrpos(" ".$tmp_script, "/");
if($pos == true){
	$SCRIPT_NAME = substr($tmp_script, $pos);
};//id

//set parameter script_name for history
$runSQL = "select id_page from sys_pagename where file_name='$SCRIPT_NAME'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) { 
	$id_page = $row[id_page];
} else {
  $runSQL = "insert into sys_pagename (file_name, created) values ('$SCRIPT_NAME', NOW())";
  $insert = mysql_query($runSQL, $connDB);
  $id_page = mysql_insert_id($connDB);
};//if

//set parameter browser for history
$runSQL = "select id_browser from sys_browser where browser='$HTTP_USER_AGENT'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) { 
	$id_browser = $row[id_browser];
} else {
  $runSQL = "insert into sys_browser (browser, created) values ('$HTTP_USER_AGENT', NOW())";
  $insert = mysql_query($runSQL, $connDB);
  $id_browser = mysql_insert_id($connDB);
};//if

//set parameter ipaddress for history
$runSQL = "select id_location from sys_location where ipaddress='$REMOTE_ADDR'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) { 
	$id_location = $row[id_location];
} else {
  $runSQL = "insert into sys_location (ipaddress, created) values ('$REMOTE_ADDR', NOW())";
  $insert = mysql_query($runSQL, $connDB);
  $id_location = mysql_insert_id($connDB);
};//if


//recorder log history web access
$runSQL = "select currentdate, session_id, page_access from sys_user_access where currentdate=CURDATE() and session_id='$SESSION_ID' and ipaddress='$REMOTE_ADDR'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) { 
	$page_access = $row[page_access];
	unset($found_pa);
	$content = explode ("#", $page_access);
	for($i=0; $i<count($content); $i++){
		unset($variabel, $found_page);
		$variabel = explode(";", $content[$i]);
		if ($variabel[0]=="$c_pta:$c_pa"){
			$found_pa = 1;
			for($j=1; $j<count($variabel); $j++){
				unset($value);
				$value = explode(":", $variabel[$j]);
				if ($value[0]==$id_page){ $value[1]=$value[1]+1; $found_page=1; };
				$variabel[$j] = implode(":",$value);
			};//for
			if ($found_page <> 1){ $variabel[$j+1] = "$id_page:1"; };
		};//if
		$content[$i] = implode(";",$variabel);
	};//for
	if ($found_pa <> 1){ $content[$i+1] = "$c_pta:$c_pa;$id_page:1"; };
	$page_access = implode("#",$content);
	
	//echo $page_access;
	$runSQL = "update sys_user_access set last_time=CURTIME(), hit_count=hit_count+1, page_access='$page_access' where currentdate=CURDATE() and session_id='$SESSION_ID' and ipaddress='$REMOTE_ADDR'";
	$update = mysql_query($runSQL, $connDB);
} else {
	$page_access = "$c_pta:$c_pa;$id_page:1";
	$runSQL = "insert into sys_user_access (currentdate, session_id, ipaddress, start_time, last_time, hit_count, id_location, id_browser, page_access, var_access) values (CURDATE(), '$SESSION_ID', '$REMOTE_ADDR', CURTIME(), CURTIME(), 1, '$id_location', '$id_browser', '$page_access', ':')";
	$insert = mysql_query($runSQL, $connDB);
};//if

function fdate($tanggal){
	if ($tanggal <> ""){
		$tmp = explode("-", $tanggal);
		$tanggal = "$tmp[2]-$tmp[1]-$tmp[0]";
	};
	return $tanggal;
};//fdate

function currency($number){
  $str = strtolower($number);
  $pos += strpos($str,"a")+strpos($str,"i")+strpos($str,"u")+strpos($str,"e")+strpos($str,"o")+strpos($str,"k")+strpos($str,"p")+strpos($str,"h");
  $pos += strpos($str,"s")+strpos($str,"d")+strpos($str,"f")+strpos($str,"g")+strpos($str,"j")+strpos($str,"l")+strpos($str,"m")+strpos($str,"v");
  $pos += strpos($str,"-")+strpos($str,"+")+strpos($str,"/")+strpos($str,".");
  if (!$pos){
	$bit = strlen($number);
	$i=1;
	while ($cur < $bit){
		$cur = $i * 3;
		if ($cur > $bit){ $length= 3-($cur-$bit); }else{ $length=3; }
		$pointer = $cur * -1;
		$lsb = substr($number,$pointer,$length);
		$i++;

		if ($currency==""){ $sparator=""; }else{ $sparator="."; };
		$currency = $lsb.$sparator.$currency;
	};//while
    return $currency;
  } else {
    return $number;
  };
};//currency

function thisstring($text){
  $str = strtolower($text);
  $pos += strpos($str,"q")+strpos($str,"w")+strpos($str,"e")+strpos($str,"r")+strpos($str,"t")+strpos($str,"y")+strpos($str,"u")+strpos($str,"i")+strpos($str,"o");
  $pos += strpos($str,"a")+strpos($str,"s")+strpos($str,"d")+strpos($str,"f")+strpos($str,"g")+strpos($str,"h")+strpos($str,"j")+strpos($str,"k")+strpos($str,"l");
  $pos += strpos($str,"z")+strpos($str,"x")+strpos($str,"c")+strpos($str,"v")+strpos($str,"b")+strpos($str,"n")+strpos($str,"m")+strpos($str,"p");
  if (!$pos){
    return 0;
  } else {
    return 1;
  };
};//thisstring

//calculate page view
if ($pnum == ""){ $pnum = $_REQUEST["pnum"]; }
function pageViewRecord ($pnum, $totalRecord, $pageLink, $listRecord = 10) {
  global $pnum, $totalRecord, $beginPage, $endPage, $totalPage, $offsetRecord, $pnumlink;

  if (!isset($pnum)) { $pnum=1; };
  if (!isset($listRecord)) { $listRecord=10; };
  if ($totalRecord>0) {
    $totalPage = intval($totalRecord / $listRecord);
    if (($totalRecord % $listRecord)<>0) { $totalPage++;};
    $offsetRecord=($pnum-1) * $listRecord;
      $limitPage=10;
      if ($pnum>$totalPage){$pnum=$totalPage;};
      $nextPage = intval($pnum/$limitPage);
      if (($pnum % $limitPage)<>0) {$nextPage++;};
      //$beginPage = (($nextPage-1)*$limitPage)+1;
      $beginPage = $pnum - ( intval($limitPage/2) );
      if ($beginPage <= 0) { $beginPage = 1; };
      //$endPage = $nextPage*$limitPage;
      $endPage = $pnum + ( intval($limitPage/2) );
      if ($endPage - $beginPage < $limitPage) { $endPage = $endPage + ($limitPage - ($endPage - $beginPage) - 1); }
      if ($endPage>$totalPage) {$endPage=$totalPage;};
  }else{
    $listRecord=0;
    $offsetRecord=0;
  };  
  $beginLINK = "<a href='"; 
  $endLINK = "' style='text-decoration:none'>";
  if ($beginPage>1) { $pnumlink .= $beginLINK . $pageLink."1" . $endLINK . "<b>�</b></a>&nbsp;"; }
  if ($pnum>1) { $pnumlink .= $beginLINK . $pageLink.($pnum-1) . $endLINK . "<b>�</b></a>"; };
  for ($hit=$beginPage; $hit<=$endPage; $hit++){
    if($pnum==$hit) {$pnumlink.="<font color='#FF0000'><b>&nbsp;".$hit."&nbsp;&nbsp;</b></font>";}
    else {$pnumlink.="&nbsp;".$beginLINK . $pageLink.$hit . $endLINK.$hit."</a>&nbsp;&nbsp;";};
  }; 
  if ($pnum<$totalPage){ $pnumlink.=$beginLINK . $pageLink.($pnum+1) . $endLINK."<b>�</b></a>"; };
  if ($endPage<$totalPage){ $pnumlink.="&nbsp;".$beginLINK . $pageLink.$totalPage . $endLINK."<b>�</b></a>"; };
  if ($totalPage == 0){ $pnumlink = "<b>0</b>"; };
  if ($totalPage == ""){ $totalPage=0; }
  return $pnumlink;
};//pageViewRecord

function changeDateFormat($text, $cek = 1){
	$text_orig = $text;

	$text = str_replace("Mon","Senin",$text);
	$text = str_replace("Tue","Selasa",$text);
	$text = str_replace("Wed","Rabu",$text);
	$text = str_replace("Thu","Kamis",$text);
	$text = str_replace("Fri","Jumat",$text);
	$text = str_replace("Sat","Sabtu",$text);
	$text = str_replace("Sun","Minggu",$text);

	$text = str_replace("Jan","Januari",$text);
	$text = str_replace("Feb","Februari",$text);
	$text = str_replace("Mar","Maret",$text);
	$text = str_replace("Apr","April",$text);
	$text = str_replace("May","Mei",$text);
	$text = str_replace("Jun","Juni",$text);
	$text = str_replace("Jul","Juli",$text);
	$text = str_replace("Aug","Agustus",$text);
	$text = str_replace("Sep","September",$text);
	$text = str_replace("Oct","Oktober",$text);
	$text = str_replace("Nov","November",$text);
	$text = str_replace("Dec","Desember",$text);

	return $text;
};//changeDateFormat

function namaALIAS($text){
	$except = array("BIN", "BINTI");
	$splited = @split (" ", strtoupper($text));
	for ($j=0; $j<count($splited); $j++){ 
		if (!in_array ($splited[$j], $except)){
			$len = strlen($splited[$j]);
			if ($len > 2){ 
				$nama .= substr($splited[$j],0,1);
			} else {
				$nama .= " ".$splited[$j]." ";
			};//if
		} else {
			$nama .= " <font color='#0000FF'>".strtolower($splited[$j])."</font> ";
		};//if
	};//for
	return $nama;
};//namaALIAS

//setting parameter web
$result = mysql_query("select variable, value from laporan_settings where onload='1'");
while ($row = mysql_fetch_array ($result)) { 
  $textdata = $row[value];
  $jml_php = substr_count($textdata, '".');
  for ($xx=0; $xx<$jml_php; $xx++){
    $cursor_awal = strpos($textdata, '".')+2;
    $cursor_akhir = strpos($textdata, '."');
    if (($cursor_awal > 0) and ($cursor_akhir > 0)){ 
      $run_php = substr($textdata, $cursor_awal, $cursor_akhir-$cursor_awal);
      eval ("\$isi_php = $run_php;");
      $textdata = str_replace('".'.$run_php.'."', $isi_php, $textdata);
    };//if
  };//for
  $row[value] = $textdata;
  
  $nama_var = $row[variable];
  $isi_var = addslashes($row[value]);
  $isi_var = str_replace('"',"'",$isi_var);
  $variable = "\$".$nama_var."=\"".$isi_var."\";";
  eval($variable);
  $$nama_var = stripslashes($$nama_var);
};//while

//=======HTML TANGGAL========//

$hari = array ("Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu");	
$bulan = array ("--All--","Januari","Pebruari","Maret","April","Mei","Juni",
                "Juli","Agustus","September","Oktober","November","Desember");
$bulannum = array ("00","01","02","03","04","05","06","07","08","09","10","11","12");

if ($tgl == ""){ $tgl=date('d'); }
if ($bln == ""){ $bln=date('m'); }
if ($thn == ""){ $thn=date('Y'); }

unset($selecttanggal);
for($i=1; $i<=31; $i++){ 
	if($i < 10){ $ii='0'.$i; }else{ $ii=$i; };
	if(($tgl == $ii)or(($tgl == "")and( $ii==date('d')))){ $cek="selected"; }else{ unset($cek); }
	$selecttanggal .= "<option value='".$ii."' $cek>".$ii."</option>\n"; 
};//end-for

unset($selectbulan);
for($i=1; $i<count($bulan); $i++){
	if(($bln == $bulannum[$i])or(($bln == "")and(($i+1) == date('m')))){ $cek="selected"; }else{ unset($cek); }
	$selectbulan .= "<option value='".$bulannum[$i]."' $cek>".$bulan[$i]."</option>\n"; 
};//end-for

unset($selectbulanAll);
if ($blnAll == ""){ $blnAll=date('m'); }
for($i=0; $i<count($bulan); $i++){
	if($blnAll == $bulannum[$i]){ $cek="selected"; }else{ unset($cek); }
	$selectbulanAll .= "<option value='".$bulannum[$i]."' $cek>".$bulan[$i]."</option>\n"; 
};//end-for

$start_tahun = 2008;
unset($selecttahun,$selecttahunAll);
if($start_tahun == ""){ $start_tahun=date('Y'); }
for($i=$start_tahun; $i<=date('Y'); $i++) {
	if(($thn==$i)or(($thn=="")and($i==date('Y')))){$cek="selected";}else{unset($cek);}
	$selecttahun.="<option value='$i' $cek>".$i."</option>\n";

	if($thnAll==$i){$cek="selected";}else{unset($cek);}
	$selecttahunAll.="<option value='$i' $cek>".$i."</option>\n";
};//end-for

$selecttanggal = "<select size=1 name='tgl' class='edyellow'> $selecttanggal </select>";
$selectbulan = "<select size=1 name='bln' class='edyellow'> $selectbulan </select>";
$selectbulanAll = "<select size=1 name='blnAll' class='edyellow'> $selectbulanAll </select>";
$selecttahun = "<select size=1 name='thn' class='edyellow'> $selecttahun </select>";

if ($thnAll == ""){ $cek="selected"; }else{ unset($cek); }
$selecttahunAll = "<option value='' $cek>-- All --</option>\n" . $selecttahunAll;
$selecttahunAll = "<select size=1 name='thnAll' class='edyellow'> $selecttahunAll </select>";

//=======END.HTML TANGGAL========//

function get_ip_address() {
	// check for shared internet/ISP IP
	if (!empty($_SERVER['HTTP_CLIENT_IP']) && validate_ip($_SERVER['HTTP_CLIENT_IP'])) {
		return $_SERVER['HTTP_CLIENT_IP'];
	};
	 
	// check for IPs passing through proxies
	if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		// check if multiple ips exist in var
		if (strpos($_SERVER['HTTP_X_FORWARDED_FOR'], ',') !== false) {
			$iplist = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
			foreach ($iplist as $ip) {
				if (validate_ip($ip))
					return $ip;
			};
		} else {
			if (validate_ip($_SERVER['HTTP_X_FORWARDED_FOR']))
				return $_SERVER['HTTP_X_FORWARDED_FOR'];
		};
	};
	if (!empty($_SERVER['HTTP_X_FORWARDED']) && validate_ip($_SERVER['HTTP_X_FORWARDED']))
		return $_SERVER['HTTP_X_FORWARDED'];
	if (!empty($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']) && validate_ip($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
		return $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
	if (!empty($_SERVER['HTTP_FORWARDED_FOR']) && validate_ip($_SERVER['HTTP_FORWARDED_FOR']))
		return $_SERVER['HTTP_FORWARDED_FOR'];
	if (!empty($_SERVER['HTTP_FORWARDED']) && validate_ip($_SERVER['HTTP_FORWARDED']))
		return $_SERVER['HTTP_FORWARDED'];
	 
	// return unreliable ip since all else failed
	if (isset($_SERVER)) {
		return $_SERVER['REMOTE_ADDR'];
	} else {
		return getenv('REMOTE_ADDR');
	};//if
};//get_ip_address


function validate_ip($ip) {
	if (strtolower($ip) === 'unknown')
	return false;
	 
	// generate ipv4 network address
	$ip = ip2long($ip);
	 
	// if the ip is set and not equivalent to 255.255.255.255
	if ($ip !== false && $ip !== -1) {
		// make sure to get unsigned long representation of ip
		// due to discrepancies between 32 and 64 bit OSes and
		// signed numbers (ints default to signed in PHP)
		$ip = sprintf('%u', $ip);
		// do private network range checking
		if ($ip >= 0 && $ip <= 50331647) return false;
		if ($ip >= 167772160 && $ip <= 184549375) return false;
		if ($ip >= 2130706432 && $ip <= 2147483647) return false;
		if ($ip >= 2851995648 && $ip <= 2852061183) return false;
		if ($ip >= 2886729728 && $ip <= 2887778303) return false;
		if ($ip >= 3221225984 && $ip <= 3221226239) return false;
		if ($ip >= 3232235520 && $ip <= 3232301055) return false;
		if ($ip >= 4294967040) return false;
	}
	return true;
};//validate_ip
?>