<?php
// Data Statistik dan Pusat Pelaporan Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id
// Contact iyok642@yahoo.com, lastupdate 28 Pebruari 2014

//load setting
include_once("include.php");

//data satker
$runSQL = "select * from laporan_satker where id_satker='$SESS_ID_SATKER'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) { 
	$this_satker = $row[nm_satker_pjg];
};//while

?>
<table width="200" height="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td vAlign="top">
	<table width='100%' border='0' cellpadding='3' cellspacing='0'>
	  <tr><td width='100%'></td></tr>
	</table>
	<table width='100%' border='0' cellpadding='3' cellspacing='0'>
	  <tr><td width='100%' colspan='4' bgcolor='#004A00' align='center'><font color="#FFFF00"><b>INPUT RK MANUAL </b>(PA)</font></td></tr>
	  <tr>
	    <td width='1%' bgcolor='#66CC00'></td>
	    <td width='33%' bgcolor='#66CC00'>
		<a href='rk3_input.php'><b>RK.3</a><br>
		<a href='rk4_input.php'><b>RK.4</a><br>
		<!--<a href='rk5_input.php'><b>RK.5</a><br>-->
		<a href='rk5new_input.php'><b>RK.5new</a><br>
		<a href='rk6_input.php'><b>RK.6</a><br>
		<a href='rk7a_input.php'><b>RK.7a</a><br>
		<a href='rk7b_input.php'><b>RK.7b</a><br>
	    </td>
        <td width='33%' bgcolor='#66CC00'>
		<a href='rk7c_input.php'><b>RK.7c</a><br>
	    <a href='rk8a_input.php'><b>RK.8a</a><br>
		<a href='rk8b_input.php'>RK.8b</a><br>
		<a href='rk8c_input.php'>RK.8c</a><br>
		<a href='rk9_input.php'><b>RK.9</a><br>
		<a href='rk10_input.php'><b>RK.10</a><br>
		</td>
		<td width='33%' bgcolor='#66CC00'>
		<a href='rk11a_input.php'><b>RK.11a</a><br>
		<a href='rk11b_input.php'>RK.11b</a><br>
		<a href='rk12_input.php'><b>RK.12</a><br>
		<a href='rkma_input.php'><b>RK.MA</a><br>
		<a href='rkesyar_input.php'>RK.ESyar</a><br>
		<br>
		</td>
		</tr>
	  <tr>
	    <td width='1%' bgcolor='#66CC00'></td>
	    <td width='99%' colspan='3' bgcolor='#66CC00'><a href='lyterpadu_input.php'><b>Pelayanan Terpadu</a></td>
		</tr>
	  <tr>
	    <td width='1%' bgcolor='#66CC00'></td>
	    <td width='99%' colspan='3' bgcolor='#66CC00'>
	        <a href='delegasi_input.php'><b>Register Delegasi</a><br>
	        <a href='delegasi_keluar_input.php'><b>Register Delegasi Keluar</a>
	    </td>
		</tr>
	</table>
	<br>
	<table width='100%' border='0' cellpadding='3' cellspacing='0'>
	  <tr><td width='100%' colspan='4' bgcolor='#004A00' align='center'><font color="#FFFF00"><b>INPUT RK MANUAL </b>(PTA)</font></td></tr>
	  <tr>
	    <td width='1%' bgcolor='#66CC00'></td>
	    <td width='33%' bgcolor='#66CC00'>
	    <a href='rk1_input.php'><b>RK.1</a><br>
		<a href='rk2_input.php'><b>RK.2</a><br>
	    </td>
        <td width='33%' bgcolor='#66CC00'>
		<a href='rk7a_input.php'><b>RK.7a</a><br>
		<a href='rk11b_input.php'>RK.11b</a><br>
		</td>
		<td width='33%' bgcolor='#66CC00' valign='top'>
		<a href='rk12_input.php'><b>RK.12</a><br>
		</td>
		</tr>
	</table>
	<br>
	<table width='100%' border='0' cellpadding='3' cellspacing='0'>
	  <tr><td width='100%' colspan='4' bgcolor='#004A00' align='center'><font color="#FFFF00"><b>CETAK LAPORAN</b></font></td></tr>
	  <tr>
	    <td width='1%' bgcolor='#66CC00'></td>
	    <td width='99%' bgcolor='#66CC00'>
          - <a href='tampil.php'><b>Laporan RK PA</b></a><hr size='1' color='#66FF00'>
          - <a href='tampil_pta.php'><b>Laporan RK PTA</b></a><hr size='1' color='#66FF00'>
          <!-- - <a href='tampil_lipa8.php'><b>LIPA.7</b></a><br>-->
          - <a href='tampil_lipa8.php'><b>LIPA.8</b></a>
        </td>
		</tr>
	</table>
	<br>
	<table width='100%' border='0' cellpadding='3' cellspacing='0'>
	  <tr><td width='100%' colspan='4' bgcolor='#004A00' align='center'><font color="#FFFF00"><b>SETTING</b></font></td></tr>
	  <tr>
	    <td width='1%' bgcolor='#66CC00'></td>
	    <td width='99%' bgcolor='#66CC00'>
          - <a href='ttd_input.php'>Penandatangan</a><br>
		  <!--
          - <a href='lock_input.php'>Kunci Laporan</a><br>
          - <a href='revisi_input.php'>Pengajuan Revisi</a>
		  -->
        </td>
		</tr>
	</table>

	<br><br>
	
	<p align="center"><font color="#FFFFFF"><?=$this_satker;?><br><br><a href="admin_login.php?do=logout" style="text-decoration:none"><img src="img/logout.png"></a></p>
	<!--
    <table width="90%" border="1" cellpadding="5" cellspacing="1" align="center" style="border-collapse:collapse" bordercolor="#006600">
      <tr>
		<td bgcolor="#009900" align="center">
		<font size="1" color="#FFFF00">Email<br></font><b><?php echo $email_pa; ?></b><br><br>
		</td>
	  </tr>
	</table>
	-->
	</td>
  </tr>
  <tr>
    <td vAlign="bottom" align="center"><font color="#009900" size="1"><i><? echo $REMOTE_ADDR; ?><br>Versi 01.2014<br><br></td>
  </tr>
</table>
