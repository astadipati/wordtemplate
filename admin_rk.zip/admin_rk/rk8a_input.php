<?php
// Data Statistik dan Pusat Pelaporan Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id/laporan
// Contact iyok642@yahoo.com, lastupdate 28 Pebruari 2014

//parameter tanggal
if($bln == ""){ $bln = $_POST["bln"]*1; };  if($bln == ""){ $bln = $_GET["bln"]*1; };
if($thn == ""){ $thn = $_POST["thn"]*1; };  if($thn == ""){ $thn = $_GET["thn"]*1; };
if($laporan == ""){ $laporan = $_POST["laporan"]*1; };  if($laporan == ""){ $laporan = $_GET["laporan"]*1; };

//set default bulan tahun laporan
if ($bln==""){ 
	$bln = (date('m')-1)*1; $thn = date('Y')*1;
	if (date('d')>=20){ $bln = date('m')*1; }
	if ($bln==0){ $bln=12; $thn=(date('Y')-1)*1; }
};//if
if ($laporan == ""){ $laporan="$thn$bln"; };

//load setting
include_once("include.php");
include("include_login.php");

//post variable
$run      = $_POST["run"];
$kolom_1  = $_POST["kolom_1"]*1;
$kolom_2  = $_POST["kolom_2"];	
$kolom_3  = $_POST["kolom_3"]*1;
$kolom_4  = $_POST["kolom_4"]*1;
$kolom_5  = $_POST["kolom_5"]*1;
$kolom_6  = $_POST["kolom_6"]*1;
$kolom_7  = $_POST["kolom_7"]*1;
$kolom_8  = $_POST["kolom_8"]*1;
$kolom_9  = $_POST["kolom_9"]*1;

//data satker
$runSQL = "select * from laporan_satker where id_satker=$SESS_ID_SATKER";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$nm_satker_pjg = $row[nm_satker_pjg];
	$kolom_1 = $row[id_satker];
	$kolom_2 = $row[nm_satker];
};//while

//variabel bulan tahun laporan
$bulan_laporan=array(); $value_laporan=array();
for($i=1; $i<=$bln; $i++){
	$nama_bln = $bulan[$i];
	array_push($bulan_laporan, " $nama_bln $thn ");
	array_push($value_laporan, "$thn$i");
};//for

//pilihan bulan tahun laporan
for($i=0; $i<count($bulan_laporan); $i++){
	if ($value_laporan[$i]==$laporan) { $cek="selected"; $bln=substr($laporan,4,2)*1; $thn=substr($laporan,0,4)*1; }else{ unset($cek); }
	$selectlaporan .= "<option value=\"".$value_laporan[$i]."\" $cek> &nbsp; ".$bulan_laporan[$i]." &nbsp; </option>"; 
};//for
$selectlaporan = "<select size=1 name=\"laporan\" onChange=\"runJump(this.value)\" class=\"laporanfree\"> $selectlaporan </select>";

if (strlen($run) < 1){ 
	$runSQL = "select * from laporan_rk8a where id_satker=$SESS_ID_SATKER and tahun=$thn and bulan=$bln";
	$result = mysql_query($runSQL, $connDB);
    if ($row = mysql_fetch_array ($result)) {
		$kolom_1  = $row["kolom_1"];
		$kolom_2  = $row["kolom_2"];
		$kolom_3  = $row["kolom_3"];
		$kolom_4  = $row["kolom_4"];
		$kolom_5  = $row["kolom_5"];
		$kolom_6  = $row["kolom_6"];
		$kolom_7  = $row["kolom_7"];
		$kolom_8  = $row["kolom_8"];
		$kolom_9  = $row["kolom_9"];
   };//if
};//if-id

//realisasi bulan lalu RK.8a
$bln_lalu=$bln-1;  $thn_lalu=$thn;
if ($bln_lalu==0){ $bln_lalu=12; $thn_lalu=$thn-1; }
$runSQL="select * from laporan_rk8a where id_satker=$SESS_ID_SATKER and tahun=$thn_lalu and bulan=$bln_lalu";
$result=mysql_query($runSQL, $connDB);
if ($row=mysql_fetch_array($result)) {
	$pagu_bulan_lalu=$row[kolom_3];
	$realisasi_bulan_lalu=$row[kolom_6];
};//if

if ($bln > 1){
	$kolom_3 = $pagu_bulan_lalu;
	if ($realisasi_bulan_lalu<>$kolom_4){ $kolom_4 = $realisasi_bulan_lalu; };
	$readonly="readonly";
};//if

$kolom_6 = $kolom_4 + $kolom_5;
$kolom_7 = $kolom_3 - $kolom_6;

//submit form
if (strlen($run) > 1){ 
    $valid = 1;
    if (($kolom_3>0) and ($kolom_3<1000)){ $ikolom_3 = "<br><font color='#FF0000' size='1'><i>* Nilai rupiah tidak valid.<br>(jangan gunakan . atau ,)"; $valid = 0; }
    if (($kolom_4>0) and ($kolom_4<1000)){ $ikolom_4 = "<br><font color='#FF0000' size='1'><i>* Nilai rupiah tidak valid.<br>(jangan gunakan . atau ,)"; $valid = 0; }
    if (($kolom_5>0) and ($kolom_5<1000)){ $ikolom_5 = "<br><font color='#FF0000' size='1'><i>* Nilai rupiah tidak valid.<br>(jangan gunakan . atau ,)"; $valid = 0; }

    if ($valid == 1){
		$runSQL = "select * from laporan_rk8a where id_satker=$SESS_ID_SATKER and tahun=$thn and bulan=$bln";
		$result = mysql_query($runSQL, $connDB);
		if ($row = mysql_fetch_array($result)) {
			$submitValid = 1;
			$runSQL = "update laporan_rk8a set id_session='$SESSION_ID', lastupdate=now(), kolom_1='$kolom_1', kolom_2='$kolom_2', kolom_3='$kolom_3', kolom_4='$kolom_4', kolom_5='$kolom_5', kolom_6='$kolom_6', kolom_7='$kolom_7', kolom_8='$kolom_8', kolom_9='$kolom_9' where id_satker='$SESS_ID_SATKER' and tahun='$thn' and bulan='$bln'";
			$update = mysql_query($runSQL, $connDB);
		} else {
			$submitValid = 1;
			$runSQL = "insert into laporan_rk8a (id_satker, tahun, bulan, id_session, lastupdate, kolom_1, kolom_2, kolom_3, kolom_4, kolom_5, kolom_6, kolom_7, kolom_8, kolom_9) VALUES ('$SESS_ID_SATKER', '$thn', '$bln', '$SESSION_ID', now(), '$kolom_1', '$kolom_2', '$kolom_3', '$kolom_4', '$kolom_5', '$kolom_6', '$kolom_7', '$kolom_8', '$kolom_9')";
			$insert = mysql_query($runSQL, $connDB);
			//echo "$runSQL<br>";
		};//if
    };//isian valid
};//end-if-submit

?>
<html>
<head>
  <meta name="Generator" content="EditPlus">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <meta name="Description" content="Sistem Pendaftaran Perkara Secara Online Pengadilan Agama">
  <title>Laporan Perkara RK.8a <? echo $bulan[($bln*1)]." ".$thn; ?></title>
  <link rel="shortcut icon" href="favicon.ico">
  <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
 <tr>
   <td align="center">
	<table width="980" border="0" cellpadding="0" cellspacing="0">
	</table>
	<table width="980" height="450" border="0" cellpadding="0" cellspacing="0" align="center">
	  <tr><td width="100%" colspan="2"><?php include("header.php"); ?></td></tr>
	  <tr>
        <td width="200" valign="top" bgcolor="#336600"><?php include("menu.php"); ?></td>
        <td width="780" valign="top">
		<table width="100%" height="450" bgcolor="#FFFFFF" border="1" cellpadding="10" cellspacing="0" style="border-collapse:collapse" bordercolor="#003300">
		 <tr>
			<td width="100%" vAlign="top">
			<!--content-->
	
<? if ($submitValid <> 1){?>

    <form method="POST" name="form" ENCTYPE="multipart/form-data" action="<? echo $_SERVER["PHP_SELF"]; ?>">
    <table align="center" border="0" cellpadding="5" cellspacing="1" width="750">
      <tr>
        <td width="100%" colspan="5" align="center">
		<? echo $selectlaporan; ?><br>
		<font color="#0000FF" size="3"><b>Pengisian RK.8a <? echo $bulan[($bln*1)]." ".$thn; ?></b></font>
        <br><font color="#0000FF">Laporan Pelaksanaan Sidang Keliling.
        <hr size="1" color="#003300">
		</td>
      </tr>
    </table>
    <table align="center" border="0" cellpadding="5" cellspacing="1" width="500">
      <tr>
        <td bgcolor='#339900' width="100%" colspan="5"><b>Laporan RK.8a bulan <? echo $bulan[($bln*1)]." ".$thn; ?></b></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>1</td>
        <td width="30%" align="left" nowrap>Nomor</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input readonly type="text" name="kolom_1" size="<?=strlen($kolom_1)+3;?>" value="<?=htmlentities(stripslashes($kolom_1));?>"><? echo $ikolom_1; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>2</td>
        <td width="30%" align="left" nowrap>Nama Pengadilan</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input readonly type="text" name="kolom_2" size="<?=strlen($kolom_2)+3;?>" value="<?=htmlentities(stripslashes($kolom_2));?>"><? echo $ikolom_2; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>3</td>
        <td width="30%" align="left" nowrap>Pagu Tahun <?=$thn;?></td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input <?=$readonly;?> type="text" name="kolom_3" size="15" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_3));?>"><? echo $ikolom_3; ?> <font size="1"><i><? if($readonly==""){ echo "<font color='#FF0000'>Input Pagu Tahun $thn *)"; }else{ echo "<font color='#6600FF'>Anggaran Sidkel Dipa.04"; }; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>4</td>
        <td width="30%" align="left" nowrap>Realisasi Bulan Lalu</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input <?=$readonly;?> type="text" name="kolom_4" size="15" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_4));?>"><? echo $ikolom_4; ?> <font size="1"><i><? if($readonly==""){ echo "<font color='#FF0000'>Input Realisasi Bulan Lalu *)"; }else{ echo "<font color='#6600FF'>Dari Lap. Sebelumnya"; }; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>5</td>
        <td width="30%" align="left" nowrap>Realisasi Bulan Ini</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_5" size="15" onChange="calculate()" value="<?=htmlentities(stripslashes($kolom_5));?>"><? echo $ikolom_5; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>6</td>
        <td width="30%" align="left" nowrap>Jumlah</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input readonly type="text" name="kolom_6" size="15" value="<?=htmlentities(stripslashes($kolom_6));?>"><? echo $ikolom_6; ?> <font size="1" color="#6600FF"><i>Jumlah Otomatis</td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>7</td>
        <td width="30%" align="left" nowrap>Sisa</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input readonly type="text" name="kolom_7" size="15" value="<?=htmlentities(stripslashes($kolom_7));?>"><? echo $ikolom_7; ?> <font size="1" color="#6600FF"><i>Sisa Otomatis</td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>8</td>
        <td width="30%" align="left" nowrap>Jumlah Kegiatan</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_8" size="5" value="<?=htmlentities(stripslashes($kolom_8));?>"><? echo $ikolom_8; ?> <font size="1" color="#6600FF"><i>Kegiatan bulan berjalan</td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>9</td>
        <td width="30%" align="left" nowrap>Jumlah Perkara</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="64%"><input type="text" name="kolom_9" size="5" value="<?=htmlentities(stripslashes($kolom_9));?>"><? echo $ikolom_9; ?> <font size="1" color="#6600FF"><i>Perkara bulan berjalan</td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
		<td width="100%" height="50" colspan="5" align="center" valign="middle">
		<input type="hidden" name="bln" value="<?=$bln;?>"><input type="hidden" name="thn" value="<?=$thn;?>">
		<input type="submit" value="    Simpan   " name="run" class="button">
		</td>
	  </tr>
	  <? if($readonly==""){ echo "<tr><td colspan='5' height='40' valign='bottom' align='right'><font color='#FF0000' size='1'><i>*) Pagu dan Realisasi bulan lalu dapat diubah pada awal tahun pelaporan, bulan januari.</td></tr>"; }; ?>
	</table>
    </form>
	<script language="Javascript" type="text/javascript">
	function runJump(val) {
	  window.location='<?=$_SERVER["PHP_SELF"];?>?laporan='+val; //make connection
	}

	function calculate() {
	 document.form.kolom_6.value = eval(document.form.kolom_4.value) + eval(document.form.kolom_5.value);
	 document.form.kolom_7.value = eval(document.form.kolom_3.value) - eval(document.form.kolom_6.value);
	}
	</script>
    <table height="300" align="center" border="0" cellpadding="5" cellspacing="1">
      <tr>
        <td width="100%"> &nbsp; </td>
      </tr>
    </table>

<? }else{?>

    <table align="center" border="0" cellpadding="5" cellspacing="1" width="750">
      <tr>
        <td width="100%" colspan="5" align="center"><font color="#0000FF" size="3"><b>Laporan RK.8a berhasil disimpan</b></font>
        <hr size="1" color="#003300">
		</td>
      </tr>
    </table>
    <table align="center" border="0" cellpadding="20" cellspacing="1" width="500">
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="100%" align="center">
		Laporan RK.8a bulan <?=$bulan[($bln*1)]." ".$thn;?> Satker <?=$nm_satker_pjg;?> berhasil disimpan.
		</td>
      </tr>
    </table>
    <table height="500" align="center" border="0" cellpadding="5" cellspacing="1">
      <tr>
        <td width="100%">[ <a href="tampil.php">Tampilkan RK Gabungan</a> ]</td>
      </tr>
    </table>

<? };?>

			<!--end.content-->
			</td>
		 </tr>
		</table>
		</td>
	  </tr>
	  <tr>
        <td width="100%" bgcolor="#004A00" colspan="2"><?php include("footer.php"); ?></td>
	  </tr>
	</table>
    </td>
  </tr>
</table>
</body>
</html>
<?
if ($connDB){ $close = mysql_close($connDB);};
?>