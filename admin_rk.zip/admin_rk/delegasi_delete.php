<?php
// Data Statistik dan Pusat Pelaporan Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id/laporan
// Contact iyok602@yahoo.com, lastupdate 28 Pebruari 2014

//parameter tanggal
if($bln == ""){ $bln = $_POST["bln"]*1; };  if($bln == ""){ $bln = $_GET["bln"]*1; };
if($thn == ""){ $thn = $_POST["thn"]*1; };  if($thn == ""){ $thn = $_GET["thn"]*1; };
if($laporan == ""){ $laporan = $_POST["laporan"]*1; };  if($laporan == ""){ $laporan = $_GET["laporan"]*1; };
if($do == ""){ $do = substr($_POST["do"],0,6); };  if($do == ""){ $do = substr($_GET["do"],0,6); };
if($id == ""){ $id = $_POST["id"]*1; };  if($id == ""){ $id = $_GET["id"]*1; };
//if($kolom_1 == ""){ $kolom_1 = $_POST["kolom_1"]*1; };  if($kolom_1 == ""){ $kolom_1 = $_GET["kolom_1"]*1; };
//if($kolom_3 == ""){ $kolom_3 = substr($_POST["kolom_3"],0,100); };  if($kolom_3 == ""){ $kolom_3 = substr($_GET["kolom_3"],0,100); };
//if($kolom_4 == ""){ $kolom_4 = substr($_POST["kolom_4"],0,100); };  if($kolom_4 == ""){ $kolom_4 = substr($_GET["kolom_4"],0,100); };
//if($kolom_6 == ""){ $kolom_6 = substr($_POST["kolom_6"],0,10); };  if($kolom_6 == ""){ $kolom_6 = substr($_GET["kolom_6"],0,10); };

//set default bulan tahun laporan
if ($bln==""){ 
	$bln = (date('m')-1)*1; $thn = date('Y')*1;
	if (date('d')>=25){ $bln = date('m')*1; }
	if ($bln==0){ $bln=12; $thn=(date('Y')-1)*1; }
};//if
if ($laporan == ""){ $laporan="$thn$bln"; };

//load setting
include_once("include.php");
include("include_login.php");

//post variable
if($run == ""){ $run = $_POST["run"]; };

//data satker
$runSQL = "select * from laporan_satker where id_satker=$SESS_ID_SATKER";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$nm_satker_pjg = $row[nm_satker_pjg];
};//while

//variabel bulan tahun laporan
$bulan_laporan=array(); $value_laporan=array();
for($i=1; $i<=$bln; $i++){
	$nama_bln = $bulan[$i];
	array_push($bulan_laporan, " $nama_bln $thn ");
	array_push($value_laporan, "$thn$i");
};//for

//pilihan bulan tahun laporan
for($i=0; $i<count($bulan_laporan); $i++){
	if ($value_laporan[$i]==$laporan) { $cek="selected"; $bln=substr($laporan,4,2)*1; $thn=substr($laporan,0,4)*1; }else{ unset($cek); }
	$selectlaporan .= "<option value=\"".$value_laporan[$i]."\" $cek> &nbsp; ".$bulan_laporan[$i]." &nbsp; </option>"; 
};//for
$selectlaporan = "<select size=1 name=\"laporan\" onChange=\"runJump(this.value)\" class=\"laporanfree\"> $selectlaporan </select>";

if ($thn==2017){ $tabelDelegasi="laporan_delegasi_2017"; }
else if (($thn==2018)and($bln<=4)){ $tabelDelegasi="laporan_delegasi_201804"; }
else { $tabelDelegasi="laporan_delegasi"; };
//echo "tabel: $thn $bln $tabelDelegasi<br>";

if ($do == "del"){ 
	$runSQL = "select id_satker, tahun, bulan, id_session, lastupdate, kolom_1, kolom_2, kolom_3, kolom_4, date_format(kolom_5,'%d-%m-%Y') kolom_5, kolom_6 as kolom_6sql, date_format(kolom_6,'%d-%m-%Y') kolom_6, date_format(kolom_7,'%d-%m-%Y') kolom_7, date_format(kolom_8,'%d-%m-%Y') kolom_8, date_format(kolom_9,'%d-%m-%Y') kolom_9, kolom_10, kolom_11, kolom_12 from $tabelDelegasi where id_satker=$SESS_ID_SATKER and tahun=$thn and bulan=$bln and id=$id";
	$result = mysql_query($runSQL, $connDB);
    if ($row = mysql_fetch_array ($result)) {
		$kolom_1  = $row["kolom_1"];
		$kolom_2  = $row["kolom_2"];
		$kolom_3  = $row["kolom_3"];
		$kolom_4  = $row["kolom_4"];
		$kolom_5  = $row["kolom_5"];
		$kolom_6sql  = $row["kolom_6sql"];
		$kolom_6  = $row["kolom_6"];
		$kolom_7  = $row["kolom_7"];
		$kolom_8  = $row["kolom_8"];
		$kolom_9  = $row["kolom_9"];
		$kolom_10 = $row["kolom_10"];
		$kolom_11 = $row["kolom_11"];
		$kolom_12 = $row["kolom_12"];
   };//if
};//if-do

//submit form
if (strlen($run) > 1){ 
	$submitValid = 1;
	$kolom_3 = str_replace("'","",$kolom_3);
	$kolom_4 = str_replace("'","",$kolom_4);
	$runSQL = "delete from $tabelDelegasi where id_satker=$SESS_ID_SATKER and tahun=$thn and bulan=$bln and id=$id";
	$result = mysql_query($runSQL, $connDB);
	//echo "$runSQL<br>";
};//end-if-submit

?>
<html>
<head>
  <meta name="Generator" content="EditPlus">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <meta name="Description" content="Data Statistik dan Pusat Pelaporan Perkara">
  <title>Register Delegasi Panggilan <? echo $bulan[($bln*1)]." ".$thn; ?></title>
  <link rel="shortcut icon" href="favicon.ico">
  <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
 <tr>
   <td align="center">
	<table width="980" border="0" cellpadding="0" cellspacing="0">
	</table>
	<table width="980" height="450" border="0" cellpadding="0" cellspacing="0" align="center">
	  <tr><td width="100%" colspan="2"><?php include("header.php"); ?></td></tr>
	  <tr>
        <td width="200" valign="top" bgcolor="#336600"><?php include("menu.php"); ?></td>
        <td width="780" valign="top">
		<table width="100%" height="450" bgcolor="#FFFFFF" border="1" cellpadding="10" cellspacing="0" style="border-collapse:collapse" bordercolor="#003300">
		 <tr>
			<td width="100%" vAlign="top">
			<!--content-->
	
<? if ($submitValid <> 1){?>

    <form method="POST" name="form" ENCTYPE="multipart/form-data" action="<? echo $_SERVER["PHP_SELF"]; ?>">
    <table align="center" border="0" cellpadding="5" cellspacing="1" width="750">
      <tr>
        <td width="100%" colspan="5" align="center">
		<? echo $selectlaporan; ?><br>
		<font color="#0000FF" size="3"><b>Hapus satu Record Delegasi Panggilan <? echo $bulan[($bln*1)]." ".$thn; ?></b></font>
        <br><font color="#0000FF">Register Delegasi Panggilan.
        <hr size="1" color="#003300">
		</td>
      </tr>
    </table>
    <table align="center" border="0" cellpadding="5" cellspacing="1" width="500">
      <tr>
        <td bgcolor='#FF0000' width="100%" colspan="5"><b>Apakah data ini ingin dihapus ?</b></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>2</td>
        <td width="39%" align="left" colspan="2" nowrap>Terima dari Satker</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="55%"><font color='#FF0000'><b><?=htmlentities(stripslashes($kolom_2));?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>3</td>
        <td width="39%" align="left" colspan="2" nowrap>Nomor Perkara</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="55%"><font color='#FF0000'><b><?=htmlentities(stripslashes($kolom_3));?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>4</td>
        <td width="39%" align="left" colspan="2" nowrap>Nama Pihak yg Dipanggil</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="55%"><font color='#FF0000'><b><?=htmlentities(stripslashes($kolom_4));?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>5</td>
        <td width="39%" align="left" colspan="2" nowrap>Tanggal Surat</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="55%"><font color='#FF0000'><b><?=htmlentities(stripslashes($kolom_5));?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>6</td>
        <td width="39%" align="left" colspan="2" nowrap>Tanggal Sidang</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="55%"><font color='#FF0000'><b><?=htmlentities(stripslashes($kolom_6));?></td>
      </tr>
      <tr bgcolor='#FF0000' onmouseover='bgColor="#FF3300"' onmouseout='bgColor="#FF0000"'>
        <td width="100%" height="50" colspan="6" align="center" valign="middle">
        <input type="hidden" name="bln" value="<?=$bln;?>"><input type="hidden" name="thn" value="<?=$thn;?>">
        <input type="hidden" name="id" value="<?=$id;?>">
        <input type="submit" value="    Hapus   " name="run" class="button">
        </td>
      </tr>
	</table>
   </form>
	<script language="Javascript" type="text/javascript">
	function runJump(val) {
	  window.location='<?=$_SERVER["PHP_SELF"];?>?laporan='+val; //make connection
	}
	</script>
	<br><br><br><br><br><br>
	<br><br><br><br><br><br>
	<br><br><br><br><br><br>
	<br><br>

<? }else{?>

    <table align="center" border="0" cellpadding="5" cellspacing="1" width="750">
      <tr>
        <td width="100%" colspan="5" align="center"><font color="#0000FF" size="3"><b>Laporan Pelayanan Terpadu berhasil dihapus</b></font>
        <hr size="1" color="#003300">
		</td>
      </tr>
    </table>
    <table align="center" border="0" cellpadding="20" cellspacing="1" width="500">
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="100%" align="center">
		Laporan Pelayanan Terpadu bulan <?=$bulan[($bln*1)]." ".$thn;?> Satker <?=$nm_satker_pjg;?> berhasil dihapus.
		</td>
      </tr>
    </table>
    <table height="200" align="center" border="0" cellpadding="5" cellspacing="1">
      <tr>
        <td width="100%">[ <a href="delegasi_input.php?laporan=<?=$laporan;?>">Kembali ke Delegasi</a> ]</td>
      </tr>
    </table>
	 <br><br><br><br><br><br>
	<br><br><br><br><br><br>
	<br><br><br><br><br><br>
	<br><br>

<? }; ?>

			<!--end.content-->
			</td>
		 </tr>
		</table>
		</td>
	  </tr>
	  <tr>
        <td width="100%" bgcolor="#004A00" colspan="2"><?php include("footer.php"); ?></td>
	  </tr>
	</table>
    </td>
  </tr>
</table>
</body>
</html>
<?
if ($connDB){ $close = mysql_close($connDB);};
?>