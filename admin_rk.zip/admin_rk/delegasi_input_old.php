<?php
// Data Statistik dan Pusat Pelaporan Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id/laporan
// Contact iyok602@yahoo.com, lastupdate 28 Pebruari 2014

//parameter tanggal
if($bln == ""){ $bln = $_POST["bln"]*1; };  if($bln == ""){ $bln = $_GET["bln"]*1; };
if($thn == ""){ $thn = $_POST["thn"]*1; };  if($thn == ""){ $thn = $_GET["thn"]*1; };
if($laporan == ""){ $laporan = $_POST["laporan"]*1; };  if($laporan == ""){ $laporan = $_GET["laporan"]*1; };
if($do == ""){ $do = substr($_POST["do"],0,6); };  if($do == ""){ $do = substr($_GET["do"],0,6); };
if($id == ""){ $id = $_POST["id"]*1; };  if($id == ""){ $id = $_GET["id"]*1; };
//if($kolom_1 == ""){ $kolom_1 = $_POST["kolom_1"]*1; };  if($kolom_1 == ""){ $kolom_1 = $_GET["kolom_1"]*1; };
//if($kolom_3 == ""){ $kolom_3 = substr($_POST["kolom_3"],0,100); };  if($kolom_3 == ""){ $kolom_3 = substr($_GET["kolom_3"],0,100); };
//if($kolom_4 == ""){ $kolom_4 = substr($_POST["kolom_4"],0,100); };  if($kolom_4 == ""){ $kolom_4 = substr($_GET["kolom_4"],0,100); };
//if($kolom_6 == ""){ $kolom_6 = substr($_POST["kolom_6"],0,10); };  if($kolom_6 == ""){ $kolom_6 = substr($_GET["kolom_6"],0,10); };

//set default bulan tahun laporan
if ($bln==""){ 
	$bln = (date('m'))*1; $thn = date('Y')*1;
	if (date('d')>=25){ $bln = date('m')*1; }
	if ($bln==0){ $bln=12; $thn=(date('Y')-1)*1; }
};//if
if ($laporan == ""){ $laporan="$thn$bln"; };

//load setting
include_once("include.php");
include("include_login.php");

//post variable
if($run == ""){ $run = $_POST["run"]; };
if($kolom_1 == ""){ $kolom_1  = $_POST["kolom_1"]*1; };
if($kolom_2 == ""){ $kolom_2  = strtoupper(substr($_POST["kolom_2"],0,100)); };
if($kolom_3 == ""){ $kolom_3  = strtoupper(substr($_POST["kolom_3"],0,100)); };
if($kolom_4 == ""){ $kolom_4  = strtoupper(substr($_POST["kolom_4"],0,100)); };
if($kolom_5 == ""){ $kolom_5  = substr($_POST["kolom_5"],0,10); };
if($kolom_6 == ""){ $kolom_6  = substr($_POST["kolom_6"],0,10); };
if($kolom_7 == ""){ $kolom_7  = substr($_POST["kolom_7"],0,10); };
if($kolom_8 == ""){ $kolom_8  = substr($_POST["kolom_8"],0,10); };
if($kolom_9 == ""){ $kolom_9  = substr($_POST["kolom_9"],0,10); };
if($kolom_10 == ""){ $kolom_10 = strtoupper(substr($_POST["kolom_10"],0,100)); };
if($kolom_11 == ""){ $kolom_11 = substr($_POST["kolom_11"],0,100); };
if($kolom_12 == ""){ $kolom_12  = $_POST["kolom_12"]*1; };
$tombol = "Tambah";

//data satker
$runSQL = "select * from laporan_satker where id_satker=$SESS_ID_SATKER";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$nm_satker_pjg = $row[nm_satker_pjg];
};//while

//variabel bulan tahun laporan
$bulan_laporan=array(); $value_laporan=array();
for($i=1; $i<=12; $i++){
	$nama_bln = $bulan[$i];
	array_push($bulan_laporan, " $nama_bln 2015 ");
	array_push($value_laporan, "2015$i");
};//for
for($i=1; $i<=$bln; $i++){
	$nama_bln = $bulan[$i];
	array_push($bulan_laporan, " $nama_bln $thn ");
	array_push($value_laporan, "$thn$i");
};//for

//pilihan bulan tahun laporan
for($i=0; $i<count($bulan_laporan); $i++){
	if ($value_laporan[$i]==$laporan) { $cek="selected"; $bln=substr($laporan,4,2)*1; $thn=substr($laporan,0,4)*1; }else{ unset($cek); }
	$selectlaporan .= "<option value=\"".$value_laporan[$i]."\" $cek> &nbsp; ".$bulan_laporan[$i]." &nbsp; </option>"; 
};//for
$selectlaporan = "<select size=1 name=\"laporan\" onChange=\"runJump(this.value)\" class=\"laporanfree\"> $selectlaporan </select>";

if ($do == "edit"){ 
	$runSQL = "select id_satker, tahun, bulan, id_session, lastupdate, kolom_1, kolom_2, kolom_3, kolom_4, date_format(kolom_5,'%d-%m-%Y') kolom_5, date_format(kolom_6,'%d-%m-%Y') kolom_6, date_format(kolom_7,'%d-%m-%Y') kolom_7, date_format(kolom_8,'%d-%m-%Y') kolom_8, date_format(kolom_9,'%d-%m-%Y') kolom_9, kolom_10, kolom_11, kolom_12 from laporan_delegasi where id_satker=$SESS_ID_SATKER and id=$id";
	$result = mysql_query($runSQL, $connDB);
    if ($row = mysql_fetch_array ($result)) {
		$kolom_1  = $row["kolom_1"];
		$kolom_2  = $row["kolom_2"];
		$kolom_3  = $row["kolom_3"];
		$kolom_4  = $row["kolom_4"];
		$kolom_5  = $row["kolom_5"];
		$kolom_6  = $row["kolom_6"];
		$kolom_7  = $row["kolom_7"];
		$kolom_8  = $row["kolom_8"];
		$kolom_9  = $row["kolom_9"];
		$kolom_10 = $row["kolom_10"];
		$kolom_11 = $row["kolom_11"];
		$kolom_12 = $row["kolom_12"];
   };//if
	$tombol = "Edit";
	//echo "$runSQL<br>";
};//if-do

//submit form
if (strlen($run) > 1){ 
	$kolom_2 = strtoupper(str_replace("'","",$kolom_2));
	$kolom_3 = strtoupper(str_replace("'","",$kolom_3));
	$kolom_4 = strtoupper(str_replace("'","",$kolom_4));
	$kolom_10 = strtoupper(str_replace("'","",$kolom_10));
	$kolom_11 = str_replace("'","",$kolom_11);

	if ($kolom_5<>""){ $kolom_5=substr($kolom_5,-4)."-".substr($kolom_5,3,2)."-".substr($kolom_5,0,2); };
	if ($kolom_6<>""){ $kolom_6=substr($kolom_6,-4)."-".substr($kolom_6,3,2)."-".substr($kolom_6,0,2); };
	if ($kolom_7<>""){ $kolom_7=substr($kolom_7,-4)."-".substr($kolom_7,3,2)."-".substr($kolom_7,0,2); };
	if ($kolom_8<>""){ $kolom_8=substr($kolom_8,-4)."-".substr($kolom_8,3,2)."-".substr($kolom_8,0,2); };
	if ($kolom_9<>""){ $kolom_9=substr($kolom_9,-4)."-".substr($kolom_9,3,2)."-".substr($kolom_9,0,2); };

	//$runSQL = "select * from laporan_delegasi where id_satker=$SESS_ID_SATKER and tahun=$thn and bulan=$bln and kolom_1='$kolom_1' and kolom_3='$kolom_3' and kolom_4='$kolom_4' and kolom_6='$kolom_6'";
	//$result = mysql_query($runSQL, $connDB);
	if ($id > 0) {
		$submitValid = 1;
		$runSQL = "update laporan_delegasi set id_session='$SESSION_ID', lastupdate=now(), kolom_1='$kolom_1', kolom_2='$kolom_2', kolom_3='$kolom_3', kolom_4='$kolom_4', kolom_5='$kolom_5', kolom_6='$kolom_6', kolom_7='$kolom_7', kolom_8='$kolom_8', kolom_9='$kolom_9', kolom_10='$kolom_10', kolom_11='$kolom_11', kolom_12='$kolom_12' where id_satker=$SESS_ID_SATKER and id=$id";
		$update = mysql_query($runSQL, $connDB);
	} else {
		$submitValid = 1;
		$runSQL = "insert into laporan_delegasi (id_satker, tahun, bulan, id_session, lastupdate, kolom_1, kolom_2, kolom_3, kolom_4, kolom_5, kolom_6, kolom_7, kolom_8, kolom_9, kolom_10, kolom_11, kolom_12) VALUES ('$SESS_ID_SATKER', '$thn', '$bln', '$SESSION_ID', now(), '$kolom_1', '$kolom_2', '$kolom_3', '$kolom_4', '$kolom_5', '$kolom_6', '$kolom_7', '$kolom_8', '$kolom_9', '$kolom_10', '$kolom_11', '$kolom_12')";
		$insert = mysql_query($runSQL, $connDB);
	};//if
	//echo "$runSQL<br>";
};//end-if-submit

?>
<html>
<head>
  <meta name="Generator" content="EditPlus">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <meta name="Description" content="Data Statistik dan Pusat Pelaporan Perkara">
  <title>Register Delegasi Panggilan <? echo $bulan[($bln*1)]." ".$thn; ?></title>
  <link rel="shortcut icon" href="favicon.ico">
  <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
 <tr>
   <td align="center">
	<table width="980" border="0" cellpadding="0" cellspacing="0">
	</table>
	<table width="980" height="450" border="0" cellpadding="0" cellspacing="0" align="center">
	  <tr><td width="100%" colspan="2"><?php include("header.php"); ?></td></tr>
	  <tr>
        <td width="200" valign="top" bgcolor="#336600"><?php include("menu.php"); ?></td>
        <td width="780" valign="top">
		<table width="100%" height="450" bgcolor="#FFFFFF" border="1" cellpadding="10" cellspacing="0" style="border-collapse:collapse" bordercolor="#003300">
		 <tr>
			<td width="100%" vAlign="top">
			<!--content-->
	
<? if ($submitValid <> 1){?>

	<script src="lib/jquery.min.js"></script>
	<script src="lib/zebra_datepicker.js"></script>
	<link rel="stylesheet" href="lib/css/default.css" />
    <form method="POST" name="form" ENCTYPE="multipart/form-data" action="<? echo $_SERVER["PHP_SELF"]; ?>">
    <table align="center" border="0" cellpadding="5" cellspacing="1" width="750">
      <tr>
        <td width="100%" colspan="5" align="center">
		  <? echo $selectlaporan; ?><br>
		  <font color="#0000FF" size="3"><b>Pengisian Register Delegasi <? echo $bulan[($bln*1)]." ".$thn; ?></b></font>
        <br><font color="#0000FF">Register Delegasi Panggilan.
        <hr size="1" color="#003300">
		</td>
      </tr>
    </table>
    <table align="center" border="0" cellpadding="5" cellspacing="1" width="500">
      <tr>
        <td bgcolor='#339900' width="100%" colspan="5"><b>Register Delegasi Panggilan bulan <? echo $bulan[($bln*1)]." ".$thn; ?></b></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>2</td>
        <td width="39%" align="left" colspan="2" nowrap>Terima dari Satker</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="55%"><input type="text" name="kolom_2" size="20" value="<?=htmlentities(stripslashes($kolom_2));?>"><? echo $ikolom_2; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>3</td>
        <td width="39%" align="left" colspan="2" nowrap>Nomor Perkara</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="55%"><input type="text" name="kolom_3" size="15" value="<?=htmlentities(stripslashes($kolom_3));?>"><? echo $ikolom_3; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>4</td>
        <td width="39%" align="left" colspan="2" nowrap>Nama Pihak yg Dipanggil</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="55%"><input type="text" name="kolom_4" size="35" value="<?=htmlentities(stripslashes($kolom_4));?>"><? echo $ikolom_4; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>5</td>
        <td width="39%" align="left" colspan="2" nowrap>Tanggal Surat</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="55%">
			<script>
				 $(document).ready(function(){
					  $('#kolom_5').Zebra_DatePicker({
							format: 'd-m-Y'
					  });
				 });
			</script>
			<input type="text" size="12" name="kolom_5" id="kolom_5" value="<?=$kolom_5;?>">
		  </td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>6</td>
        <td width="39%" align="left" colspan="2" nowrap>Tanggal Sidang</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="55%">
			<script>
				 $(document).ready(function(){
					  $('#kolom_6').Zebra_DatePicker({
							format: 'd-m-Y'
					  });
				 });
			</script>
			<input type="text" size="12" name="kolom_6" id="kolom_6" value="<?=$kolom_6;?>">
		  </td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>7</td>
        <td width="39%" align="left" colspan="2" nowrap>Tanggal Terima Surat</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="55%">
			<script>
				 $(document).ready(function(){
					  $('#kolom_7').Zebra_DatePicker({
							format: 'd-m-Y'
					  });
				 });
			</script>
			<input type="text" size="12" name="kolom_7" id="kolom_7" value="<?=$kolom_7;?>">
		  </td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="5%" align="center" nowrap>8</td>
        <td width="39%" align="left" colspan="2" nowrap>Tanggal Pelaksanaan</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="55%">
			<script>
				 $(document).ready(function(){
					  $('#kolom_8').Zebra_DatePicker({
							format: 'd-m-Y'
					  });
				 });
			</script>
			<input type="text" size="12" name="kolom_8" id="kolom_8" value="<?=$kolom_8;?>">
		  </td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>9</td>
        <td width="39%" align="left" colspan="2" nowrap>Tanggal Kirim Kembali</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="55%">
			<script>
				 $(document).ready(function(){
					  $('#kolom_9').Zebra_DatePicker({
							format: 'd-m-Y'
					  });
				 });
			</script>
			<input type="text" size="12" name="kolom_9" id="kolom_9" value="<?=$kolom_9;?>">
		  </td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>10</td>
        <td width="39%" align="left" colspan="2">Nama Jurusita/JSP</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="55%"><input type="text" name="kolom_10" size="30" value="<?=htmlentities(stripslashes($kolom_10));?>"><? echo $ikolom_10; ?></td>
      </tr>
      <tr bgcolor='#EEFBE1' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#EEFBE1"'>
        <td width="5%" align="center" nowrap>11</td>
        <td width="39%" align="left" colspan="2">Keterangan</td>
        <td width="1%" align="center" nowrap>:</td>
        <td width="55%"><input type="text" name="kolom_11" size="40" value="<?=htmlentities(stripslashes($kolom_11));?>"><? echo $ikolom_11; ?></td>
      </tr>
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="100%" height="50" colspan="6" align="center" valign="middle">
        <input type="hidden" name="id" value="<?=$id;?>"><input type="hidden" name="bln" value="<?=$bln;?>"><input type="hidden" name="thn" value="<?=$thn;?>">
        <input type="submit" value="    <?=$tombol;?>   " name="run" class="button">
        </td>
      </tr>
	</table>
    </form>
	<script language="Javascript" type="text/javascript">
	function runJump(val) {
	  window.location='<?=$_SERVER["PHP_SELF"];?>?laporan='+val; //make connection
	}
	</script>

<? }else{?>

    <table align="center" border="0" cellpadding="5" cellspacing="1" width="750">
      <tr>
        <td width="100%" colspan="5" align="center"><font color="#0000FF" size="3"><b>Laporan Pelayanan Terpadu berhasil disimpan</b></font>
        <hr size="1" color="#003300">
		</td>
      </tr>
    </table>
    <table align="center" border="0" cellpadding="20" cellspacing="1" width="500">
      <tr bgcolor='#CCFA9A' onmouseover='bgColor="#ABE159"' onmouseout='bgColor="#CCFA9A"'>
        <td width="100%" align="center">
		Penambahan data pada Register Delegasi bulan <?=$bulan[($bln*1)]." ".$thn;?> Satker <?=$nm_satker_pjg;?> berhasil disimpan.
		</td>
      </tr>
    </table>
    <table height="200" align="center" border="0" cellpadding="5" cellspacing="1">
      <tr>
        <td width="100%">[ <a href="delegasi_input.php?laporan=<?=$laporan;?>">Input Lagi</a> ]</td>
      </tr>
    </table>

<? }; ?>

	 <table align="center" border="0" cellpadding="5" cellspacing="1" width="500">
      <tr bgcolor='#339900'>
        <td width="5%" align="center"><font size='1'>No</td>
        <td width="5%" align="center"><font size='1'>Terima dari Satker</td>
        <td width="5%" align="center"><font size='1'>Nomor Perkara</td>
        <td width="5%" align="center"><font size='1'>Nama Pihak yg Dipanggil</td>
        <td width="5%" align="center"><font size='1'>Tanggal Surat</td>
        <td width="5%" align="center"><font size='1'>Tanggal Sidang</td>
        <td width="5%" align="center"><font size='1'>Tanggal Terima Surat</td>
        <td width="5%" align="center"><font size='1'>Tanggal Pelaksanaan</td>
        <td width="5%" align="center"><font size='1'>Tanggal Kirim Kembali</td>
        <td width="5%" align="center"><font size='1'>Nama Jurusita/JSP</td>
        <td width="5%" align="center"><font size='1'>Keterangan</td>
        <td width="5%" rowspan="2" align="center"></td>
      </tr>
      <tr bgcolor='#339900'>
        <td width="5%" align="center"><font size='1'>1</td>
        <td width="5%" align="center"><font size='1'>2</td>
        <td width="5%" align="center"><font size='1'>3</td>
        <td width="5%" align="center"><font size='1'>4</td>
        <td width="5%" align="center"><font size='1'>5</td>
        <td width="5%" align="center"><font size='1'>6</td>
        <td width="5%" align="center"><font size='1'>7</td>
        <td width="5%" align="center"><font size='1'>8</td>
        <td width="5%" align="center"><font size='1'>9</td>
        <td width="5%" align="center"><font size='1'>10</td>
        <td width="5%" align="center"><font size='1'>11</td>
      </tr>
		<?
			$i=0;
			$runSQL = "select id_satker, tahun, bulan, id_session, lastupdate, kolom_1, kolom_2, kolom_3, kolom_4, date_format(kolom_5,'%d-%m-%Y') kolom_5, kolom_6 as kolom_6sql, date_format(kolom_6,'%d-%m-%Y') kolom_6, kolom_7 as kolom_7srt, date_format(kolom_7,'%d-%m-%Y') kolom_7, date_format(kolom_8,'%d-%m-%Y') kolom_8, date_format(kolom_9,'%d-%m-%Y') kolom_9, kolom_10, kolom_11, kolom_12, id from laporan_delegasi where id_satker=$SESS_ID_SATKER and tahun=$thn and bulan=$bln order by kolom_7srt asc";
			$result = mysql_query($runSQL, $connDB);
			while ($row = mysql_fetch_array ($result)) {
				$idrow = "?thn=".$row["tahun"]."&bln=".$row["bulan"]."&id=".$row["id"];
				$i++;
				if ($i%2 > 0){ $color="#CCFA9A"; }else{ $color="#EEFBE1"; };
				$htmlData .= "<tr bgcolor='$color' onmouseover='bgColor=\"#ABE159\"' onmouseout='bgColor=\"$color\"'>";
				$htmlData .= "<td align='center'><font size='1'>".$i."</td>";
				$htmlData .= "<td align='center'><font size='1'>".$row["kolom_2"]."</td>";
				$htmlData .= "<td align='center'><font size='1'>".$row["kolom_3"]."</td>";
				$htmlData .= "<td align='center'><font size='1'>".$row["kolom_4"]."</td>";
				$htmlData .= "<td align='center'><font size='1'>".$row["kolom_5"]."</td>";
				$htmlData .= "<td align='center'><font size='1'>".$row["kolom_6"]."</td>";
				$htmlData .= "<td align='center'><font size='1'>".$row["kolom_7"]."</td>";
				$htmlData .= "<td align='center'><font size='1'>".$row["kolom_8"]."</td>";
				$htmlData .= "<td align='center'><font size='1'>".$row["kolom_9"]."</td>";
				$htmlData .= "<td align='center'><font size='1'>".$row["kolom_10"]."</td>";
				$htmlData .= "<td align='center'><font size='1'>".$row["kolom_11"]."</td>";
				$htmlData .= "<td align='center'><font size='1'>[<a href='".$_SERVER["PHP_SELF"].$idrow."&do=edit'>edit</a>] [<a href='delegasi_delete.php".$idrow."&do=del'>del</a>]</td>";
				$htmlData .= "</tr>";
			};//while
			echo $htmlData;
		?>
		</table>
			
			<p><center><a href="download.php?<?="bln=$bln&thn=$thn&id_satker=$SESS_ID_SATKER";?>"><img src="img/csv.jpg" height='35'></a></center></p>
			<!--end.content-->
			</td>
		 </tr>
		</table>
		</td>
	  </tr>
	  <tr>
        <td width="100%" bgcolor="#004A00" colspan="2"><?php include("footer.php"); ?></td>
	  </tr>
	</table>
    </td>
  </tr>
</table>
</body>
</html>
<?
if ($connDB){ $close = mysql_close($connDB);};
?>