<table width="100%" height="100%" border="0" cellpadding="3" cellspacing="0">
  <tr>
	<td align="right">
	<font color="#00CC00" size="1"><b>Pengadilan Tinggi Agama Surabaya</b>,
	<font color="#00CC00" size="1">Jl. Mayjen Sungkono No.7 Surabaya
	</td>
  </tr>
</table>