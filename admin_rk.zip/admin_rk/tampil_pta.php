<?php
// Data Statistik dan Pusat Pelaporan Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id/laporan
// Contact iyok642@yahoo.com, lastupdate 28 Pebruari 2014

//parameter tanggal
$bln = $_POST["bln"]*1; if($bln==""){ $bln = $_GET["bln"]*1; };
$thn = $_POST["thn"]*1; if($thn==""){ $thn = $_GET["thn"]*1; };
$view = $_POST["view"];  if($view==""){ $view = $_GET["view"]; };
$laporan = $_POST["laporan"]*1;  if($laporan==""){ $laporan = $_GET["laporan"]*1; };

if (($bln=="") and ($thn=="") and ($laporan <> "")){ $bln=substr($laporan,4,2)*1; $thn=substr($laporan,0,4)*1; }

//set default bulan tahun laporan
if ($bln==""){ 
	$bln = (date('m')-1)*1; $thn = date('Y')*1;
	if (date('d')>=25){ $bln = date('m')*1; }
	if ($bln==0){ $bln=12; $thn=(date('Y')-1)*1; }
};//if
if ($laporan == ""){ $laporan="$thn$bln"; };

//load setting
include_once("include.php");
include("include_login.php");

//default id_parent
$id_parent = 12;
$runSQL = "select * from laporan_satker where id_satker='$SESS_ID_SATKER'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array ($result)) { 
	if ($row[tk_satker]=="PA"){ $id_parent=$row[id_parent]; };
	if ($row[tk_satker]=="PTA"){ $id_parent=$row[id_satker]; };
};//while

//data satker
$runSQL = "select * from laporan_satker where id_satker=$id_parent";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$nm_satker_pjg = $row[nm_satker_pjg];
};//while

//pilihan bulan tahun laporan
unset($selectbulan);
for($i=1; $i<=12; $i++){
	if ($i==($bln*1)) { $cek="selected"; }else{ unset($cek); }
	$selectbulan .= "<option value=\"".$i."$parser\" $cek> &nbsp; ".$bulan[$i]." &nbsp; </option>"; 
};//for
$selectbulan = "<select size=1 name=\"bln\" onChange=\"runJump(this.value)\" class=\"laporanfree\"> $selectbulan </select>";

unset($selecttahun);
for($i=2014; $i<=date('Y'); $i++){
	if ($i==($thn*1)) { $cek="selected"; }else{ unset($cek); }
	$selecttahun .= "<option value=\"".$i.$bln."$parser\" $cek> &nbsp; ".$i." &nbsp; </option>"; 
};//for
$selecttahun = "<select size=1 name=\"thn\" onChange=\"runJump3(this.value)\" class=\"laporanfree\"> $selecttahun </select>";

$view_laporan = array("RK.1", "RK.2", "RK.3", "RK.4", "RK.5", "RK.6", "RK.7a", "RK.7b", "RK.7c", "RK.8a", "RK.8b", "RK.8c", "RK.9", "RK.10", "RK.11a", "RK.11b", "RK.12", "RK.MA", "RK.ESYARIAH", "Pelayanan Terpadu");
for($i=0; $i<count($view_laporan); $i++){
	if ($htmlview <> ""){ $space = "|"; };
	if ($i%12 == 0){ $space="<br>"; };
	$htmlview .= " $space <a href=\"?view=".$view_laporan[$i]."&laporan=".$laporan."\"><b>".$view_laporan[$i]."</b></a>";

	$selectdownload .= "<option value=\"".$view_laporan[$i]."&laporan=$laporan\"> &nbsp; ".$view_laporan[$i]." &nbsp; </option>"; 
};//for

$title="<b>RK.3 Laporan Perkara yang Diterima"; 
if ($view == "RK.1"){ $title="<b>RK.1 Laporan Perkara Banding yang Diterima"; }
if ($view == "RK.2"){ $title="<b>RK.2 Laporan Perkara Banding yang Diputus"; }
if ($view == "RK.3"){ $title="<b>RK.3 Laporan Perkara yang Diterima"; }
if ($view == "RK.4"){ $title="<b>RK.4 Laporan Perkara yang Diputus"; }
if ($view == "RK.5"){ $title="<b>RK.5 Faktor-faktor penyebab terjadinya perceraian"; }
if ($view == "RK.6"){ $title="<b>RK.6 PP No.10 Tahun 1983 jo. PP No.45 Tahun 1990"; }
if ($view == "RK.7a"){ $title="<b>RK.7a Rekapitulasi Keuangan Perkara"; }
if ($view == "RK.7b"){ $title="<b>RK.7b Rekapitulasi Keuangan Perkara Eksekusi"; }
if ($view == "RK.7c"){ $title="<b>RK.7c Rekapitulasi Keuangan Perkara Konsinyasi"; }
if ($view == "RK.8a"){ $title="<b>RK.8a Pelaksanaan Sidang Keliling"; }
if ($view == "RK.8b"){ $title="<b>RK.8b Pelaksanaan Prodeo"; }
if ($view == "RK.8c"){ $title="<b>RK.8c Pelaksanaan Posbakum"; }
if ($view == "RK.9"){ $title="<b>RK.9 Rekap Perkara Banding, Kasasi, PK, Eksekusi"; }
if ($view == "RK.10"){ $title="<b>RK.10 Rekapitulasi Mediasi"; }
if ($view == "RK.11a"){ $title="<b>RK.11a Hak Kepaniteraan"; }
if ($view == "RK.11b"){ $title="<b>RK.11b Hak Kepaniteraan Lainnya"; }
if ($view == "RK.12"){ $title="<b>RK.12 Tingkat Penyelesaian Perkara"; }
if ($view == "RK.MA"){ $title="<b>RK.MA Rekapitulasi Perkara Diterima Diputus"; }
if ($view == "RK.ESYARIAH"){ $title="<b>RK.ESyariah Laporan Ekonomi Syariah"; }
if ($view == "Pelayanan Terpadu"){ $title="<b>Laporan Pelayanan Terpadu"; }
if ($view == "Register Delegasi"){ $title="<b>Register Delegasi Panggilan/Pemberitahuan"; }

?>
<html>
<head>
  <meta name="Generator" content="EditPlus">
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <meta name="Description" content="Sistem Pendaftaran Perkara Secara Online Pengadilan Agama">
  <title>Laporan Perkara <? echo $bulan[($bln*1)]." ".$thn; ?></title>
  <link rel="shortcut icon" href="favicon.ico">
  <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
 <tr>
   <td align="center">
	<table width="980" border="0" cellpadding="0" cellspacing="0">
	</table>
	<table width="980" height="450" border="0" cellpadding="0" cellspacing="0" align="center">
	  <tr><td width="100%" colspan="2"><?php include("header.php"); ?></td></tr>
	  <tr>
        <td width="200" valign="top" bgcolor="#336600"><?php include("menu.php"); ?></td>
        <td width="780" valign="top">
		<table width="100%" height="450" bgcolor="#FFFFFF" border="1" cellpadding="10" cellspacing="0" style="border-collapse:collapse" bordercolor="#003300">
		 <tr>
			<td width="100%" vAlign="top">
			<!--content-->
	
			<table align="center" border="0" cellpadding="0" cellspacing="0" width="750">
			  <tr>
			    <td width="100%" colspan="5" align="center">
				<? echo $selectbulan.' '.$selecttahun; ?><br>
			   <br><font color="#0000FF" size="3"><b>Laporan <?=$title."<br>".$nm_satker_pjg?><br>Bulan <?=$bulan[($bln*1)]." Tahun ".$thn;?></b></font></b>
				<br><br>
				Untuk keperluan hardcopy (<b>cetak laporan PTA</b>) download file berikut :<br>
				<table align="center" border="0" cellpadding="1" cellspacing="5">
				  <tr>
				    <td align="center" valign="top"><a href="download_pta.php?<?="bln=$bln&thn=$thn";?>"><img src="img/csv.jpg" height='35'></a><br><a href="download_pta.php?<?="bln=$bln&thn=$thn";?>"><font size="1" color="#009900"><b>RK<br><?=$bulan[($bln*1)]."<br>".$thn;?></a></td>
					<? if ($SESS_ID_SATKER=="12"){ ?>
					<td align="center">&nbsp;</td>
				    <td align="center" valign="top"><a href="download_delegasi_pta.php?<?="bln=$bln&thn=$thn";?>"><img src="img/csv.jpg" height='35'></a><br><a href="download_delegasi_pta.php?<?="bln=$bln&thn=$thn";?>"><font size="1" color="#009900"><b>Delegasi<br><?=$bulan[($bln*1)]."<br>".$thn;?></a></td>
					<td align="center">&nbsp;</td>
				    <td align="center" valign="top"><a href="download_delegasi_keluar_pta.php?<?="bln=$bln&thn=$thn";?>"><img src="img/csv.jpg" height='35'></a><br><a href="download_delegasi_keluar_pta.php?<?="bln=$bln&thn=$thn";?>"><font size="1" color="#009900"><b>Delegasi Keluar<br><?=$bulan[($bln*1)]."<br>".$thn;?></a></td>
					<td align="center">&nbsp;</td>
				    <td align="center" valign="top">
					<select size=1 name="download_pta" onChange="runJump2(this.value)" class="laporanfree">
					   <option value="" selected> -- Pilih RK -- </option>
					   <?=$selectdownload;?>
					</select>
					<!--<a href="download_setahun.php?<?="bln=$bln&thn=$thn";?>">--><br><font size="1" color="#009900"><b>(rekap semua bulan)</td>
					<? }; ?>
				  </tr>
				</table>
				<?=$htmlview;?>
			    </td>
			  </tr>
			</table>
		    <iframe name="news_view" border="0" src="rk_rekap_pta.php?<?="view=$view&bln=$bln&thn=$thn";?>" width="100%" height="1060" style="border:none"></iframe>

			<!--end.content-->
			</td>
		 </tr>
		</table>
		</td>
	  </tr>
	  <tr>
        <td width="100%" bgcolor="#004A00" colspan="2"><?php include("footer.php"); ?></td>
	  </tr>
	</table>
    </td>
  </tr>
</table>
<script language="Javascript" type="text/javascript">
	function runJump(val) {
	  window.location='<?=$_SERVER["PHP_SELF"];?>?laporan=<?=$thn?>'+val; //make connection
	}
	function runJump2(val) {
	  window.location='download_setahun.php?view='+val; //make connection
	}
	function runJump3(val) {
	  window.location='<?=$_SERVER["PHP_SELF"];?>?laporan='+val; //make connection
	}
</script>
</body>
</html>
<?
if ($connDB){ $close = mysql_close($connDB);};
?>