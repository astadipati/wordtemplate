<?
header("location:http://www.pta-surabaya.go.id/?");
?>