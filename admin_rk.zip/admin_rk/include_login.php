<?php
session_start();
$SESSION_ID = session_id();

$runSQL = "select id_satker, name_user, (unix_timestamp(now())-unix_timestamp(created)) waktu from sys_session where session_id='$SESSION_ID'";
$result = mysql_query($runSQL, $connDB);
if ($row = mysql_fetch_array($result)) {
  $SESS_ID_SATKER = $row[id_satker];
  $SESS_NM_USER = $row[name_user];
  
  if ($row[waktu] > 28800){ //7200*4=28800 (4jam)
	  mysql_query("delete from sys_session where (unix_timestamp(now())-unix_timestamp(created)) > 28800"); //4 hours
	  mysql_query("optimize table sys_session");
	  mysql_close($connDB);
	  header("location:admin_login.php"); 
  };//if

}else {

  mysql_close($connDB);
  header("location:admin_login.php"); 

};//if
?>