<?php
// Data Statistik dan Pusat Pelaporan Perkara
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id
// Contact iyok642@yahoo.com, lastupdate 28 Pebruari 2014

@set_time_limit(3600);
@ini_set('memory_limit','1024M');

//parameter tanggal
$bln = $_POST["bln"]*1; if($bln==""){ $bln = $_GET["bln"]*1; }
$thn = $_POST["thn"]*1; if($thn==""){ $thn = $_GET["thn"]*1; };
$id_satker = $_POST["id_satker"]*1; if($id_satker==""){ $id_satker = $_GET["id_satker"]*1; };

//set default bulan tahun laporan
if ($bln==""){ 
	$bln = (date('m')-1)*1; $thn = date('Y')*1;
	if (date('d')>=25){ $bln = date('m')*1; }
	if ($bln==0){ $bln=12; $thn=(date('Y')-1)*1; }
};//if

$lastday = date ("t", mktime(0,0,0,$bln,1,$thn));
$numbday = date ("N", mktime(0,0,0,$bln,$lastday,$thn));
if ($numbday > 5){ $lastday = $lastday-($numbday-5); }

//load setting
include_once("include.php");
include("include_login.php");

//satker user akses
$view_this_satker=$SESS_ID_SATKER;
$runSQL = "select * from laporan_satker where id_satker='$SESS_ID_SATKER'";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	if (($row[tk_satker]=="PTA")or($row[tk_satker]=="BADILAG")){ $view_this_satker=$id_satker; }
};//while

//profile satker
$runSQL = "select * from laporan_satker where id_satker='$view_this_satker'";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) { 
	$kode_perkara = $row[kode_perkara];
	$nama_satker = $row[nm_satker_pjg];
	$alamat_satker = $row[almt_satker];
	$website_email = "Website: ".$row[url_satker]." Email: ".$row[email_satker];
	$nama_ketua = $row[nama_ketua];
	$nama_pansek = $row[nama_pansek];
	$nama_kota = $row[nama_kota];
};//while



/**
 * PHPExcel
 *
 * Copyright (C) 2006 - 2013 PHPExcel
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * @category   PHPExcel
 * @package    PHPExcel
 * @copyright  Copyright (c) 2006 - 2013 PHPExcel (http://www.codeplex.com/PHPExcel)
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt	LGPL
 * @version    1.7.9, 2013-06-02
 */

/** Error reporting */
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
date_default_timezone_set('Europe/London');

if (PHP_SAPI == 'cli')
	die('This example should only be run from a Web Browser');

/** Include PHPExcel */
require_once 'excell/PHPExcel.php';

if ($thn >= 2017){
  $fileTemplate = "master_rk_pa_allbulan2017.xls";
} else {
  $fileTemplate = "master_rk_pa_allbulan.xls";
};//if
$fileDownload = "RK_".strtoupper($kode_perkara)."_Januari-".$bulan[($bln*1)]."_".$thn.".xls";

// Create new PHPExcel object
//$objPHPExcel = new PHPExcel();

// Read the file
$objReader = PHPExcel_IOFactory::createReader('Excel5');
$objPHPExcel = $objReader->load($fileTemplate);


// Set document properties
$objPHPExcel->getProperties()->setCreator("iyok642")
							 ->setLastModifiedBy("pta-surabaya.go.id")
							 ->setTitle("Laporan Perkara Pengadilan Agama")
							 ->setSubject("Laporan Perkara Pengadilan Agama")
							 ->setDescription("Pusat Pelaporan Data Perkara SiADPA & SiADPTA Online")
							 ->setKeywords("Pusat Pelaporan Data Perkara SiADPA & SiADPTA Online")
							 ->setCategory("Pusat Pelaporan Data Perkara SiADPA & SiADPTA Online");

// Add some data
$objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A2", strtoupper($nama_satker))
            ->setCellValue("A3", "BULAN JANUARI s/d ".strtoupper($bulan[($bln*1)])." TAHUN ".$thn)
            ->setCellValue("B23", "Ketua ".$nama_satker)
            ->setCellValue("B28", $nama_ketua)
            ->setCellValue("Y22", $nama_kota.", ".$lastday." ".$bulan[($bln*1)]." ".$thn)
            ->setCellValue("Y28", $nama_pansek);
			
//laporan rk.3
$runSQL = "select * from laporan_rk3 where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 7 + $row["bulan"];
	
    $objPHPExcel->setActiveSheetIndex(0)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_5"])
            ->setCellValue("F".$cc, $row["kolom_6"])
            ->setCellValue("G".$cc, $row["kolom_7"])
            ->setCellValue("H".$cc, $row["kolom_8"])
            ->setCellValue("I".$cc, $row["kolom_9"])
            ->setCellValue("J".$cc, $row["kolom_10"])
            ->setCellValue("K".$cc, $row["kolom_11"])
            ->setCellValue("L".$cc, $row["kolom_12"])
            ->setCellValue("M".$cc, $row["kolom_13"])
            ->setCellValue("N".$cc, $row["kolom_14"])
            ->setCellValue("O".$cc, $row["kolom_15"])
            ->setCellValue("P".$cc, $row["kolom_16"])
            ->setCellValue("Q".$cc, $row["kolom_17"])
            ->setCellValue("R".$cc, $row["kolom_18"])
            ->setCellValue("S".$cc, $row["kolom_19"])
            ->setCellValue("T".$cc, $row["kolom_20"])
            ->setCellValue("U".$cc, $row["kolom_21"])
            ->setCellValue("V".$cc, $row["kolom_22"])
            ->setCellValue("W".$cc, $row["kolom_23"])
            ->setCellValue("X".$cc, $row["kolom_24"])
            ->setCellValue("Y".$cc, $row["kolom_25"])
            ->setCellValue("Z".$cc, $row["kolom_26"])
            ->setCellValue("AA".$cc, $row["kolom_27"])
            ->setCellValue("AB".$cc, $row["kolom_28"])
            ->setCellValue("AC".$cc, $row["kolom_29"])
            ->setCellValue("AD".$cc, $row["kolom_30"])
            ->setCellValue("AE".$cc, $row["kolom_31"])
            ->setCellValue("AF".$cc, $row["kolom_32"])
            ->setCellValue("AG".$cc, $row["kolom_33"])
            ->setCellValue("AI".$cc, $row["kolom_35"]);
};//while


//laporan rk.4
$runSQL = "select * from laporan_rk4 where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 7 + $row["bulan"];

    $objPHPExcel->setActiveSheetIndex(1)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("F".$cc, $row["kolom_6"])
            ->setCellValue("G".$cc, $row["kolom_7"])
            ->setCellValue("H".$cc, $row["kolom_8"])
            ->setCellValue("I".$cc, $row["kolom_9"])
            ->setCellValue("J".$cc, $row["kolom_10"])
            ->setCellValue("K".$cc, $row["kolom_11"])
            ->setCellValue("L".$cc, $row["kolom_12"])
            ->setCellValue("M".$cc, $row["kolom_13"])
            ->setCellValue("N".$cc, $row["kolom_14"])
            ->setCellValue("O".$cc, $row["kolom_15"])
            ->setCellValue("P".$cc, $row["kolom_16"])
            ->setCellValue("Q".$cc, $row["kolom_17"])
            ->setCellValue("R".$cc, $row["kolom_18"])
            ->setCellValue("S".$cc, $row["kolom_19"])
            ->setCellValue("T".$cc, $row["kolom_20"])
            ->setCellValue("U".$cc, $row["kolom_21"])
            ->setCellValue("V".$cc, $row["kolom_22"])
            ->setCellValue("W".$cc, $row["kolom_23"])
            ->setCellValue("X".$cc, $row["kolom_24"])
            ->setCellValue("Y".$cc, $row["kolom_25"])
            ->setCellValue("Z".$cc, $row["kolom_26"])
            ->setCellValue("AA".$cc, $row["kolom_27"])
            ->setCellValue("AB".$cc, $row["kolom_28"])
            ->setCellValue("AC".$cc, $row["kolom_29"])
            ->setCellValue("AD".$cc, $row["kolom_30"])
            ->setCellValue("AE".$cc, $row["kolom_31"])
            ->setCellValue("AF".$cc, $row["kolom_32"])
            ->setCellValue("AG".$cc, $row["kolom_33"])
            ->setCellValue("AH".$cc, $row["kolom_34"])
            ->setCellValue("AI".$cc, $row["kolom_35"])
            ->setCellValue("AJ".$cc, $row["kolom_36"])
            ->setCellValue("AK".$cc, $row["kolom_37"])
            ->setCellValue("AL".$cc, $row["kolom_38"])
            ->setCellValue("AM".$cc, $row["kolom_39"])
            ->setCellValue("AN".$cc, $row["kolom_40"])
            ->setCellValue("AO".$cc, $row["kolom_41"])
            ->setCellValue("AR".$cc, $row["kolom_44"])
            ->setCellValue("AS".$cc, $row["kolom_45"]);
};//while

/*
//laporan rk.5
if ($thn >= 2017){
$runSQL = "select * from laporan_rk5new where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 8 + $row["bulan"];

    $objPHPExcel->setActiveSheetIndex(2)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_5"])
            ->setCellValue("F".$cc, $row["kolom_6"])
            ->setCellValue("G".$cc, $row["kolom_7"])
            ->setCellValue("H".$cc, $row["kolom_8"])
            ->setCellValue("I".$cc, $row["kolom_9"])
            ->setCellValue("J".$cc, $row["kolom_10"])
            ->setCellValue("K".$cc, $row["kolom_11"])
            ->setCellValue("L".$cc, $row["kolom_12"])
            ->setCellValue("M".$cc, $row["kolom_13"])
            ->setCellValue("N".$cc, $row["kolom_14"])
            ->setCellValue("O".$cc, $row["kolom_15"])
            ->setCellValue("P".$cc, $row["kolom_16"])
            ->setCellValue("R".$cc, $row["kolom_19"]);
};//while
}else{
$runSQL = "select * from laporan_rk5 where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 8 + $row["bulan"];

    $objPHPExcel->setActiveSheetIndex(2)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_5"])
            ->setCellValue("F".$cc, $row["kolom_6"])
            ->setCellValue("G".$cc, $row["kolom_7"])
            ->setCellValue("H".$cc, $row["kolom_8"])
            ->setCellValue("I".$cc, $row["kolom_9"])
            ->setCellValue("J".$cc, $row["kolom_10"])
            ->setCellValue("K".$cc, $row["kolom_11"])
            ->setCellValue("L".$cc, $row["kolom_12"])
            ->setCellValue("M".$cc, $row["kolom_13"])
            ->setCellValue("N".$cc, $row["kolom_14"])
            ->setCellValue("O".$cc, $row["kolom_15"])
            ->setCellValue("P".$cc, $row["kolom_16"])
            ->setCellValue("Q".$cc, $row["kolom_17"])
            ->setCellValue("S".$cc, $row["kolom_19"]);
};//while
};//if
*/

//laporan rk.6
$runSQL = "select * from laporan_rk6 where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 9 + $row["bulan"];

    $objPHPExcel->setActiveSheetIndex(3)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_5"])
            ->setCellValue("F".$cc, $row["kolom_6"])
            ->setCellValue("G".$cc, $row["kolom_7"])
            ->setCellValue("H".$cc, $row["kolom_8"])
            ->setCellValue("J".$cc, $row["kolom_10"])
            ->setCellValue("K".$cc, $row["kolom_11"])
            ->setCellValue("L".$cc, $row["kolom_12"])
            ->setCellValue("P".$cc, $row["kolom_16"])
            ->setCellValue("Q".$cc, $row["kolom_17"])
            ->setCellValue("R".$cc, $row["kolom_18"])
            ->setCellValue("S".$cc, $row["kolom_19"])
            ->setCellValue("T".$cc, $row["kolom_20"]);
};//while


//laporan rk.7a
$runSQL = "select * from laporan_rk7a where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 6 + $row["bulan"];

    $objPHPExcel->setActiveSheetIndex(4)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_5"])
            ->setCellValue("F".$cc, $row["kolom_6"])
            ->setCellValue("H".$cc, $row["kolom_8"]);
};//while


//laporan rk.8a
$runSQL = "select * from laporan_rk8a where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 6 + $row["bulan"];

    $objPHPExcel->setActiveSheetIndex(5)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_5"])
            ->setCellValue("H".$cc, $row["kolom_8"])
            ->setCellValue("I".$cc, $row["kolom_9"]);
};//while


//laporan rk.8b
$runSQL = "select * from laporan_rk8b where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 6 + $row["bulan"];

    $objPHPExcel->setActiveSheetIndex(6)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_5"])
            ->setCellValue("H".$cc, $row["kolom_8"]);
};//while


//laporan rk.8c
$runSQL = "select * from laporan_rk8c where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 7 + $row["bulan"];

    $objPHPExcel->setActiveSheetIndex(7)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_5"])
            ->setCellValue("H".$cc, $row["kolom_8"]);
};//while


//laporan rk.9
$runSQL = "select * from laporan_rk9 where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 7 + $row["bulan"];

    $objPHPExcel->setActiveSheetIndex(8)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_5"])
            ->setCellValue("F".$cc, $row["kolom_6"])
            ->setCellValue("G".$cc, $row["kolom_7"])
            ->setCellValue("H".$cc, $row["kolom_8"])
            ->setCellValue("I".$cc, $row["kolom_9"])
            ->setCellValue("J".$cc, $row["kolom_10"]);
};//while


//laporan rk.10
$runSQL = "select * from laporan_rk10 where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 7 + $row["bulan"];

    $objPHPExcel->setActiveSheetIndex(9)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_5"])
            ->setCellValue("F".$cc, $row["kolom_6"])
            ->setCellValue("G".$cc, $row["kolom_7"])
            ->setCellValue("H".$cc, $row["kolom_8"])
            ->setCellValue("I".$cc, $row["kolom_9"])
            ->setCellValue("J".$cc, $row["kolom_10"])
            ->setCellValue("K".$cc, $row["kolom_11"])
            ->setCellValue("L".$cc, $row["kolom_12"]);
};//while


//laporan rk.11a
$runSQL = "select * from laporan_rk11a where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 7 + $row["bulan"];

    $objPHPExcel->setActiveSheetIndex(10)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"]);
};//while


//laporan rk.11b
$runSQL = "select * from laporan_rk11b where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 7 + $row["bulan"];

    $objPHPExcel->setActiveSheetIndex(11)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_5"])
            ->setCellValue("F".$cc, $row["kolom_6"])
            ->setCellValue("G".$cc, $row["kolom_7"])
            ->setCellValue("H".$cc, $row["kolom_8"])
            ->setCellValue("I".$cc, $row["kolom_9"])
            ->setCellValue("J".$cc, $row["kolom_10"])
            ->setCellValue("K".$cc, $row["kolom_11"])
            ->setCellValue("L".$cc, $row["kolom_12"])
            ->setCellValue("M".$cc, $row["kolom_13"])
            ->setCellValue("N".$cc, $row["kolom_14"])
            ->setCellValue("O".$cc, $row["kolom_15"])
            ->setCellValue("P".$cc, $row["kolom_16"])
            ->setCellValue("Q".$cc, $row["kolom_17"])
            ->setCellValue("R".$cc, $row["kolom_18"])
            ->setCellValue("S".$cc, $row["kolom_19"])
            ->setCellValue("T".$cc, $row["kolom_20"])
            ->setCellValue("U".$cc, $row["kolom_21"]);
};//while


//laporan rk.12
$runSQL = "select * from laporan_rk12 where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 7 + $row["bulan"];

    $objPHPExcel->setActiveSheetIndex(12)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_5"])
            ->setCellValue("F".$cc, $row["kolom_6"]);
};//while


//laporan rk.ma
$runSQL = "select * from laporan_rkma where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 8 + $row["bulan"];

    $objPHPExcel->setActiveSheetIndex(13)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_5"])
            ->setCellValue("G".$cc, $row["kolom_7"])
            ->setCellValue("H".$cc, $row["kolom_8"])
            ->setCellValue("I".$cc, $row["kolom_9"])
            ->setCellValue("K".$cc, $row["kolom_11"])
            ->setCellValue("L".$cc, $row["kolom_12"]);
};//while


//laporan rk.esyar
$runSQL = "select * from laporan_rkesyar where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12)";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$cc = 7 + $row["bulan"];

    $objPHPExcel->setActiveSheetIndex(14)
            ->setCellValue("A".$cc, $row["bulan"])
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_5"])
            ->setCellValue("F".$cc, $row["kolom_6"])
            ->setCellValue("G".$cc, $row["kolom_7"])
            ->setCellValue("H".$cc, $row["kolom_8"])
            ->setCellValue("I".$cc, $row["kolom_9"])
            ->setCellValue("J".$cc, $row["kolom_10"]);
};//while


//laporan layanan terpadu
$jml_5=""; $jml_6=""; $jml_7=""; $jml_8=""; $jml_9="";
for($cc=1; $cc<=12; $cc++){

	$i=0; $kolom_1=""; $kolom_2=""; $kolom_3=""; $kolom_4=""; $kolom_5=""; $kolom_6=""; $kolom_7=""; $kolom_8=""; $kolom_9=""; $kolom_10="";
	$runSQL = "select * from laporan_lyterpadu where id_satker='$view_this_satker' and tahun='$thn' and bulan='$cc'";
	$result = mysql_query($runSQL, $connDB);
	while ($row = mysql_fetch_array ($result)) { 
		$i++;
		$kolom_1 .= $i."\r\n";
		//$kolom_2 .= $row["kolom_2"]."\r\n";
		$kolom_3 .= $row["kolom_3"]."\r\n";
		$kolom_4 .= $row["kolom_4"]."\r\n";
		$kolom_5 .= $row["kolom_5"]."\r\n";
		$kolom_6 .= $row["kolom_6"]."\r\n";
		$kolom_7 .= $row["kolom_7"]."\r\n";
		$kolom_8 .= $row["kolom_8"]."\r\n";
		$kolom_9 .= $row["kolom_9"]."\r\n";
		$kolom_10 .= $row["kolom_10"]."\r\n";

		$jml_5 += $row["kolom_5"];
		$jml_6 += $row["kolom_6"];
		$jml_7 += $row["kolom_7"];
		$jml_8 += $row["kolom_8"];
		$jml_9 += $row["kolom_9"];
	};//while

	$row = 7 + $cc;
	$objPHPExcel->setActiveSheetIndex(15)
					->setCellValue("A".$row, $cc)
					->setCellValue("B".$row, $kolom_3)
					->setCellValue("C".$row, $kolom_4)
					->setCellValue("D".$row, $kolom_5)
					->setCellValue("E".$row, $kolom_6)
					->setCellValue("F".$row, $kolom_7)
					->setCellValue("G".$row, $kolom_8)
					->setCellValue("H".$row, $kolom_9)
					->setCellValue("I".$row, $kolom_10);
};//for

$objPHPExcel->setActiveSheetIndex(15)
				->setCellValue("D20", $jml_5)
				->setCellValue("E20", $jml_6)
				->setCellValue("F20", $jml_7)
				->setCellValue("G20", $jml_8)
				->setCellValue("H20", $jml_9);


/*
//register delegasi
$baris = 0;
$runSQL = "select id_satker, tahun, bulan, id_session, lastupdate, kolom_1, kolom_2, kolom_3, kolom_4, kolom_4b, date_format(kolom_5,'%d-%m-%Y') kolom_5, kolom_6 as kolom_6sql, date_format(kolom_6,'%d-%m-%Y') kolom_6, kolom_7 as kolom_7srt, date_format(kolom_7,'%d-%m-%Y') kolom_7, date_format(kolom_8,'%d-%m-%Y') kolom_8, date_format(kolom_8b,'%d-%m-%Y') kolom_8b, date_format(kolom_9,'%d-%m-%Y') kolom_9, kolom_10, kolom_11, kolom_12 from laporan_delegasi where id_satker='$view_this_satker' and tahun='$thn' and (bulan >=1 and bulan <=12) ORDER BY bulan ASC , kolom_7srt ASC";
$result = mysql_query($runSQL, $connDB);
while ($row = mysql_fetch_array ($result)) {
	$baris++;
	$cc = 6 + $baris;
	if (($row["kolom_5"]=="00-00-0000")or($row["kolom_5"]=="")){ $row["kolom_5"]=" - "; }
	if (($row["kolom_6"]=="00-00-0000")or($row["kolom_6"]=="")){ $row["kolom_6"]=" - "; }
	if (($row["kolom_7"]=="00-00-0000")or($row["kolom_7"]=="")){ $row["kolom_7"]=" - "; }
	if (($row["kolom_8"]=="00-00-0000")or($row["kolom_8"]=="")){ $row["kolom_8"]=" - "; }
	if (($row["kolom_8b"]=="00-00-0000")or($row["kolom_8b"]=="")){ $row["kolom_8b"]=" - "; }
	if (($row["kolom_9"]=="00-00-0000")or($row["kolom_9"]=="")){ $row["kolom_9"]=" - "; }
    $objPHPExcel->setActiveSheetIndex(16)
            ->setCellValue("A".$cc, $baris)
            ->setCellValue("B".$cc, $row["kolom_2"])
            ->setCellValue("C".$cc, $row["kolom_3"])
            ->setCellValue("D".$cc, $row["kolom_4"])
            ->setCellValue("E".$cc, $row["kolom_4b"])
            ->setCellValue("F".$cc, $row["kolom_5"])
            ->setCellValue("G".$cc, $row["kolom_6"])
            ->setCellValue("H".$cc, $row["kolom_7"])
            ->setCellValue("I".$cc, $row["kolom_8"])
            ->setCellValue("J".$cc, $row["kolom_8b"])
            ->setCellValue("K".$cc, $row["kolom_9"])
            ->setCellValue("L".$cc, $row["kolom_10"])
            ->setCellValue("M".$cc, $row["kolom_11"]);
};//while
*/


// Set active sheet index to the first sheet, so Excel opens this as the first sheet
$objPHPExcel->setActiveSheetIndex(0);


// Redirect output to a client’s web browser (Excel5)
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="'.$fileDownload.'"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
$objWriter->save('php://output');
exit;
