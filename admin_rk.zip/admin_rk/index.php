<?php
// Aplikasi Pendaftaran Perkara Online
// Copyright PTA Surabaya, http://www.pta-surabaya.go.id
// Contact Tim IT PTA Surabaya, lastupdate 15 Mei 2013

header("location:tampil.php");

?>